<?php
declare(strict_types=1);

namespace Edugram;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use PDO;
use Throwable;

final class Auth
{
    private const PASSWORD_HINT = 'At least 8 characters, including uppercase, lowercase, and a number. A symbol is optional and may improve strength.';
    private const DUMMY_PASSWORD_HASH = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';

    /** Return the Authorization header from the common Apache/PHP server keys. */
    public static function bearerHeader(): string
    {
        foreach (['HTTP_AUTHORIZATION', 'REDIRECT_HTTP_AUTHORIZATION'] as $key) {
            if (isset($_SERVER[$key]) && is_string($_SERVER[$key])) {
                return $_SERVER[$key];
            }
        }

        $headers = function_exists('getallheaders') ? getallheaders() : [];
        if ((!is_array($headers) || $headers === []) && function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
        }
        if (is_array($headers)) {
            foreach ($headers as $name => $value) {
                if (strcasecmp((string)$name, 'Authorization') === 0 && is_string($value)) {
                    return $value;
                }
            }
        }

        return '';
    }

    public static function login(PDO $db, array $body, string $ipAddress, string $jwtSecret): array
    {
        $rawIdentifier = is_string($body['identifier'] ?? null)
            ? $body['identifier']
            : (is_string($body['email'] ?? null) ? $body['email'] : '');
        $identifier = trim($rawIdentifier);
        $password = $body['password'] ?? null;

        $user = null;
        if (is_string($password) && $identifier !== '' && (function_exists('mb_strlen') ? mb_strlen($identifier) : strlen($identifier)) <= 255) {
            $user = self::findByIdentifier($db, $identifier);
        }
        if ($user === null) {
            password_verify(is_string($password) ? $password : '', self::DUMMY_PASSWORD_HASH);
        }

        $validPassword = is_string($password) && $user !== null
            && ($user['accountStatus'] === 'active')
            && self::verifyPassword($password, (string)$user['passwordHash']);

        Audit::recordLoginAttempt(
            $db,
            $validPassword ? $user['id'] : ($user['id'] ?? null),
            $identifier,
            $validPassword,
            $ipAddress
        );

        if (!$validPassword) {
            throw new HttpError(401, 'Invalid credentials');
        }

        Audit::record($db, $user['id'], 'login_success', 'User signed in', $ipAddress);
        $token = self::issueToken($user, $jwtSecret);
        $publicUser = self::publicUser($user);
        if ($user['role'] === 'student') {
            unset($publicUser['email']);
        }
        return ['token' => $token, 'user' => $publicUser];
    }

    public static function register(PDO $db, array $body, string $ipAddress, string $jwtSecret): array
    {
        $email = is_string($body['email'] ?? null) ? strtolower(trim($body['email'])) : '';
        $firstName = is_string($body['firstName'] ?? null) ? trim($body['firstName']) : '';
        $middleName = is_string($body['middleName'] ?? null) ? trim($body['middleName']) : '';
        $lastName = is_string($body['lastName'] ?? null) ? trim($body['lastName']) : '';
        $phone = is_string($body['phone'] ?? null) ? trim($body['phone']) : '';
        $studentId = is_string($body['studentId'] ?? null)
            ? trim($body['studentId'])
            : (is_string($body['idNumber'] ?? null) ? trim($body['idNumber']) : '');
        $otpCode = is_string($body['otpCode'] ?? null) ? trim($body['otpCode']) : '';

        if ((function_exists('mb_strlen') ? mb_strlen($email) : strlen($email)) > 255 || !preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $email)) {
            throw new HttpError(400, 'A valid email address is required');
        }
        if (strlen($otpCode) !== 6) {
            throw new HttpError(400, 'A valid 6-digit verification code is required');
        }

        $otpId = Otp::verify(
            $db,
            $email,
            $otpCode,
            'Verification code has expired. Please request a new one.',
            'Invalid verification code'
        );

        $password = $body['password'] ?? null;
        if (!self::isValidPassword($password)) {
            throw new HttpError(400, self::PASSWORD_HINT);
        }
        if ($firstName === '' || (function_exists('mb_strlen') ? mb_strlen($firstName) : strlen($firstName)) > 100 || (function_exists('mb_strlen') ? mb_strlen($middleName) : strlen($middleName)) > 100
            || $lastName === '' || (function_exists('mb_strlen') ? mb_strlen($lastName) : strlen($lastName)) > 100) {
            throw new HttpError(400, 'First and last name are required and must be 100 characters or fewer');
        }
        if ((function_exists('mb_strlen') ? mb_strlen($phone) : strlen($phone)) > 20 || (function_exists('mb_strlen') ? mb_strlen($studentId) : strlen($studentId)) > 30) {
            throw new HttpError(400, 'Phone or student ID is too long');
        }

        $yearSectionId = self::resolveYearSection($db, $body);
        $db->beginTransaction();
        try {
            $insert = $db->prepare(
                'INSERT INTO users (role_id, email, phone, password_hash, first_name, middle_name, last_name, '
                . 'school_id_number, year_section_id, account_status, terms_accepted_at) '
                . 'SELECT role_id, :email, :phone, :password_hash, :first_name, :middle_name, :last_name, '
                . ':student_id, :year_section_id, \'active\', CURRENT_TIMESTAMP FROM roles WHERE role_name = \'student\''
            );
            $insert->execute([
                'email' => $email,
                'phone' => $phone !== '' ? $phone : null,
                'password_hash' => password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]),
                'first_name' => $firstName,
                'middle_name' => $middleName !== '' ? $middleName : null,
                'last_name' => $lastName,
                'student_id' => $studentId !== '' ? $studentId : null,
                'year_section_id' => $yearSectionId,
            ]);
            if ($insert->rowCount() !== 1) {
                throw new \RuntimeException('The student role is missing from the roles table.');
            }

            $userId = (string)$db->lastInsertId();
            Otp::consume($db, $otpId);
            Audit::record($db, $userId, 'account_registered', 'Student account registered via OTP verification', $ipAddress);

            $user = [
                'id' => $userId,
                'email' => $email,
                'phone' => $phone !== '' ? $phone : null,
                'role' => 'student',
                'firstName' => $firstName,
                'middleName' => $middleName !== '' ? $middleName : null,
                'lastName' => $lastName,
                'studentId' => $studentId !== '' ? $studentId : null,
                'yearSectionId' => $yearSectionId,
            ];
            $token = self::issueToken($user, $jwtSecret);
            $db->commit();
            $publicUser = self::publicUser($user);
            unset($publicUser['email']);
            return ['token' => $token, 'user' => $publicUser];
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }
    }

    public static function resetPassword(PDO $db, array $body, string $ipAddress): array
    {
        $email = is_string($body['email'] ?? null) ? strtolower(trim($body['email'])) : '';
        $otpCode = is_string($body['otpCode'] ?? null) ? trim($body['otpCode']) : '';
        $newPassword = $body['newPassword'] ?? null;

        if ($email === '' || $otpCode === '' || !is_string($newPassword) || $newPassword === '') {
            throw new HttpError(400, 'Email, verification code, and new password are required');
        }
        if (!self::isValidPassword($newPassword)) {
            throw new HttpError(400, self::PASSWORD_HINT);
        }

        $otpId = Otp::verify($db, $email, $otpCode, 'Verification code has expired', 'Invalid verification code');
        $findUser = $db->prepare(self::userSelect() . ' WHERE LOWER(u.email) = LOWER(:email) LIMIT 1');
        $findUser->execute(['email' => $email]);
        $user = $findUser->fetch();
        if (!$user) {
            throw new HttpError(404, 'Account not found');
        }

        $db->beginTransaction();
        try {
            $passwordHash = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => 12]);
            $history = $db->prepare('INSERT INTO password_history (user_id, password_hash) VALUES (:id, :hash)');
            $history->execute(['id' => $user['id'], 'hash' => $passwordHash]);
            $update = $db->prepare(
                'UPDATE users SET password_hash = :hash, password_changed_at = CURRENT_TIMESTAMP '
                . 'WHERE user_id = :id'
            );
            $update->execute(['hash' => $passwordHash, 'id' => $user['id']]);
            Otp::consume($db, $otpId);
            Audit::record($db, $user['id'], 'password_reset_otp', 'Password reset completed via OTP verification', $ipAddress);
            $db->commit();
            return ['success' => true, 'message' => 'Password updated successfully! You can now log in.'];
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }
    }

    public static function requireAuth(PDO $db, string $authorization, string $jwtSecret): array
    {
        if (!preg_match('/^Bearer\s+(.+)$/i', trim($authorization), $matches)) {
            throw new HttpError(401, 'Not authenticated');
        }
        try {
            $claims = JWT::decode($matches[1], new Key($jwtSecret, 'HS256'));
        } catch (Throwable) {
            throw new HttpError(401, 'Invalid or expired token');
        }

        $userId = (string)($claims->userId ?? $claims->sub ?? '');
        if (!preg_match('/^[1-9]\d*$/', $userId)) {
            throw new HttpError(401, 'Please sign in again');
        }
        try {
            $user = self::findById($db, $userId);
        } catch (Throwable $error) {
            error_log('Authentication account lookup failed: ' . $error->getMessage());
            throw new HttpError(500, 'Could not verify the account');
        }
        if (!$user || $user['accountStatus'] !== 'active') {
            throw new HttpError(401, 'Account is unavailable. Please sign in again.');
        }
        $user['userId'] = $userId;
        return $user;
    }

    public static function requireRole(array $user, array $roles): void
    {
        if (!in_array($user['role'] ?? '', $roles, true)) {
            throw new HttpError(403, 'Forbidden');
        }
    }

    public static function findById(PDO $db, string $id): ?array
    {
        $statement = $db->prepare(self::userSelect() . ' WHERE u.user_id = :id LIMIT 1');
        $statement->execute(['id' => $id]);
        return $statement->fetch() ?: null;
    }

    private static function findByIdentifier(PDO $db, string $identifier): ?array
    {
        $statement = $db->prepare(
            self::userSelect() . ' WHERE LOWER(u.email) = LOWER(:email) OR u.phone = :phone LIMIT 1'
        );
        $statement->execute(['email' => $identifier, 'phone' => $identifier]);
        return $statement->fetch() ?: null;
    }

    private static function userSelect(): string
    {
        return 'SELECT CAST(u.user_id AS CHAR) AS id, u.email, u.phone, u.password_hash AS passwordHash, '
            . 'u.first_name AS firstName, u.middle_name AS middleName, u.last_name AS lastName, '
            . 'u.school_id_number AS studentId, CAST(u.year_section_id AS CHAR) AS yearSectionId, '
            . 'year_section.year_section_name AS yearSectionName, CAST(major.major_id AS CHAR) AS majorId, '
            . 'major.major_name AS majorName, CAST(course.course_id AS CHAR) AS courseId, '
            . 'course.course_code AS courseCode, course.course_name AS courseName, '
            . 'u.account_status AS accountStatus, u.failed_login_count AS failedLoginCount, '
            . 'u.locked_until AS lockedUntil, r.role_name AS role, u.created_at AS createdAt, '
            . 'u.updated_at AS updatedAt FROM users u JOIN roles r ON r.role_id = u.role_id '
            . 'LEFT JOIN year_sections year_section ON year_section.year_section_id = u.year_section_id '
            . 'LEFT JOIN majors major ON major.major_id = year_section.major_id '
            . 'LEFT JOIN courses course ON course.course_id = major.course_id';
    }

    private static function verifyPassword(string $password, string $storedHash): bool
    {
        // Node's bcrypt writes $2b$ hashes. PHP's common bcrypt format is $2y$;
        // these prefixes use the same bcrypt hash data, so normalize only the prefix.
        if (str_starts_with($storedHash, '$2b$')) {
            $storedHash = '$2y$' . substr($storedHash, 4);
        }
        return password_verify($password, $storedHash);
    }

    private static function issueToken(array $user, string $jwtSecret): string
    {
        if ($jwtSecret === '') {
            throw new \RuntimeException('JWT_SECRET is missing from the environment.');
        }
        $now = time();
        return JWT::encode([
            'iat' => $now,
            'exp' => $now + 3600,
            'sub' => (string)$user['id'],
            'userId' => (string)$user['id'],
            'role' => $user['role'],
        ], $jwtSecret, 'HS256');
    }

    private static function publicUser(array $user): array
    {
        unset($user['passwordHash'], $user['password_hash'], $user['password'], $user['salt'], $user['_dbUserId']);
        return $user;
    }

    private static function isValidPassword(mixed $password): bool
    {
        return is_string($password) && (function_exists('mb_strlen') ? mb_strlen($password) : strlen($password)) >= 8
            && preg_match('/[A-Z]/', $password) === 1
            && preg_match('/[a-z]/', $password) === 1
            && preg_match('/\d/', $password) === 1;
    }

    private static function resolveYearSection(PDO $db, array $body): ?string
    {
        $hasAcademicInputs = array_intersect(['courseId', 'majorId', 'year', 'section'], array_keys($body)) !== [];
        if (!$hasAcademicInputs) {
            $id = $body['yearSectionId'] ?? null;
            if ($id === null || $id === '') {
                return null;
            }
            $id = trim((string)$id);
            if (!preg_match('/^[1-9]\d*$/', $id) || !self::yearSectionExists($db, $id)) {
                throw new HttpError(400, 'Select a valid year and section');
            }
            return $id;
        }

        $courseId = trim((string)($body['courseId'] ?? ''));
        $majorId = trim((string)($body['majorId'] ?? ''));
        $year = trim((string)($body['year'] ?? ''));
        $section = preg_replace('/\s+/', ' ', trim((string)($body['section'] ?? '')));
        $values = [$courseId, $majorId, $year, $section];
        if (!array_filter($values, static fn($value) => $value !== '')) {
            return null;
        }
        if (in_array('', $values, true)) {
            throw new HttpError(400, 'Choose a course and major, then enter both year and section.');
        }
        if (!preg_match('/^[1-9]\d*$/', $courseId) || !preg_match('/^[1-9]\d*$/', $majorId)
            || !preg_match('/^[1-6]$/', $year)
            || !preg_match('/^[A-Za-z0-9][A-Za-z0-9 -]{0,15}$/', $section)) {
            throw new HttpError(400, 'Enter a year from 1 to 6 and a section using letters, numbers, spaces, or hyphens.');
        }
        $name = $year . '-' . $section;
        if ((function_exists('mb_strlen') ? mb_strlen($name) : strlen($name)) > 20) {
            throw new HttpError(400, 'The year and section together must be 20 characters or fewer.');
        }

        $db->beginTransaction();
        try {
            $major = $db->prepare('SELECT major_id FROM majors WHERE major_id = :major AND course_id = :course FOR UPDATE');
            $major->execute(['major' => $majorId, 'course' => $courseId]);
            if (!$major->fetch()) {
                $db->rollBack();
                throw new HttpError(400, 'The selected major does not belong to the selected course.');
            }
            $find = $db->prepare(
                'SELECT CAST(year_section_id AS CHAR) FROM year_sections '
                . 'WHERE major_id = :major AND LOWER(year_section_name) = LOWER(:name) LIMIT 1 FOR UPDATE'
            );
            $find->execute(['major' => $majorId, 'name' => $name]);
            $yearSectionId = $find->fetchColumn();
            if ($yearSectionId === false) {
                $insert = $db->prepare('INSERT INTO year_sections (major_id, year_section_name) VALUES (:major, :name)');
                $insert->execute(['major' => $majorId, 'name' => $name]);
                $yearSectionId = (string)$db->lastInsertId();
            }
            $db->commit();
            return (string)$yearSectionId;
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }
    }

    private static function yearSectionExists(PDO $db, string $id): bool
    {
        $statement = $db->prepare('SELECT 1 FROM year_sections WHERE year_section_id = :id LIMIT 1');
        $statement->execute(['id' => $id]);
        return (bool)$statement->fetchColumn();
    }
}
