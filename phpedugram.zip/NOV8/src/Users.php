<?php
declare(strict_types=1);

namespace Edugram;

use PDO;
use PDOException;
use Throwable;

final class Users
{
    private const PASSWORD_HINT = 'At least 8 characters, including uppercase, lowercase, and a number. A symbol is optional and may improve strength.';
    private const ROLES = ['student', 'teacher', 'admin', 'super_admin'];

    /** Returns null when the path/method is not handled, otherwise [status, response]. */
    public static function handle(PDO $db, string $method, string $path, array $body, array $actor, string $ip): ?array
    {
        if (preg_match('#^/api/users/([^/]+)(?:/(password|role|status))?$#', $path, $matches) !== 1) {
            return null;
        }
        $id = $matches[1];
        $action = $matches[2] ?? '';
        if (!preg_match('/^[1-9]\d*$/', $id)) {
            throw new HttpError(400, 'A valid id is required');
        }

        if ($method === 'PUT' && $action === 'password') {
            return self::updatePassword($db, $id, $body, $actor, $ip);
        }
        if ($method === 'PUT' && $action === 'role') {
            return self::updateRole($db, $id, $body, $actor, $ip);
        }
        if ($method === 'PUT' && $action === 'status') {
            return self::updateStatus($db, $id, $body, $actor, $ip);
        }
        if ($method === 'PUT' && $action === '') {
            return self::updateProfile($db, $id, $body, $actor, $ip);
        }
        if ($method === 'DELETE' && $action === '') {
            return self::delete($db, $id, $actor, $ip);
        }
        return null;
    }

    private static function updatePassword(PDO $db, string $id, array $body, array $actor, string $ip): array
    {
        $self = $id === (string)($actor['sub'] ?? '') || $id === (string)$actor['userId'];
        $isAdmin = in_array($actor['role'], ['admin', 'super_admin'], true);
        if (!$self && !$isAdmin) {
            throw new HttpError(403, 'Forbidden');
        }
        $password = $body['password'] ?? null;
        if (!self::validPassword($password)) {
            throw new HttpError(400, self::PASSWORD_HINT);
        }

        $targetId = $self ? (string)$actor['userId'] : $id;
        $user = Auth::findById($db, $targetId);
        if (!$user) {
            throw new HttpError(404, 'User not found');
        }
        if (!$self && $actor['role'] === 'admin' && !in_array($user['role'], ['student', 'teacher'], true)) {
            throw new HttpError(403, 'Admins can manage student and teacher passwords only');
        }

        $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
        $db->beginTransaction();
        try {
            $lock = $db->prepare('SELECT user_id FROM users WHERE user_id = :id FOR UPDATE');
            $lock->execute(['id' => $targetId]);
            if (!$lock->fetch()) {
                throw new HttpError(404, 'User not found');
            }
            $history = $db->prepare('INSERT INTO password_history (user_id, password_hash) VALUES (:id, :hash)');
            $history->execute(['id' => $targetId, 'hash' => $hash]);
            $update = $db->prepare(
                'UPDATE users SET password_hash = :hash, password_changed_at = CURRENT_TIMESTAMP, '
                . 'failed_login_count = 0, locked_until = NULL WHERE user_id = :id'
            );
            $update->execute(['hash' => $hash, 'id' => $targetId]);
            $actorId = (string)$actor['userId'];
            Audit::record(
                $db,
                $actorId,
                $self ? 'password_changed' : 'password_reset',
                $self ? "User {$actorId} changed their password" : "User {$actorId} reset password for user {$targetId}",
                $ip
            );
            $db->commit();
            return [200, ['success' => true]];
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }
    }

    private static function updateProfile(PDO $db, string $id, array $body, array $actor, string $ip): array
    {
        $self = $id === (string)$actor['userId'] || $id === (string)($actor['sub'] ?? '');
        if (!$self && !in_array($actor['role'], ['admin', 'super_admin'], true)) {
            throw new HttpError(403, 'Forbidden');
        }
        $targetId = $self ? (string)$actor['userId'] : $id;
        $target = Auth::findById($db, $targetId);
        if (!$target) {
            throw new HttpError(404, 'User not found');
        }
        if (array_key_exists('password', $body) && (!$self || !self::validPassword($body['password']))) {
            throw new HttpError(400, self::PASSWORD_HINT);
        }
        if (!$self && $actor['role'] === 'admin' && !in_array($target['role'], ['student', 'teacher'], true)) {
            throw new HttpError(403, 'Admins may update students and teachers only');
        }
        if (!$self && $actor['role'] === 'super_admin' && $target['role'] === 'super_admin') {
            throw new HttpError(403, 'Super-admin profiles cannot be edited through this route');
        }

        $email = is_string($body['email'] ?? null) ? strtolower(trim($body['email'])) : $target['email'];
        $firstName = is_string($body['firstName'] ?? null) ? trim($body['firstName']) : '';
        $middleName = is_string($body['middleName'] ?? null) ? trim($body['middleName']) : '';
        $lastName = is_string($body['lastName'] ?? null) ? trim($body['lastName']) : '';
        $phone = is_string($body['phone'] ?? null) ? trim($body['phone']) : '';
        $studentId = is_string($body['studentId'] ?? null) ? trim($body['studentId']) : '';

        if (!preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $email) || strlen($email) > 255 || $firstName === ''
            || $lastName === '' || strlen($firstName) > 100 || strlen($middleName) > 100
            || strlen($lastName) > 100 || strlen($phone) > 20 || strlen($studentId) > 30) {
            throw new HttpError(400, 'Profile fields are invalid');
        }
        $yearSectionId = self::profileYearSection($db, $body);
        $hash = !empty($body['password']) ? password_hash((string)$body['password'], PASSWORD_BCRYPT, ['cost' => 12]) : null;
        $db->beginTransaction();
        try {
            $lock = $db->prepare('SELECT year_section_id FROM users WHERE user_id = :id FOR UPDATE');
            $lock->execute(['id' => $targetId]);
            $oldYearSection = $lock->fetchColumn();
            if ($oldYearSection === false) {
                throw new HttpError(404, 'User not found');
            }
            $update = $db->prepare(
                'UPDATE users SET email = :email, first_name = :first_name, middle_name = :middle_name, '
                . 'last_name = :last_name, phone = :phone, school_id_number = :student_id, '
                . 'year_section_id = :year_section_id WHERE user_id = :id'
            );
            $update->execute([
                'email' => $email,
                'first_name' => $firstName,
                'middle_name' => $middleName !== '' ? $middleName : null,
                'last_name' => $lastName,
                'phone' => $phone !== '' ? $phone : null,
                'student_id' => $studentId !== '' ? $studentId : null,
                'year_section_id' => $yearSectionId,
                'id' => $targetId,
            ]);
            if ($hash !== null) {
                $history = $db->prepare('INSERT INTO password_history (user_id, password_hash) VALUES (:id, :hash)');
                $history->execute(['id' => $targetId, 'hash' => $hash]);
                $passwordUpdate = $db->prepare(
                    'UPDATE users SET password_hash = :hash, password_changed_at = CURRENT_TIMESTAMP, '
                    . 'failed_login_count = 0, locked_until = NULL WHERE user_id = :id'
                );
                $passwordUpdate->execute(['hash' => $hash, 'id' => $targetId]);
            }
            $actorId = (string)$actor['userId'];
            Audit::record(
                $db,
                $actorId,
                $hash !== null ? 'password_changed' : 'profile_updated',
                $hash !== null ? "User {$actorId} changed their password" : "User {$actorId} updated profile for user {$targetId}",
                $ip
            );
            if ((string)($oldYearSection ?: '') !== (string)($yearSectionId ?: '')) {
                $event = $yearSectionId ? 'year_section_assigned' : 'year_section_removed';
                $description = $yearSectionId
                    ? "Assigned user {$targetId} to year and section {$yearSectionId}"
                    : "Removed user {$targetId} from their year and section";
                Audit::record($db, $actorId, $event, $description, $ip);
            }
            $db->commit();
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            if ($error instanceof PDOException && $error->getCode() === '23000') {
                throw new HttpError(409, 'Email or ID number is already in use');
            }
            throw $error;
        }

        $updated = Auth::findById($db, $targetId);
        $safe = self::publicUser($updated);
        if ($target['role'] === 'student') {
            unset($safe['email']);
        }
        return [200, ['user' => $safe]];
    }

    private static function updateRole(PDO $db, string $id, array $body, array $actor, string $ip): array
    {
        Auth::requireRole($actor, ['admin', 'super_admin']);
        $role = $body['role'] ?? null;
        if (!in_array($role, self::ROLES, true)) {
            throw new HttpError(400, 'Invalid role');
        }
        if ($role === 'super_admin' && $actor['role'] !== 'super_admin') {
            throw new HttpError(403, 'Only a super admin can assign the super admin role');
        }
        $user = Auth::findById($db, $id);
        if (!$user) {
            throw new HttpError(404, 'User not found');
        }
        if ($user['role'] === 'teacher' && $role !== 'teacher' && self::teacherClassCount($db, $id) > 0) {
            throw new HttpError(409, 'Reassign or delete the classes assigned to this teacher before changing their role');
        }
        if ($id === (string)$actor['userId']) {
            throw new HttpError(403, 'You cannot change your own role');
        }
        if ($actor['role'] === 'admin' && !in_array($user['role'], ['student', 'teacher'], true)) {
            throw new HttpError(403, 'Admins may change student and teacher roles only');
        }
        if ($user['role'] === 'super_admin' && $actor['role'] !== 'super_admin') {
            throw new HttpError(403, 'Only a super admin can change a super admin role');
        }

        $db->beginTransaction();
        try {
            $roleQuery = $db->prepare('SELECT role_id FROM roles WHERE role_name = :role');
            $roleQuery->execute(['role' => $role]);
            $roleId = $roleQuery->fetchColumn();
            if ($roleId === false) {
                throw new \RuntimeException('The requested role is missing from the roles table.');
            }
            $update = $db->prepare('UPDATE users SET role_id = :role_id WHERE user_id = :id');
            $update->execute(['role_id' => $roleId, 'id' => $id]);
            if ($role !== 'student') {
                $enrollments = $db->prepare('SELECT class_id FROM enrollments WHERE student_id = :id FOR UPDATE');
                $enrollments->execute(['id' => $id]);
                $classes = $enrollments->fetchAll();
                $remove = $db->prepare('DELETE FROM enrollments WHERE student_id = :id');
                $remove->execute(['id' => $id]);
                foreach ($classes as $enrollment) {
                    Audit::record($db, (string)$actor['userId'], 'class_member_removed',
                        "Removed user {$id} from class {$enrollment['class_id']} due to role change", $ip);
                }
            }
            Audit::record($db, (string)$actor['userId'], 'role_changed', "Changed user {$id} role to {$role}", $ip);
            $db->commit();
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }
        $user['role'] = $role;
        $safe = self::publicUser($user);
        return [200, ['user' => $safe]];
    }

    private static function updateStatus(PDO $db, string $id, array $body, array $actor, string $ip): array
    {
        Auth::requireRole($actor, ['admin', 'super_admin']);
        $target = Auth::findById($db, $id);
        if (!$target) {
            throw new HttpError(404, 'User not found');
        }
        if ($id === (string)$actor['userId']) {
            throw new HttpError(403, 'You cannot change your own account status');
        }
        if ($actor['role'] === 'admin' && !in_array($target['role'], ['student', 'teacher'], true)) {
            throw new HttpError(403, 'Admins may update student and teacher account status only');
        }
        if ($actor['role'] === 'super_admin' && $target['role'] === 'super_admin') {
            throw new HttpError(403, 'Super-admin account status cannot be changed by another super admin');
        }
        $status = $body['status'] ?? null;
        if (!in_array($status, ['active', 'locked', 'suspended'], true)) {
            throw new HttpError(400, 'Select active, locked, or suspended');
        }

        $db->beginTransaction();
        try {
            $lock = $db->prepare('SELECT user_id FROM users WHERE user_id = :id FOR UPDATE');
            $lock->execute(['id' => $id]);
            if (!$lock->fetch()) {
                throw new HttpError(404, 'User not found');
            }
            $update = $db->prepare(
                'UPDATE users SET account_status = :status, '
                . 'failed_login_count = CASE WHEN :active_status = \'active\' THEN 0 ELSE failed_login_count END, '
                . 'locked_until = CASE WHEN :clear_lock = \'active\' THEN NULL ELSE locked_until END '
                . 'WHERE user_id = :id'
            );
            $update->execute(['status' => $status, 'active_status' => $status, 'clear_lock' => $status, 'id' => $id]);
            $actorId = (string)$actor['userId'];
            Audit::record($db, $actorId, 'account_status_changed', "User {$actorId} set account {$id} status to {$status}", $ip);
            $db->commit();
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }
        return [200, ['user' => self::publicUser(Auth::findById($db, $id))]];
    }

    private static function delete(PDO $db, string $id, array $actor, string $ip): array
    {
        Auth::requireRole($actor, ['admin', 'super_admin']);
        $target = Auth::findById($db, $id);
        if (!$target) {
            throw new HttpError(404, 'User not found');
        }
        if ($id === (string)$actor['userId']) {
            throw new HttpError(403, 'You cannot delete your own account');
        }
        if ($actor['role'] === 'admin' && !in_array($target['role'], ['student', 'teacher'], true)) {
            throw new HttpError(403, 'Admins may delete student and teacher accounts only');
        }
        if ($target['role'] === 'teacher' && self::teacherClassCount($db, $id) > 0) {
            throw new HttpError(409, 'Reassign or delete the classes assigned to this teacher before deleting the account');
        }
        if ($target['role'] === 'super_admin' && $actor['role'] !== 'super_admin') {
            throw new HttpError(403, 'Only a super admin can delete a super admin account');
        }

        $db->beginTransaction();
        try {
            $enrollments = $db->prepare('SELECT class_id FROM enrollments WHERE student_id = :id FOR UPDATE');
            $enrollments->execute(['id' => $id]);
            $classes = $enrollments->fetchAll();
            $delete = $db->prepare('DELETE FROM users WHERE user_id = :id');
            $delete->execute(['id' => $id]);
            if ($delete->rowCount() !== 1) {
                throw new HttpError(404, 'User not found');
            }
            foreach ($classes as $enrollment) {
                Audit::record($db, (string)$actor['userId'], 'class_member_removed',
                    "Removed deleted user {$id} from class {$enrollment['class_id']}", $ip);
            }
            Audit::record($db, (string)$actor['userId'], 'user_deleted', "User {$actor['userId']} deleted user {$id}", $ip);
            $db->commit();
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }

        $coursework = self::removeCoursework($db, $id);
        $coursework['users'] = self::listUsers($db);
        return [200, ['success' => true, 'data' => $coursework]];
    }

    private static function removeCoursework(PDO $db, string $id): array
    {
        $select = $db->prepare('SELECT record_type, record_id, payload FROM coursework_records');
        $select->execute();
        $rows = $select->fetchAll();
        $data = ['users' => [], 'assignments' => [], 'submissions' => [], 'drafts' => []];
        foreach ($rows as $row) {
            $item = json_decode((string)$row['payload'], true);
            if (!is_array($item)) {
                continue;
            }
            if ($row['record_type'] === 'assignment') {
                $data['assignments'][] = $item;
            } elseif ($row['record_type'] === 'submission' && (string)($item['studentId'] ?? '') !== $id) {
                $data['submissions'][] = $item;
            } elseif ($row['record_type'] === 'draft' && !str_starts_with((string)$row['record_id'], $id . ':')) {
                $data['drafts'][$row['record_id']] = $item;
            }
        }
        $deleteSubmissions = $db->prepare('DELETE FROM coursework_records WHERE record_type = \'submission\' AND owner_id = :id');
        $deleteSubmissions->execute(['id' => $id]);
        $deleteDrafts = $db->prepare('DELETE FROM coursework_records WHERE record_type = \'draft\' AND owner_id = :id');
        $deleteDrafts->execute(['id' => $id]);
        return $data;
    }

    private static function listUsers(PDO $db): array
    {
        $sql = 'SELECT CAST(u.user_id AS CHAR) AS id, u.email, u.phone, u.first_name AS firstName, '
            . 'u.middle_name AS middleName, u.last_name AS lastName, u.school_id_number AS studentId, '
            . 'CAST(u.year_section_id AS CHAR) AS yearSectionId, year_section.year_section_name AS yearSectionName, '
            . 'r.role_name AS role, u.account_status AS accountStatus, u.created_at AS createdAt, '
            . 'u.updated_at AS updatedAt FROM users u JOIN roles r ON r.role_id = u.role_id '
            . 'LEFT JOIN year_sections year_section ON year_section.year_section_id = u.year_section_id '
            . 'ORDER BY u.created_at, u.user_id';
        $statement = $db->prepare($sql);
        $statement->execute();
        return $statement->fetchAll();
    }

    private static function publicUser(?array $user): ?array
    {
        if ($user === null) {
            return null;
        }
        unset($user['passwordHash'], $user['password_hash'], $user['password'], $user['salt'], $user['_dbUserId']);
        return $user;
    }

    private static function teacherClassCount(PDO $db, string $teacherId): int
    {
        $statement = $db->prepare('SELECT COUNT(*) FROM classes WHERE teacher_id = :id');
        $statement->execute(['id' => $teacherId]);
        return (int)$statement->fetchColumn();
    }

    private static function validPassword(mixed $password): bool
    {
        return is_string($password) && strlen($password) >= 8
            && preg_match('/[A-Z]/', $password) === 1
            && preg_match('/[a-z]/', $password) === 1
            && preg_match('/\d/', $password) === 1;
    }

    private static function profileYearSection(PDO $db, array $body): ?string
    {
        $hasInputs = array_intersect(['courseId', 'majorId', 'year', 'section'], array_keys($body)) !== [];
        if (!$hasInputs) {
            $id = trim((string)($body['yearSectionId'] ?? ''));
            if ($id === '') {
                return null;
            }
            if (!preg_match('/^[1-9]\d*$/', $id) || !self::yearSectionExists($db, $id)) {
                throw new HttpError(400, 'Select a valid year and section');
            }
            return $id;
        }
        $courseId = trim((string)($body['courseId'] ?? ''));
        $majorId = trim((string)($body['majorId'] ?? ''));
        $year = trim((string)($body['year'] ?? ''));
        $section = preg_replace('/\s+/', ' ', trim((string)($body['section'] ?? '')));
        $values = [$courseId, $majorId, $year, $section];
        if (!array_filter($values, static fn($value) => $value !== '')) {
            return null;
        }
        if (in_array('', $values, true)) {
            throw new HttpError(400, 'Choose a course and major, then enter both year and section.');
        }
        if (!preg_match('/^[1-9]\d*$/', $courseId) || !preg_match('/^[1-9]\d*$/', $majorId)
            || !preg_match('/^[1-6]$/', $year) || !preg_match('/^[A-Za-z0-9][A-Za-z0-9 -]{0,15}$/', $section)) {
            throw new HttpError(400, 'Enter a year from 1 to 6 and a section using letters, numbers, spaces, or hyphens.');
        }
        $name = $year . '-' . $section;
        if (strlen($name) > 20) {
            throw new HttpError(400, 'The year and section together must be 20 characters or fewer.');
        }
        $major = $db->prepare('SELECT 1 FROM majors WHERE major_id = :major AND course_id = :course');
        $major->execute(['major' => $majorId, 'course' => $courseId]);
        if (!$major->fetchColumn()) {
            throw new HttpError(400, 'The selected major does not belong to the selected course.');
        }
        $find = $db->prepare(
            'SELECT CAST(year_section_id AS CHAR) FROM year_sections '
            . 'WHERE major_id = :major AND LOWER(year_section_name) = LOWER(:name) LIMIT 1'
        );
        $find->execute(['major' => $majorId, 'name' => $name]);
        $id = $find->fetchColumn();
        if ($id === false) {
            $insert = $db->prepare('INSERT INTO year_sections (major_id, year_section_name) VALUES (:major, :name)');
            $insert->execute(['major' => $majorId, 'name' => $name]);
            $id = (string)$db->lastInsertId();
        }
        return (string)$id;
    }

    private static function yearSectionExists(PDO $db, string $id): bool
    {
        $statement = $db->prepare('SELECT 1 FROM year_sections WHERE year_section_id = :id LIMIT 1');
        $statement->execute(['id' => $id]);
        return (bool)$statement->fetchColumn();
    }
}
