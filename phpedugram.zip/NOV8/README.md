﻿# EDUGRAM

EDUGRAM is an academic writing and submission system. Its backend uses plain PHP, PDO, and MySQL.

## Folder structure

- public/: web root, pages, styles, frontend scripts, and API router.
- src/: PHP authentication, database, user, academic, class, coursework, mail, audit, and AI code.
- database/: SQL schema and migrations.
- vendor/: Composer packages; do not serve this folder from Apache.
- .env.example: blank settings template. Keep the real .env outside public/ and private.

## Requirements

- Laragon with Apache and MySQL or MariaDB.
- PHP 8.1+ with openssl, curl, mbstring, and pdo_mysql enabled.
- Composer.

## Setup

1. From the project folder run: composer install
2. Copy .env.example to .env and fill in database, JWT, OTP, SMTP, and Gemini settings. Never commit real secrets.
3. Import edugram_login_db (1).sql in HeidiSQL.
4. Run database/php_otp_migration.sql in HeidiSQL.
5. Run database/php_migration_extra.sql in HeidiSQL. The API needs this for coursework_records and users.middle_name; it will fail until this migration is run.
6. Set the Laragon virtual host document root to the project's public/ folder. Enable Apache mod_rewrite and the PHP extensions listed above.
7. Open http://<your-vhost>/api/health. Expected JSON: {"success":true,"message":"EDUGRAM PHP API is healthy"}.

## API endpoints

A signed-in request needs a valid Bearer JWT for an active account. Account status is checked on each authenticated request.

| Method | Endpoint | Role needed | What it does |
|---|---|---|---|
| POST | /api/send-otp | Public | Send an email verification code. |
| POST | /api/verify-otp | Public | Verify and consume an OTP. |
| POST | /api/login | Public | Sign in and receive a JWT. |
| POST | /api/register | Public, valid OTP | Register a student account. |
| POST | /api/forgot-password/reset | Public, valid OTP | Reset a password. |
| PUT | /api/users/:id | Self, admin, super_admin | Update a profile. |
| PUT | /api/users/:id/password | Self, admin, super_admin | Change or reset a password. |
| PUT | /api/users/:id/role | Admin, super_admin | Change a role, subject to role rules. |
| PUT | /api/users/:id/status | Admin, super_admin | Change account status. |
| DELETE | /api/users/:id | Admin, super_admin | Delete an account. |
| GET | /api/academic/options | Public | Load courses, majors, and year-sections. |
| POST/PUT/DELETE | /api/academic/courses[/:id] | Super_admin | Create, edit, or delete a course. |
| POST/PUT/DELETE | /api/academic/majors[/:id] | Super_admin | Create, edit, or delete a major. |
| POST/PUT/DELETE | /api/academic/year-sections[/:id] | Super_admin | Create, edit, or delete a year-section. |
| GET | /api/classes | Student, teacher, admin, super_admin | List classes visible to the role. |
| POST | /api/classes | Admin, super_admin | Create a class and optionally enroll students. |
| PUT/DELETE | /api/classes/:id | Admin, super_admin | Edit or delete a class. |
| GET | /api/classes/:id/members | Student, teacher, admin, super_admin | List class members with role-based checks. |
| POST | /api/classes/:id/members/bulk | Admin, super_admin | Enroll students by school ID number. |
| DELETE | /api/classes/:id/members/:userId | Admin, super_admin | Remove a student from a class. |
| GET | /api/data | Signed in | Load role-filtered users and coursework. |
| PUT | /api/data | Signed in | Disabled; use resource-specific routes. |
| POST | /api/assignments | Teacher, admin, super_admin | Create an assignment. |
| PUT/DELETE | /api/assignments/:id | Teacher, admin, super_admin | Edit or delete an assignment; teachers manage their own. |
| PUT | /api/drafts/:assignmentId | Student | Save a draft for an available assignment. |
| POST | /api/submissions | Student | Submit or update work for an available assignment. |
| PUT | /api/submissions/:id/grade | Teacher, admin, super_admin | Grade a submission; teachers grade their own assignments. |
| POST | /api/ai/analyze-writing | Student | Analyze writing with LanguageTool. |
| POST | /api/ai/improve-writing | Student | Request a revision from Gemini. |
| POST | /api/ai/generate-feedback | Teacher, admin, super_admin | Generate feedback with Gemini. |
| GET | /api/health | Public | Check PHP and MySQL connectivity. |

## Troubleshooting

- vendor/autoload.php missing: run composer install in the project folder.
- Authorization header missing: enable Apache mod_rewrite and confirm public/.htaccess is active. The router checks common Apache Authorization header keys.
- SMTP incomplete: check private .env MAIL_* settings. OTP email needs a working Gmail SMTP account and app password.
- Missing table or column: import the main schema, then run both OTP and extra SQL migrations. Schema details are logged server-side; the browser receives a generic error.
- Health check fails: start MySQL in Laragon, check .env database settings, and enable pdo_mysql.

