<?php
declare(strict_types=1);

namespace Edugram;

use PDO;

final class Audit
{
    public static function recordLoginAttempt(
        PDO $db,
        ?string $userId,
        string $identifier,
        bool $success,
        string $ipAddress
    ): void {
        $statement = $db->prepare(
            'INSERT INTO login_attempts (user_id, identifier_used, ip_address, was_successful, failure_reason) '
            . 'VALUES (:user_id, :identifier, :ip_address, :was_successful, :failure_reason)'
        );
        $statement->execute([
            'user_id' => $userId,
            'identifier' => self::truncate($identifier !== '' ? $identifier : '(empty)', 255),
            'ip_address' => self::truncate($ipAddress !== '' ? $ipAddress : '0.0.0.0', 45),
            'was_successful' => $success ? 1 : 0,
            'failure_reason' => $success ? null : 'invalid_credentials',
        ]);
    }

    public static function record(PDO $db, ?string $userId, string $eventType, string $description, string $ipAddress): void
    {
        $statement = $db->prepare(
            'INSERT INTO audit_logs (user_id, event_type, description, ip_address) '
            . 'VALUES (:user_id, :event_type, :description, :ip_address)'
        );
        $statement->execute([
            'user_id' => $userId,
            'event_type' => self::truncate($eventType, 50),
            'description' => self::truncate($description, 255),
            'ip_address' => $ipAddress !== '' ? self::truncate($ipAddress, 45) : null,
        ]);
    }

    private static function truncate(string $value, int $length): string
    {
        return function_exists('mb_substr')
            ? mb_substr($value, 0, $length, 'UTF-8')
            : substr($value, 0, $length);
    }
}
