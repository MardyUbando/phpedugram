<?php
declare(strict_types=1);

namespace Edugram;

use PDO;
use PDOException;
use Throwable;

final class Academic
{
    private const CONFIG = [
        'courses' => [
            'type' => 'course', 'table' => 'courses', 'id' => 'course_id',
            'fields' => ['course_code', 'course_name'],
        ],
        'majors' => [
            'type' => 'major', 'table' => 'majors', 'id' => 'major_id',
            'fields' => ['course_id', 'major_name'],
        ],
        'year-sections' => [
            'type' => 'yearSection', 'table' => 'year_sections', 'id' => 'year_section_id',
            'fields' => ['major_id', 'year_section_name'],
        ],
    ];

    public static function handle(PDO $db, string $method, string $path, array $body, ?array $actor, string $ip): ?array
    {
        if ($method === 'GET' && $path === '/api/academic/options') {
            return [200, ['courses' => self::options($db)]];
        }
        if (preg_match('#^/api/academic/(courses|majors|year-sections)(?:/([^/]+))?$#', $path, $matches) !== 1) {
            return null;
        }
        if ($actor === null) {
            throw new HttpError(401, 'Not authenticated');
        }
        Auth::requireRole($actor, ['super_admin']);

        $route = self::CONFIG[$matches[1]];
        $id = $matches[2] ?? null;
        if ($id !== null && !preg_match('/^[1-9]\d*$/', $id)) {
            throw new HttpError(400, 'A valid id is required');
        }
        if ($method === 'POST' && $id === null) {
            return self::save($db, $route, $body, null, (string)$actor['userId'], $ip);
        }
        if ($method === 'PUT' && $id !== null) {
            return self::save($db, $route, $body, $id, (string)$actor['userId'], $ip);
        }
        if ($method === 'DELETE' && $id !== null) {
            return self::delete($db, $route, $id, (string)$actor['userId'], $ip);
        }
        return null;
    }

    private static function options(PDO $db): array
    {
        $statement = $db->prepare(
            'SELECT CAST(course.course_id AS CHAR) AS courseId, course.course_code AS courseCode, '
            . 'course.course_name AS courseName, CAST(major.major_id AS CHAR) AS majorId, '
            . 'major.major_name AS majorName, CAST(year_section.year_section_id AS CHAR) AS yearSectionId, '
            . 'year_section.year_section_name AS yearSectionName '
            . 'FROM courses course LEFT JOIN majors major ON major.course_id = course.course_id '
            . 'LEFT JOIN year_sections year_section ON year_section.major_id = major.major_id '
            . 'ORDER BY course.course_code, major.major_name, year_section.year_section_name'
        );
        $statement->execute();
        $rows = $statement->fetchAll();

        $courses = [];
        foreach ($rows as $row) {
            $courseId = (string)$row['courseId'];
            if (!isset($courses[$courseId])) {
                $courses[$courseId] = [
                    'id' => $courseId,
                    'code' => $row['courseCode'],
                    'name' => $row['courseName'],
                    'majors' => [],
                ];
            }
            if ($row['majorId'] === null) {
                continue;
            }
            $majorId = (string)$row['majorId'];
            if (!isset($courses[$courseId]['majors'][$majorId])) {
                $courses[$courseId]['majors'][$majorId] = [
                    'id' => $majorId,
                    'name' => $row['majorName'],
                    'yearSections' => [],
                ];
            }
            if ($row['yearSectionId'] !== null) {
                $courses[$courseId]['majors'][$majorId]['yearSections'][] = [
                    'id' => (string)$row['yearSectionId'],
                    'name' => $row['yearSectionName'],
                ];
            }
        }
        foreach ($courses as &$course) {
            $course['majors'] = array_values($course['majors']);
        }
        unset($course);
        return array_values($courses);
    }

    private static function save(PDO $db, array $route, array $body, ?string $id, string $actorId, string $ip): array
    {
        $type = $route['type'];
        $values = self::values($route, $body);
        $parent = $values['courseId'] ?? $values['majorId'] ?? null;
        if ($parent !== null && !self::parentExists($db, $type, $parent)) {
            throw new HttpError(400, ($type === 'major' ? 'Course' : 'Major') . ' not found');
        }
        if (self::nameExists($db, $type, $values, $id)) {
            throw new HttpError(409, $type === 'course'
                ? 'A course with that code already exists'
                : 'A ' . ($type === 'yearSection' ? 'year and section' : $type) . ' with that name already exists');
        }

        $isNew = $id === null;
        $name = match ($type) {
            'course' => 'course ' . $values['code'],
            'major' => 'major ' . $values['name'],
            default => 'year and section ' . $values['name'],
        };
        $db->beginTransaction();
        try {
            if ($id !== null) {
                $find = $db->prepare("SELECT {$route['id']} FROM {$route['table']} WHERE {$route['id']} = :id FOR UPDATE");
                $find->execute(['id' => $id]);
                if (!$find->fetch()) {
                    throw new HttpError(404, ($type === 'yearSection' ? 'year and section' : $type) . ' not found');
                }
                [$columns, $params] = self::columnsAndParams($route, $values);
                $params['id'] = $id;
                $update = $db->prepare("UPDATE {$route['table']} SET {$columns} WHERE {$route['id']} = :id");
                $update->execute($params);
                $entityId = $id;
                $event = $type . '_updated';
                $description = "Updated {$name}";
            } else {
                [$columns, $params] = self::columnsAndParams($route, $values);
                $columnNames = implode(', ', $route['fields']);
                $placeholders = implode(', ', array_map(static fn($field) => ':' . $field, $route['fields']));
                $insert = $db->prepare("INSERT INTO {$route['table']} ({$columnNames}) VALUES ({$placeholders})");
                $insert->execute($params);
                $entityId = (string)$db->lastInsertId();
                $event = $type . '_created';
                $description = "Created {$name}";
            }
            Audit::record($db, $actorId, $event, $description, $ip);
            $db->commit();
            return [$isNew ? 201 : 200, ['id' => $entityId]];
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            if ($error instanceof PDOException && $error->getCode() === '23000') {
                throw new HttpError(409, $type === 'course' ? 'That course code already exists' : 'That entry already exists');
            }
            throw $error;
        }
    }

    private static function values(array $route, array $body): array
    {
        $type = $route['type'];
        $name = is_string($body['name'] ?? null) ? trim($body['name']) : '';
        if ($type === 'course') {
            $code = is_string($body['code'] ?? null) ? strtoupper(trim($body['code'])) : '';
            if (!preg_match('/^[A-Z0-9-]{1,20}$/', $code) || $name === '' || strlen($name) > 150) {
                throw new HttpError(400, 'Course code (1-20 letters, numbers, or hyphens) and name (1-150 characters) are required');
            }
            return ['code' => $code, 'name' => $name];
        }
        $parentField = $type === 'major' ? 'courseId' : 'majorId';
        $parentId = trim((string)($body[$parentField] ?? ''));
        $maximum = $type === 'major' ? 150 : 20;
        if (!preg_match('/^[1-9]\d*$/', $parentId) || $name === '' || strlen($name) > $maximum) {
            throw new HttpError(400, ($type === 'major' ? 'Course' : 'Major') . " and a name (1-{$maximum} characters) are required");
        }
        return [$parentField => $parentId, 'name' => $name];
    }

    private static function columnsAndParams(array $route, array $values): array
    {
        $mapping = match ($route['type']) {
            'course' => ['course_code' => $values['code'], 'course_name' => $values['name']],
            'major' => ['course_id' => $values['courseId'], 'major_name' => $values['name']],
            default => ['major_id' => $values['majorId'], 'year_section_name' => $values['name']],
        };
        $assignments = [];
        $params = [];
        foreach ($mapping as $column => $value) {
            $assignments[] = "{$column} = :{$column}";
            $params[$column] = $value;
        }
        return [implode(', ', $assignments), $params];
    }

    private static function parentExists(PDO $db, string $type, string $id): bool
    {
        $query = $type === 'major'
            ? 'SELECT 1 FROM courses WHERE course_id = :id LIMIT 1'
            : 'SELECT 1 FROM majors WHERE major_id = :id LIMIT 1';
        $statement = $db->prepare($query);
        $statement->execute(['id' => $id]);
        return (bool)$statement->fetchColumn();
    }

    private static function nameExists(PDO $db, string $type, array $values, ?string $excludingId): bool
    {
        if ($type === 'course') {
            $statement = $db->prepare(
                'SELECT 1 FROM courses WHERE course_code = :code AND (:excluded_a IS NULL OR course_id <> :excluded_b) LIMIT 1'
            );
            $statement->execute(['code' => $values['code'], 'excluded_a' => $excludingId, 'excluded_b' => $excludingId]);
        } elseif ($type === 'major') {
            $statement = $db->prepare(
                'SELECT 1 FROM majors WHERE course_id = :parent AND LOWER(major_name) = LOWER(:name) '
                . 'AND (:excluded_a IS NULL OR major_id <> :excluded_b) LIMIT 1'
            );
            $statement->execute(['parent' => $values['courseId'], 'name' => $values['name'], 'excluded_a' => $excludingId, 'excluded_b' => $excludingId]);
        } else {
            $statement = $db->prepare(
                'SELECT 1 FROM year_sections WHERE major_id = :parent AND LOWER(year_section_name) = LOWER(:name) '
                . 'AND (:excluded_a IS NULL OR year_section_id <> :excluded_b) LIMIT 1'
            );
            $statement->execute(['parent' => $values['majorId'], 'name' => $values['name'], 'excluded_a' => $excludingId, 'excluded_b' => $excludingId]);
        }
        return (bool)$statement->fetchColumn();
    }

    private static function delete(PDO $db, array $route, string $id, string $actorId, string $ip): array
    {
        [$usageSql, $describe] = self::usage($route['type']);
        $db->beginTransaction();
        try {
            $find = $db->prepare("SELECT {$route['id']}, {$route['fields'][count($route['fields']) - 1]} AS name FROM {$route['table']} WHERE {$route['id']} = :id FOR UPDATE");
            $find->execute(['id' => $id]);
            $entity = $find->fetch();
            if (!$entity) {
                $db->rollBack();
                return [404, ['error' => ($route['type'] === 'yearSection' ? 'year and section' : $route['type']) . ' not found']];
            }
            $usage = $db->prepare($usageSql);
            $usage->execute(['id' => $id]);
            $inUse = $describe($usage->fetch() ?: []);
            if ($inUse !== []) {
                $db->rollBack();
                $label = $route['type'] === 'yearSection' ? 'Year and section entry' : $route['type'];
                return [409, ['error' => $label . ' is used by ' . implode(' and ', $inUse)]];
            }
            $delete = $db->prepare("DELETE FROM {$route['table']} WHERE {$route['id']} = :id");
            $delete->execute(['id' => $id]);
            Audit::record($db, $actorId, $route['type'] . '_deleted', "Deleted {$route['type']} {$entity['name']}", $ip);
            $db->commit();
            return [200, ['success' => true]];
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }
    }

    private static function usage(string $type): array
    {
        return match ($type) {
            'course' => [
                'SELECT COUNT(DISTINCT major.major_id) AS majorCount, COUNT(DISTINCT class.class_id) AS classCount '
                . 'FROM majors major LEFT JOIN year_sections ys ON ys.major_id = major.major_id '
                . 'LEFT JOIN classes class ON class.year_section_id = ys.year_section_id WHERE major.course_id = :id',
                static function (array $row): array {
                    $uses = [];
                    $majors = (int)($row['majorCount'] ?? 0);
                    $classes = (int)($row['classCount'] ?? 0);
                    if ($majors) $uses[] = $majors . ' major' . ($majors === 1 ? '' : 's');
                    if ($classes) $uses[] = $classes . ' class' . ($classes === 1 ? '' : 'es');
                    return $uses;
                },
            ],
            'major' => [
                'SELECT COUNT(DISTINCT ys.year_section_id) AS yearSectionCount, COUNT(DISTINCT class.class_id) AS classCount '
                . 'FROM year_sections ys LEFT JOIN classes class ON class.year_section_id = ys.year_section_id WHERE ys.major_id = :id',
                static function (array $row): array {
                    $uses = [];
                    $sections = (int)($row['yearSectionCount'] ?? 0);
                    $classes = (int)($row['classCount'] ?? 0);
                    if ($sections) $uses[] = $sections . ' year/section' . ($sections === 1 ? '' : 's');
                    if ($classes) $uses[] = $classes . ' class' . ($classes === 1 ? '' : 'es');
                    return $uses;
                },
            ],
            default => [
                'SELECT COUNT(DISTINCT class.class_id) AS classCount, COUNT(DISTINCT u.user_id) AS userCount '
                . 'FROM year_sections ys LEFT JOIN classes class ON class.year_section_id = ys.year_section_id '
                . 'LEFT JOIN users u ON u.year_section_id = ys.year_section_id WHERE ys.year_section_id = :id',
                static function (array $row): array {
                    $uses = [];
                    $classes = (int)($row['classCount'] ?? 0);
                    $users = (int)($row['userCount'] ?? 0);
                    if ($classes) $uses[] = $classes . ' class' . ($classes === 1 ? '' : 'es');
                    if ($users) $uses[] = $users . ' user' . ($users === 1 ? '' : 's');
                    return $uses;
                },
            ],
        };
    }
}
