<?php
declare(strict_types=1);

namespace Edugram;

use PDO;
use PDOException;
use Throwable;

final class Classes
{
    /** Route class requests to the matching handler. */
    public static function handle(PDO $db, string $method, string $path, array $body, array $actor, string $ip): ?array
    {
        if ($path === '/api/classes' && $method === 'GET') {
            return [200, ['classes' => self::list($db, $actor)]];
        }

        if (preg_match('#^/api/classes/([^/]+)/members(?:/bulk|/([^/]+))?$#', $path, $matches)
            || preg_match('#^/api/classes/([^/]+)$#', $path, $matches)) {
            $classId = $matches[1];
            if (!preg_match('/^[1-9]\d*$/', $classId)) {
                throw new HttpError(400, 'A valid class id is required');
            }

            if (str_contains($path, '/members') && $method === 'GET') {
                return self::members($db, $classId, $actor);
            }
            if (str_ends_with($path, '/members/bulk') && $method === 'POST') {
                self::requireAdmin($actor);
                return self::bulk($db, $classId, $body, $actor, $ip);
            }
            if (preg_match('#/members/([^/]+)$#', $path, $memberMatch) && $method === 'DELETE') {
                self::requireAdmin($actor);
                return self::remove($db, $classId, $memberMatch[1], $actor, $ip);
            }
            if ($path === '/api/classes/' . $classId && $method === 'PUT') {
                self::requireAdmin($actor);
                return self::save($db, $classId, $body, $actor, $ip);
            }
            if ($path === '/api/classes/' . $classId && $method === 'DELETE') {
                self::requireAdmin($actor);
                return self::delete($db, $classId, $actor, $ip);
            }
            return null;
        }

        if ($path === '/api/classes' && $method === 'POST') {
            self::requireAdmin($actor);
            return self::save($db, null, $body, $actor, $ip);
        }

        return null;
    }

    /** Allow only admins to change class setup or enrollment. */
    private static function requireAdmin(array $actor): void
    {
        Auth::requireRole($actor, ['admin', 'super_admin']);
    }

    /** Read one class with its academic labels. */
    private static function findClass(PDO $db, string $classId): ?array
    {
        $statement = $db->prepare(
            'SELECT CAST(c.class_id AS CHAR) id, CAST(c.year_section_id AS CHAR) yearSectionId, '
            . 'CAST(c.teacher_id AS CHAR) teacherId, c.subject, co.course_code courseCode, '
            . 'co.course_name courseName, m.major_name majorName, y.year_section_name yearSectionName '
            . 'FROM classes c JOIN year_sections y ON y.year_section_id = c.year_section_id '
            . 'JOIN majors m ON m.major_id = y.major_id JOIN courses co ON co.course_id = m.course_id '
            . 'WHERE c.class_id = :id'
        );
        $statement->execute(['id' => $classId]);
        return $statement->fetch() ?: null;
    }

    /** List classes allowed for the current role. */
    private static function list(PDO $db, array $actor): array
    {
        $filter = '';
        $parameters = [];
        if ($actor['role'] === 'student') {
            $filter = ' WHERE EXISTS (SELECT 1 FROM enrollments own '
                . 'WHERE own.class_id = c.class_id AND own.student_id = :user_id)';
            $parameters['user_id'] = $actor['userId'];
        } elseif ($actor['role'] === 'teacher') {
            $filter = ' WHERE c.teacher_id = :user_id';
            $parameters['user_id'] = $actor['userId'];
        }

        $statement = $db->prepare(
            'SELECT CAST(c.class_id AS CHAR) id, CAST(c.year_section_id AS CHAR) yearSectionId, '
            . 'co.course_code courseCode, co.course_name courseName, m.major_name majorName, '
            . 'y.year_section_name yearSectionName, c.subject, CAST(c.teacher_id AS CHAR) teacherId, '
            . 'CONCAT_WS(" ", NULLIF(t.first_name, ""), NULLIF(t.middle_name, ""), NULLIF(t.last_name, "")) teacherName, '
            . 'COUNT(e.student_id) memberCount FROM classes c JOIN users t ON t.user_id = c.teacher_id '
            . 'JOIN year_sections y ON y.year_section_id = c.year_section_id '
            . 'JOIN majors m ON m.major_id = y.major_id JOIN courses co ON co.course_id = m.course_id '
            . 'LEFT JOIN enrollments e ON e.class_id = c.class_id' . $filter . ' '
            . 'GROUP BY c.class_id, c.year_section_id, co.course_code, co.course_name, m.major_name, '
            . 'y.year_section_name, c.subject, c.teacher_id, t.first_name, t.middle_name, t.last_name '
            . 'ORDER BY co.course_code, m.major_name, y.year_section_name, c.subject, c.class_id'
        );
        $statement->execute($parameters);
        return $statement->fetchAll();
    }

    /** Load class members after checking student and teacher access. */
    private static function members(PDO $db, string $classId, array $actor): array
    {
        $class = self::findClass($db, $classId);
        if ($class === null) {
            return [404, ['error' => 'Class not found']];
        }

        if ($actor['role'] === 'student') {
            $enrollment = $db->prepare(
                'SELECT 1 FROM enrollments WHERE class_id = :class_id AND student_id = :user_id'
            );
            $enrollment->execute(['class_id' => $classId, 'user_id' => $actor['userId']]);
            if (!$enrollment->fetchColumn()) {
                throw new HttpError(403, 'You can view members only for classes you are enrolled in');
            }
        }
        if ($actor['role'] === 'teacher' && $class['teacherId'] !== $actor['userId']) {
            throw new HttpError(403, 'You can view members only for classes assigned to you');
        }

        $statement = $db->prepare(
            'SELECT CAST(u.user_id AS CHAR) id, u.first_name firstName, u.middle_name middleName, '
            . 'u.last_name lastName, u.school_id_number studentId, u.email, r.role_name role, '
            . 'y.year_section_name yearSectionName, m.major_name majorName, co.course_name courseName, '
            . 'co.course_code courseCode FROM enrollments e JOIN users u ON u.user_id = e.student_id '
            . 'JOIN roles r ON r.role_id = u.role_id LEFT JOIN year_sections y ON y.year_section_id = u.year_section_id '
            . 'LEFT JOIN majors m ON m.major_id = y.major_id LEFT JOIN courses co ON co.course_id = m.course_id '
            . 'WHERE e.class_id = :class_id ORDER BY u.last_name, u.first_name, u.user_id'
        );
        $statement->execute(['class_id' => $classId]);
        $members = $statement->fetchAll();

        if ($actor['role'] === 'student') {
            $members = array_map(
                static fn(array $member): array => [
                    'firstName' => $member['firstName'],
                    'middleName' => $member['middleName'],
                    'lastName' => $member['lastName'],
                ],
                $members
            );
            $class = array_intersect_key(
                $class,
                array_flip(['id', 'courseCode', 'courseName', 'majorName', 'yearSectionName', 'subject'])
            );
        }

        return [200, ['class' => $class, 'members' => $members]];
    }

    /** Validate the year-section, teacher, and subject fields. */
    private static function validate(PDO $db, array $body): array
    {
        $yearSectionId = trim((string)($body['yearSectionId'] ?? ''));
        $teacherId = trim((string)($body['teacherId'] ?? ''));
        $subject = is_string($body['subject'] ?? null) ? trim($body['subject']) : '';

        if (!preg_match('/^[1-9]\d*$/', $yearSectionId)) {
            throw new HttpError(400, 'Select a valid year and section');
        }
        $section = $db->prepare('SELECT 1 FROM year_sections WHERE year_section_id = :id');
        $section->execute(['id' => $yearSectionId]);
        if (!$section->fetchColumn()) {
            throw new HttpError(400, 'Select a valid year and section');
        }
        if ($subject === '' || strlen($subject) > 150) {
            throw new HttpError(400, 'Subject is required and must be 150 characters or fewer');
        }
        if (!preg_match('/^[1-9]\d*$/', $teacherId)) {
            throw new HttpError(400, 'Select a valid teacher');
        }
        $teacher = $db->prepare(
            'SELECT r.role_name FROM users u JOIN roles r ON r.role_id = u.role_id WHERE u.user_id = :id'
        );
        $teacher->execute(['id' => $teacherId]);
        if ($teacher->fetchColumn() !== 'teacher') {
            throw new HttpError(400, 'The selected user is not a teacher');
        }

        return [$yearSectionId, $teacherId, $subject];
    }

    /** Create or update a class and apply requested enrollments in one transaction. */
    private static function save(PDO $db, ?string $classId, array $body, array $actor, string $ip): array
    {
        [$yearSectionId, $teacherId, $subject] = self::validate($db, $body);
        $isNew = $classId === null;
        $db->beginTransaction();

        try {
            if ($isNew) {
                $insert = $db->prepare(
                    'INSERT INTO classes (year_section_id, teacher_id, subject) '
                    . 'VALUES (:year_section_id, :teacher_id, :subject)'
                );
                $insert->execute([
                    'year_section_id' => $yearSectionId,
                    'teacher_id' => $teacherId,
                    'subject' => $subject,
                ]);
                $classId = (string)$db->lastInsertId();
                Audit::record($db, $actor['userId'], 'class_created', "Created class $classId: $subject", $ip);
                Audit::record($db, $actor['userId'], 'class_teacher_assigned', "Assigned user $teacherId as teacher of class $classId", $ip);

                if (($body['includeSectionStudents'] ?? false) === true) {
                    $students = $db->prepare(
                        "SELECT u.user_id FROM users u JOIN roles r ON r.role_id = u.role_id "
                        . "WHERE r.role_name = 'student' AND u.year_section_id = :year_section_id "
                        . 'ORDER BY u.user_id FOR UPDATE'
                    );
                    $students->execute(['year_section_id' => $yearSectionId]);
                    foreach ($students->fetchAll(PDO::FETCH_COLUMN) as $studentId) {
                        self::insertEnrollment($db, $classId, (string)$studentId);
                        Audit::record($db, $actor['userId'], 'class_member_added',
                            "Enrolled user $studentId in class $classId from matching year and section", $ip);
                    }
                }

                $report = self::enrollNumbers(
                    $db,
                    $classId,
                    is_string($body['studentIdNumbers'] ?? null) ? $body['studentIdNumbers'] : '',
                    (string)$actor['userId'],
                    $ip
                );
            } else {
                $lock = $db->prepare(
                    'SELECT teacher_id, year_section_id, subject FROM classes WHERE class_id = :id FOR UPDATE'
                );
                $lock->execute(['id' => $classId]);
                $oldClass = $lock->fetch();
                if (!$oldClass) {
                    $db->rollBack();
                    return [404, ['error' => 'Class not found']];
                }

                $update = $db->prepare(
                    'UPDATE classes SET year_section_id = :year_section_id, teacher_id = :teacher_id, '
                    . 'subject = :subject WHERE class_id = :id'
                );
                $update->execute([
                    'year_section_id' => $yearSectionId,
                    'teacher_id' => $teacherId,
                    'subject' => $subject,
                    'id' => $classId,
                ]);
                Audit::record($db, $actor['userId'], 'class_updated', "Updated class $classId", $ip);
                if ((string)$oldClass['teacher_id'] !== $teacherId) {
                    Audit::record($db, $actor['userId'], 'class_teacher_assigned',
                        "Assigned user $teacherId as teacher of class $classId", $ip);
                }
                if ((string)$oldClass['year_section_id'] !== $yearSectionId) {
                    Audit::record($db, $actor['userId'], 'class_year_section_changed',
                        "Changed year and section for class $classId", $ip);
                }
                $report = [];
            }

            $db->commit();
        } catch (PDOException $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            if ($error->getCode() === '23000') {
                throw new HttpError(409, 'A class already exists for this year and section, subject, and teacher');
            }
            throw $error;
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }

        if ($isNew) {
            return [201, ['class' => self::findClass($db, $classId), 'report' => $report]];
        }
        return [200, ['class' => self::findClass($db, $classId)]];
    }

    /** Add one enrollment row with a prepared statement. */
    private static function insertEnrollment(PDO $db, string $classId, string $studentId): void
    {
        $insert = $db->prepare('INSERT INTO enrollments (class_id, student_id) VALUES (:class_id, :student_id)');
        $insert->execute(['class_id' => $classId, 'student_id' => $studentId]);
    }

    /** Enroll students by school ID and return a result for each supplied ID. */
    private static function enrollNumbers(PDO $db, string $classId, string $numbers, string $actorId, string $ip): array
    {
        $studentIds = array_values(array_unique(array_filter(preg_split('/[\s,]+/', $numbers) ?: [])));
        $report = [];
        foreach ($studentIds as $studentId) {
            $find = $db->prepare(
                'SELECT u.user_id, r.role_name role FROM users u JOIN roles r ON r.role_id = u.role_id '
                . 'WHERE u.school_id_number = :student_id FOR UPDATE'
            );
            $find->execute(['student_id' => $studentId]);
            $student = $find->fetch();
            if (!$student) {
                $report[] = ['studentId' => $studentId, 'status' => 'not found'];
                continue;
            }
            if ($student['role'] !== 'student') {
                $report[] = ['studentId' => $studentId, 'status' => 'not a student'];
                continue;
            }

            $exists = $db->prepare(
                'SELECT 1 FROM enrollments WHERE class_id = :class_id AND student_id = :student_id'
            );
            $exists->execute(['class_id' => $classId, 'student_id' => $student['user_id']]);
            if ($exists->fetchColumn()) {
                $report[] = ['studentId' => $studentId, 'status' => 'already in this class'];
                continue;
            }

            $databaseStudentId = (string)$student['user_id'];
            self::insertEnrollment($db, $classId, $databaseStudentId);
            Audit::record($db, $actorId, 'class_member_added',
                "Enrolled user $databaseStudentId in class $classId", $ip);
            $report[] = ['studentId' => $studentId, 'status' => 'added'];
        }
        return $report;
    }

    /** Bulk-enroll student IDs while locking the class row. */
    private static function bulk(PDO $db, string $classId, array $body, array $actor, string $ip): array
    {
        $numbers = $body['studentIdNumbers'] ?? '';
        if (!is_string($numbers) || !count(array_filter(preg_split('/[\s,]+/', $numbers) ?: []))) {
            throw new HttpError(400, 'Enter one or more student ID numbers');
        }

        $db->beginTransaction();
        try {
            $lock = $db->prepare('SELECT class_id FROM classes WHERE class_id = :id FOR UPDATE');
            $lock->execute(['id' => $classId]);
            if (!$lock->fetch()) {
                throw new HttpError(404, 'Class not found');
            }
            $report = self::enrollNumbers($db, $classId, $numbers, (string)$actor['userId'], $ip);
            $db->commit();
            $members = self::members($db, $classId, ['role' => 'admin', 'userId' => $actor['userId']])[1]['members'];
            return [200, ['report' => $report, 'members' => $members]];
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }
    }

    /** Remove one student enrollment and return the updated member list. */
    private static function remove(PDO $db, string $classId, string $userId, array $actor, string $ip): array
    {
        if (!preg_match('/^[1-9]\d*$/', $userId)) {
            throw new HttpError(400, 'A valid user id is required');
        }
        $db->beginTransaction();
        try {
            $delete = $db->prepare('DELETE FROM enrollments WHERE class_id = :class_id AND student_id = :user_id');
            $delete->execute(['class_id' => $classId, 'user_id' => $userId]);
            if (!$delete->rowCount()) {
                $db->rollBack();
                return [404, ['error' => 'Student is not enrolled in this class']];
            }
            Audit::record($db, $actor['userId'], 'class_member_removed', "Removed user $userId from class $classId", $ip);
            $db->commit();
            $members = self::members($db, $classId, ['role' => 'admin', 'userId' => $actor['userId']])[1]['members'];
            return [200, ['members' => $members]];
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }
    }

    /** Delete a class and record removal of each enrollment in the audit log. */
    private static function delete(PDO $db, string $classId, array $actor, string $ip): array
    {
        $db->beginTransaction();
        try {
            $enrollmentQuery = $db->prepare('SELECT student_id FROM enrollments WHERE class_id = :id FOR UPDATE');
            $enrollmentQuery->execute(['id' => $classId]);
            $studentIds = $enrollmentQuery->fetchAll(PDO::FETCH_COLUMN);

            $classQuery = $db->prepare('SELECT subject FROM classes WHERE class_id = :id FOR UPDATE');
            $classQuery->execute(['id' => $classId]);
            $subject = $classQuery->fetchColumn();
            if ($subject === false) {
                $db->rollBack();
                return [404, ['error' => 'Class not found']];
            }

            foreach ($studentIds as $studentId) {
                Audit::record($db, $actor['userId'], 'class_member_removed',
                    "Removed user $studentId from class $classId", $ip);
            }
            $delete = $db->prepare('DELETE FROM classes WHERE class_id = :id');
            $delete->execute(['id' => $classId]);
            Audit::record($db, $actor['userId'], 'class_deleted', "Deleted class $classId: $subject", $ip);
            $db->commit();
            return [200, ['success' => true]];
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }
    }
}
