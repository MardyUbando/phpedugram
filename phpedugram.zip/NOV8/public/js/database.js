'use strict';

function decodeJwtPayload(token) {
  try {
    const segment = token.split('.')[1];
    if (!segment) return null;
    const base64 = segment.replace(/-/g, '+').replace(/_/g, '/');
    const padded = base64.padEnd(Math.ceil(base64.length / 4) * 4, '=');
    const bytes = Uint8Array.from(atob(padded), character => character.charCodeAt(0));
    const payload = JSON.parse(new TextDecoder().decode(bytes));
    return Number(payload.exp) > Math.floor(Date.now() / 1000) ? payload : null;
  } catch {
    return null;
  }
}

function setupPasswordStrength(inputId, meterId) {
  const input = document.getElementById(inputId);
  const meter = document.getElementById(meterId);
  if (!input || !meter) return;
  const update = () => {
    const password = input.value;
    const score = (password.length >= 8 ? 1 : 0)
      + (password.length >= 12 ? 1 : 0)
      + (/[a-z]/.test(password) && /[A-Z]/.test(password) ? 1 : 0)
      + (/\d/.test(password) ? 1 : 0)
      + (/[^A-Za-z0-9]/.test(password) ? 1 : 0);
    const strength = score >= 5 ? 'Strong' : score >= 3 ? 'Medium' : 'Weak';
    meter.textContent = password
      ? `Strength: ${strength}${/[^A-Za-z0-9]/.test(password) ? '' : ' — adding a symbol may improve strength.'}`
      : 'Strength: Weak';
  };
  input.addEventListener('input', update);
  update();
}

function normalizeData(data) {
  return {
    users: Array.isArray(data?.users) ? data.users : [],
    assignments: Array.isArray(data?.assignments) ? data.assignments : [],
    submissions: Array.isArray(data?.submissions) ? data.submissions : [],
    drafts: data?.drafts && typeof data.drafts === 'object' ? data.drafts : {},
  };
}

function loadDatabase() {
  const token = sessionStorage.getItem('edugram_jwt');
  if (!token || window.location.pathname.endsWith('/index.html') || window.location.pathname.endsWith('/index.php')) return normalizeData({});
  const request = new XMLHttpRequest();
  try {
    request.open('GET', '/api/data', false);
    request.setRequestHeader('Authorization', 'Bearer ' + token);
    request.send(null);
    if (request.status >= 200 && request.status < 300) {
      return normalizeData(JSON.parse(request.responseText));
    }
    throw new Error(`Dashboard data request failed with status ${request.status}`);
  } catch (error) {
    console.error('Dashboard data could not be loaded from the server', error);
    sessionStorage.clear();
    window.alert('Dashboard data could not be loaded. Please sign in again.');
    window.location.href = 'index.php';
    return normalizeData({});
  }
}

let db = loadDatabase();
let USERS = db.users;
let ASSIGNMENTS = db.assignments;
let SUBMISSIONS = db.submissions;
let DRAFTS = db.drafts;

console.log('Database connected:', USERS.length, 'users loaded');
