<?php
declare(strict_types=1);

use Edugram\Db;
use Edugram\Auth;
use Edugram\HttpError;
use Edugram\Otp;
use Edugram\Users;
use Edugram\Academic;
use Edugram\Classes;
use Edugram\Coursework;
use Edugram\Ai;
use Dotenv\Dotenv;

ini_set('display_errors', '0');
require dirname(__DIR__) . '/vendor/autoload.php';

date_default_timezone_set('Asia/Manila');

$root = dirname(__DIR__);
if (is_file($root . '/.env')) {
    Dotenv::createImmutable($root)->safeLoad();
}
$_ENV['APP_DEBUG'] ??= 'false';

function respondJson(int $status, array $body): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function readJsonBody(): array
{
    $body = json_decode(file_get_contents('php://input') ?: '', true);
    return is_array($body) ? $body : [];
}

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

if (str_starts_with($path, '/api/')) {
    header('Content-Type: application/json; charset=utf-8');
    try {
        if ($method === 'POST' && $path === '/api/send-otp') {
            $body = readJsonBody();
            Otp::send(
                Db::connect(),
                is_string($body['email'] ?? null) ? $body['email'] : '',
                (string)($_SERVER['REMOTE_ADDR'] ?? '')
            );
            respondJson(200, ['success' => true, 'message' => 'OTP sent successfully!']);
        }
        if ($method === 'POST' && $path === '/api/verify-otp') {
            $body = readJsonBody();
            $email = is_string($body['email'] ?? null) ? strtolower(trim($body['email'])) : '';
            $code = is_string($body['otp_code'] ?? null) || is_numeric($body['otp_code'] ?? null)
                ? (string)$body['otp_code'] : '';
            if ($email === '' || $code === '') {
                throw new HttpError(400, 'Email and OTP code are required');
            }
            $db = Db::connect();
            $otpId = Otp::verify($db, $email, $code, 'OTP has expired.', 'Invalid verification code.');
            Otp::consume($db, $otpId);
            respondJson(200, ['success' => true, 'message' => 'OTP verified successfully!']);
        }
        if ($method === 'POST' && $path === '/api/login') {
            $body = readJsonBody();
            $result = Auth::login(
                Db::connect(),
                $body,
                (string)($_SERVER['REMOTE_ADDR'] ?? ''),
                (string)($_ENV['JWT_SECRET'] ?? '')
            );
            respondJson(200, $result);
        }
        if ($method === 'POST' && $path === '/api/register') {
            $body = readJsonBody();
            $result = Auth::register(
                Db::connect(),
                $body,
                (string)($_SERVER['REMOTE_ADDR'] ?? ''),
                (string)($_ENV['JWT_SECRET'] ?? '')
            );
            respondJson(201, $result);
        }
        if ($method === 'POST' && $path === '/api/forgot-password/reset') {
            $result = Auth::resetPassword(
                Db::connect(),
                readJsonBody(),
                (string)($_SERVER['REMOTE_ADDR'] ?? '')
            );
            respondJson(200, $result);
        }
        if (str_starts_with($path, '/api/users/')) {
            $db = Db::connect();
            $actor = Auth::requireAuth(
                $db,
                Auth::bearerHeader(),
                (string)($_ENV['JWT_SECRET'] ?? '')
            );
            $result = Users::handle($db, $method, $path, readJsonBody(), $actor, (string)($_SERVER['REMOTE_ADDR'] ?? ''));
            if ($result === null) {
                respondJson(404, ['error' => 'Not found']);
            }
            respondJson($result[0], $result[1]);
        }
        if ($path === '/api/academic/options' && $method === 'GET') {
            $result = Academic::handle(Db::connect(), $method, $path, [], null, (string)($_SERVER['REMOTE_ADDR'] ?? ''));
            respondJson($result[0], $result[1]);
        }
        if (str_starts_with($path, '/api/academic/')) {
            $db = Db::connect();
            $actor = Auth::requireAuth(
                $db,
                Auth::bearerHeader(),
                (string)($_ENV['JWT_SECRET'] ?? '')
            );
            $result = Academic::handle($db, $method, $path, readJsonBody(), $actor, (string)($_SERVER['REMOTE_ADDR'] ?? ''));
            if ($result === null) {
                respondJson(404, ['error' => 'Not found']);
            }
            respondJson($result[0], $result[1]);
        }
        if ($path === '/api/classes' || str_starts_with($path, '/api/classes/')) {
            $db = Db::connect();
            $actor = Auth::requireAuth($db, Auth::bearerHeader(), (string)($_ENV['JWT_SECRET'] ?? ''));
            $result = Classes::handle($db, $method, $path, readJsonBody(), $actor, (string)($_SERVER['REMOTE_ADDR'] ?? ''));
            if ($result === null) {
                respondJson(404, ['error' => 'Not found']);
            }
            respondJson($result[0], $result[1]);
        }
        if (in_array($path, ['/api/data','/api/assignments','/api/drafts','/api/submissions'], true)
            || preg_match('#^/api/(assignments|drafts|submissions)/#', $path)) {
            $db = Db::connect();
            $actor = Auth::requireAuth($db, Auth::bearerHeader(), (string)($_ENV['JWT_SECRET'] ?? ''));
            $result = Coursework::handle($db, $method, $path, readJsonBody(), $actor, (string)($_SERVER['REMOTE_ADDR'] ?? ''));
            if ($result === null) {
                respondJson(404, ['error' => 'Not found']);
            }
            respondJson($result[0], $result[1]);
        }
        if (str_starts_with($path, '/api/ai/')) {
            $db=Db::connect();
            $actor = Auth::requireAuth($db, Auth::bearerHeader(), (string)($_ENV['JWT_SECRET'] ?? ''));
            $result=Ai::handle($path,readJsonBody(),$actor);
            if ($result === null) {
                respondJson(404, ['error' => 'Not found']);
            }
            respondJson($result[0], $result[1]);
        }
        if ($method === 'GET' && $path === '/api/health') {
            $health = Db::connect()->prepare('SELECT 1');
            $health->execute();
            respondJson(200, ['success' => true, 'message' => 'EDUGRAM PHP API is healthy']);
        }
        respondJson(404, ['error' => 'Not found']);
    } catch (HttpError $error) {
        respondJson($error->statusCode, ['error' => $error->getMessage()]);
    } catch (Throwable $error) {
        if ($error instanceof PDOException && in_array((string)$error->getCode(), ['42S02', '42S22'], true)) {
            error_log('Database schema is missing a required table or column: ' . $error->getMessage());
        } else {
            error_log('API request failed: ' . $error->getMessage());
        }
        if ($path === '/api/register' && $error instanceof PDOException && $error->getCode() === '23000') {
            respondJson(409, ['error' => 'Email, phone, or student ID is already registered']);
        }
        $messages = [
            '/api/login' => 'Login failed',
            '/api/register' => 'Failed to register',
            '/api/send-otp' => 'Failed to send OTP',
            '/api/verify-otp' => 'Server error during verification',
            '/api/forgot-password/reset' => 'Failed to reset password',
        ];
        $message = $messages[$path] ?? 'Service unavailable';
        if (str_starts_with($path, '/api/users/')) {
            $message = str_ends_with($path, '/password') ? 'Failed to update password'
                : (str_ends_with($path, '/role') ? 'Failed to update user role'
                    : (str_ends_with($path, '/status') ? 'Failed to update account status'
                        : (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') === 'DELETE' ? 'Failed to delete user' : 'Failed to update profile')));
        }
        if (str_starts_with($path, '/api/academic/')) {
            $message = $method === 'GET' ? 'Failed to load academic options'
                : (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') === 'DELETE' ? 'Failed to delete academic entry'
                    : ($method === 'POST' ? 'Failed to create academic entry' : 'Failed to update academic entry'));
        }
        respondJson(500, ['error' => $message]);
    }
}

if ($path === '/' || $path === '/index.php') {
    header('Location: /edu_php/index.php', true, 302);
    exit;
}

http_response_code(404);
header('Content-Type: text/plain; charset=utf-8');
echo 'Not found';
