'use strict';

const jwt = sessionStorage.getItem('edugram_jwt');
const userRole = sessionStorage.getItem('edugram_user_role');
const decoded = jwt ? decodeJwtPayload(jwt) : null;

if (!decoded || userRole !== 'teacher') window.location.href = 'index.php';

let currentUser = USERS.find(user => user.id === (decoded?.userId || decoded?.sub));
let activeSubmissionId = null;
let activeAssignmentId = null;
const TEACHER_PAGE_SIZE = 8;
let teacherClassPage = 1;
let teacherAssignmentPage = 1;
let teacherSubmissionPage = 1;
let teacherSubmissionFilter = 'all';

if (!currentUser) {
  sessionStorage.clear();
  window.location.href = 'index.php';
}

const $ = id => document.getElementById(id);
const html = value => String(value ?? '').replace(/[&<>"']/g, char => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[char]));
const textFromHtml = value => {
  const div = document.createElement('div');
  div.innerHTML = value || '';
  return div.textContent || div.innerText || '';
};
const formatDate = value => value ? new Date(value).toLocaleDateString('en-PH', {
  month: 'short', day: 'numeric', year: 'numeric',
}) : 'No date';

function initTeacherDashboard() {
  $('auth-screen')?.style && ($('auth-screen').style.display = 'none');
  $('teacher-screen')?.style && ($('teacher-screen').style.display = 'flex');
  updateChrome();
  setupNavigation();
  setupDashboardInteractions();
  setupCreateForm();
  setupSubmissions();
  setupAssignmentEditor();
  setupProfile();
  renderAll();
  refreshTeacherClasses();
  setupPasswordStrength('profile-pass', 'profile-password-strength');
  $('teacher-logout')?.addEventListener('click', logout);
  $('teacher-menu-toggle')?.addEventListener('click', () => $('teacher-sidebar')?.classList.toggle('active'));
}

function updateChrome() {
  const initials = ((currentUser.firstName?.[0] || 'T') + (currentUser.lastName?.[0] || '')).toUpperCase();
  if ($('teacher-avatar')) $('teacher-avatar').textContent = initials;
  if ($('teacher-name')) $('teacher-name').textContent = [currentUser.firstName, currentUser.middleName, currentUser.lastName].filter(Boolean).join(' ');
  if ($('teacher-welcome-name')) $('teacher-welcome-name').textContent = currentUser.firstName.split(' ')[0];
}

function setupNavigation() {
  const titles = {
    't-overview': 'Dashboard',
    't-create': 'Create Assignment',
    't-submissions': 'Submissions',
    't-assignments': 'My Assignments',
    't-sections': 'Classes',
    't-profile': 'My Profile',
  };
  document.querySelectorAll('.nav-item, .t-nav-link').forEach(item => {
    item.addEventListener('click', event => {
      event.preventDefault();
      showPanel(item.dataset.panel, titles[item.dataset.panel]);
    });
  });
}

function setupDashboardInteractions() {
  const navigate = target => {
    const panelId = target.dataset.dashboardPanel;
    if (!panelId) return;
    const titles = { 't-sections': 'Classes', 't-assignments': 'My Assignments', 't-submissions': 'Submissions' };
    showPanel(panelId, titles[panelId] || 'Dashboard');
    const filter = target.dataset.dashboardFilter;
    if (filter) document.querySelector(`#t-submissions .filter-btn[data-tfilter="${filter}"]`)?.click();
  };
  document.addEventListener('click', event => {
    const target = event.target.closest('[data-dashboard-panel]');
    if (!target) return;
    event.preventDefault();
    navigate(target);
  });
  document.addEventListener('keydown', event => {
    if (!['Enter', ' '].includes(event.key)) return;
    const target = event.target.closest('[data-dashboard-panel]');
    if (!target || target.tagName === 'A' || target.tagName === 'BUTTON') return;
    event.preventDefault();
    navigate(target);
  });
}

async function refreshTeacherClasses() {
  try {
    const headers = { Authorization: `Bearer ${sessionStorage.getItem('edugram_jwt') || ''}` };
    const response = await fetch('/api/classes', { headers });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not load classes');
    const ownClasses = result.classes;
    const all = await Promise.all(ownClasses.map(async classInfo => {
      const membersResponse = await fetch(`/api/classes/${encodeURIComponent(classInfo.id)}/members`, { headers });
      const membersResult = await membersResponse.json();
      if (!membersResponse.ok) throw new Error(membersResult.error || `Could not load members for ${classInfo.subject}`);
      return { ...classInfo, members: membersResult.members };
    }));
    $('teacher-classes-error')?.classList.add('hidden');
    renderTeacherClasses(all);
  } catch (error) {
    console.error('Teacher classes refresh failed', error);
    if ($('teacher-classes-error')) {
      $('teacher-classes-error').textContent = error.message || 'Could not refresh classes.';
      $('teacher-classes-error').classList.remove('hidden');
    }
  }
}

function showPanel(panelId, title = 'Dashboard') {
  document.querySelectorAll('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.panel === panelId));
  document.querySelectorAll('.panel').forEach(panel => panel.classList.toggle('active', panel.id === panelId));
  if ($('teacher-panel-title')) $('teacher-panel-title').textContent = title;
  $('teacher-sidebar')?.classList.remove('active');
  if (panelId === 't-profile') populateProfile();
}

function renderAll() {
  updateStats();
  renderRecentSubmissions();
  renderSubmissions();
  renderAssignments();
  populateProfile();
}

function updateStats() {
  const pending = SUBMISSIONS.filter(s => s.status === 'submitted').length;
  if ($('t-pending-count')) $('t-pending-count').textContent = pending;
  if ($('t-pending-review')) $('t-pending-review').textContent = pending;
  if ($('t-total-students')) $('t-total-students').textContent = USERS.filter(u => u.role === 'student').length;
  if ($('t-total-assignments')) $('t-total-assignments').textContent = ASSIGNMENTS.length;
  if ($('t-graded')) $('t-graded').textContent = SUBMISSIONS.filter(s => s.status === 'graded').length;
}

function setupCreateForm() {
  $('create-assignment-btn')?.addEventListener('click', createAssignment);
  $('reset-assignment-btn')?.addEventListener('click', resetCreateForm);
  $('create-assignment-close')?.addEventListener('click', closeCreateAssignmentModal);
  $('create-assignment-cancel')?.addEventListener('click', closeCreateAssignmentModal);
  $('create-assignment-backdrop')?.addEventListener('click', closeCreateAssignmentModal);
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && $('t-create')?.classList.contains('active')) closeCreateAssignmentModal();
  });
  $('new-assignment-pdf')?.addEventListener('change', async event => {
    const file = event.target.files?.[0];
    if ($('new-assignment-pdf-name')) $('new-assignment-pdf-name').textContent = file?.name || 'No file selected';
    if (!file) return;
    if (file.size > 5 * 1024 * 1024 || !file.name.toLowerCase().endsWith('.pdf')) {
      event.target.value = '';
      $('new-assignment-pdf-name').textContent = 'No file selected';
      return showFormMessage('create-error', file.size > 5 * 1024 * 1024 ? 'PDF handouts must be 5 MB or smaller.' : 'Please choose a PDF file.');
    }
    const signature = new TextDecoder().decode(new Uint8Array(await file.slice(0, 5).arrayBuffer()));
    if (signature !== '%PDF-') {
      event.target.value = '';
      $('new-assignment-pdf-name').textContent = 'No file selected';
      showFormMessage('create-error', 'This file is not a valid PDF.');
    }
  });
}

function closeCreateAssignmentModal() {
  showPanel('t-overview', 'Dashboard');
}

async function createAssignment() {
  const title = $('new-assignment-title')?.value.trim();
  const due = $('new-assignment-due')?.value;
  const desc = $('new-assignment-desc')?.value.trim();
  if (!title || !due || !desc) return showFormMessage('create-error', 'Title, due date, and prompt are required.');

  try {
    const attachmentFile = $('new-assignment-pdf')?.files?.[0];
    const attachment = attachmentFile ? {
      name: attachmentFile.name,
      data: await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
        reader.onerror = () => reject(new Error('Could not read the PDF attachment.'));
        reader.readAsDataURL(attachmentFile);
      }),
    } : null;
    const response = await fetch('/api/assignments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${jwt}` },
      body: JSON.stringify({
        title,
        subject: $('new-assignment-subject')?.value.trim() || '',
        description: desc,
        rubric: $('new-assignment-rubric')?.value.trim() || '',
        type: $('new-assignment-type')?.value || 'essay',
        class: '',
        forAll: true,
        minWords: Number($('new-assignment-words')?.value || 250),
        dueDate: new Date(due + 'T23:59:00').toISOString(),
        attachment,
      }),
    });
    const result = await response.json();
    if (!response.ok) return showFormMessage('create-error', result.error || 'Could not publish assignment.');
    ASSIGNMENTS.unshift(result.assignment);
    resetCreateForm();
    showFormMessage('create-success', 'Assignment published.');
    renderAll();
    showPanel('t-assignments', 'My Assignments');
  } catch (error) {
    console.error('Assignment create failed', error);
    showFormMessage('create-error', 'Could not reach the server. Assignment was not saved.');
  }
}

function resetCreateForm() {
  ['new-assignment-title', 'new-assignment-subject', 'new-assignment-due', 'new-assignment-words', 'new-assignment-desc', 'new-assignment-rubric', 'new-assignment-pdf'].forEach(id => {
    if ($(id)) $(id).value = '';
  });
  if ($('new-assignment-pdf-name')) $('new-assignment-pdf-name').textContent = 'No file selected';
  $('create-error')?.classList.add('hidden');
}

function showFormMessage(id, message) {
  const el = $(id);
  if (!el) return;
  el.textContent = message;
  el.classList.remove('hidden');
  setTimeout(() => el.classList.add('hidden'), 3000);
}

function setupSubmissions() {
  document.querySelectorAll('#t-submissions .filter-btn').forEach(button => {
    button.addEventListener('click', () => {
      document.querySelectorAll('#t-submissions .filter-btn').forEach(btn => btn.classList.remove('active'));
      button.classList.add('active');
      teacherSubmissionFilter = button.dataset.tfilter || 'all';
      teacherSubmissionPage = 1;
      renderSubmissions(teacherSubmissionFilter);
    });
  });
  $('modal-close')?.addEventListener('click', closeFeedbackModal);
  $('modal-cancel')?.addEventListener('click', closeFeedbackModal);
  $('modal-submit-feedback')?.addEventListener('click', submitFeedback);
  $('ai-generate-feedback-btn')?.addEventListener('click', generateFeedback);
  document.querySelectorAll('.ftag').forEach(tag => tag.addEventListener('click', () => {
    const box = $('modal-feedback-text');
    if (box) box.value = `${box.value}${box.value ? '\n' : ''}${tag.dataset.tag}`;
  }));
}

function renderRecentSubmissions() {
  const container = $('t-recent-submissions');
  if (!container) return;
  const recent = [...SUBMISSIONS].sort((a, b) => new Date(b.submittedAt || 0) - new Date(a.submittedAt || 0)).slice(0, 4);
  container.innerHTML = recent.length ? recent.map(submissionRow).join('') : '<p class="empty-hint">No submissions yet.</p>';
  bindReviewButtons(container);
  bindClickableSubmissionCards(container);
}

function renderSubmissions(filter = 'all') {
  const container = $('submissions-list');
  if (!container) return;
  teacherSubmissionFilter = filter;
  let submissions = [...SUBMISSIONS].sort((a, b) => new Date(b.submittedAt || b.updatedAt || 0) - new Date(a.submittedAt || a.updatedAt || 0));
  if (filter === 'pending') submissions = submissions.filter(s => s.status === 'submitted');
  if (filter === 'graded') submissions = submissions.filter(s => s.status === 'graded');
  const pages = Math.max(1, Math.ceil(submissions.length / TEACHER_PAGE_SIZE));
  teacherSubmissionPage = Math.min(teacherSubmissionPage, pages);
  const visible = submissions.slice((teacherSubmissionPage - 1) * TEACHER_PAGE_SIZE, teacherSubmissionPage * TEACHER_PAGE_SIZE);
  container.innerHTML = visible.length ? visible.map(sub => {
    const assignment = ASSIGNMENTS.find(item => item.id === sub.assignmentId);
    return `<tr><td><strong>${html(sub.studentName || 'Student')}</strong></td><td>${html(assignment?.title || 'Assignment')}</td><td>${formatDate(sub.submittedAt || sub.updatedAt)}</td><td><span class="status-badge ${html(sub.status)}">${html(sub.status)}</span></td><td>${html(sub.grade || '—')}</td><td><button type="button" class="btn-primary small review-submission" data-id="${html(sub.id)}">${sub.status === 'graded' ? 'Edit Feedback' : 'Review'}</button></td></tr>`;
  }).join('') : '<tr><td colspan="6" class="teacher-empty-row">No submissions found.</td></tr>';
  renderTeacherPagination('submissions-pagination', submissions.length, teacherSubmissionPage, page => {
    teacherSubmissionPage = page;
    renderSubmissions(teacherSubmissionFilter);
  });
  bindReviewButtons(container);
}

function renderTeacherPagination(id, total, page, setPage) {
  const element = $(id);
  if (!element) return;
  const pages = Math.max(1, Math.ceil(total / TEACHER_PAGE_SIZE));
  const start = total ? (page - 1) * TEACHER_PAGE_SIZE + 1 : 0;
  const end = Math.min(page * TEACHER_PAGE_SIZE, total);
  element.innerHTML = `<span>Showing ${start}–${end} of ${total}</span><div class="teacher-pagination-controls"><button type="button" class="teacher-page-button" data-page="${page - 1}" ${page <= 1 ? 'disabled' : ''}>Previous</button><span>Page ${page} of ${pages}</span><button type="button" class="teacher-page-button" data-page="${page + 1}" ${page >= pages ? 'disabled' : ''}>Next</button></div>`;
  element.querySelectorAll('[data-page]').forEach(button => button.addEventListener('click', () => setPage(Number(button.dataset.page))));
}

function renderTeacherClasses(classes) {
  const tbody = $('teacher-classes-list');
  if (!tbody) return;
  const pages = Math.max(1, Math.ceil(classes.length / TEACHER_PAGE_SIZE));
  teacherClassPage = Math.min(teacherClassPage, pages);
  const visible = classes.slice((teacherClassPage - 1) * TEACHER_PAGE_SIZE, teacherClassPage * TEACHER_PAGE_SIZE);
  tbody.innerHTML = visible.length ? visible.map(classInfo => {
    const roster = classInfo.members.length
      ? `<details class="teacher-roster"><summary>View ${classInfo.members.length} student${classInfo.members.length === 1 ? '' : 's'}</summary><ul>${classInfo.members.map(member => `<li><strong>${html([member.firstName, member.middleName, member.lastName].filter(Boolean).join(' '))}</strong><small>${html(member.studentId || 'No ID')} · ${html(member.email || '')}</small></li>`).join('')}</ul></details>`
      : '<span class="teacher-record-muted">No students assigned</span>';
    return `<tr><td>${html(classInfo.courseCode)}</td><td>${html(classInfo.majorName)}</td><td>${html(classInfo.yearSectionName)}</td><td><strong>${html(classInfo.subject)}</strong></td><td>${roster}</td></tr>`;
  }).join('') : '<tr><td colspan="5" class="teacher-empty-row">No classes assigned to you.</td></tr>';
  renderTeacherPagination('classes-pagination', classes.length, teacherClassPage, page => {
    teacherClassPage = page;
    renderTeacherClasses(classes);
  });
}
function submissionRow(sub) {
  const assignment = ASSIGNMENTS.find(a => a.id === sub.assignmentId);
  return `
    <div class="card teacher-submission-card" style="margin-bottom:1rem;" role="button" tabindex="0" data-submission-card="${html(sub.id)}" aria-label="Review ${html(assignment?.title || 'assignment')} submitted by ${html(sub.studentName || 'student')}">
      <div class="card-header">
        <h3>${html(assignment?.title || 'Assignment')}</h3>
        <span class="status-badge ${html(sub.status)}">${html(sub.status)}</span>
      </div>
      <p><strong>${html(sub.studentName || 'Student')}</strong> · ${formatDate(sub.submittedAt || sub.updatedAt)}</p>
      <p>${html(textFromHtml(sub.content).slice(0, 180))}${textFromHtml(sub.content).length > 180 ? '...' : ''}</p>
      <button class="btn-primary small review-submission" data-id="${html(sub.id)}">${sub.status === 'graded' ? 'Edit Feedback' : 'Review'}</button>
    </div>
  `;
}

function bindReviewButtons(scope) {
  scope.querySelectorAll('.review-submission').forEach(button => button.addEventListener('click', () => openFeedbackModal(button.dataset.id)));
}

function bindClickableSubmissionCards(scope) {
  scope.querySelectorAll('[data-submission-card]').forEach(card => {
    card.addEventListener('click', event => {
      if (event.target.closest('button')) return;
      openFeedbackModal(card.dataset.submissionCard);
    });
    card.addEventListener('keydown', event => {
      if (!['Enter', ' '].includes(event.key) || event.target.closest('button')) return;
      event.preventDefault();
      openFeedbackModal(card.dataset.submissionCard);
    });
  });
}

function openFeedbackModal(id) {
  const sub = SUBMISSIONS.find(s => s.id === id);
  if (!sub) return;
  const assignment = ASSIGNMENTS.find(a => a.id === sub.assignmentId);
  activeSubmissionId = id;
  if ($('modal-student')) $('modal-student').textContent = sub.studentName || 'Student';
  if ($('modal-assignment')) $('modal-assignment').textContent = assignment?.title || 'Assignment';
  if ($('modal-submitted')) $('modal-submitted').textContent = formatDate(sub.submittedAt || sub.updatedAt);
  if ($('modal-text')) $('modal-text').innerHTML = sub.content || '';
  if ($('modal-feedback-text')) $('modal-feedback-text').value = sub.feedback || '';
  if ($('modal-private-note')) $('modal-private-note').value = sub.privateNote || '';
  if ($('modal-grade')) $('modal-grade').value = sub.grade || '';
  $('feedback-modal')?.classList.remove('hidden');
}

function closeFeedbackModal() {
  activeSubmissionId = null;
  $('feedback-modal')?.classList.add('hidden');
}

async function submitFeedback() {
  const sub = SUBMISSIONS.find(s => s.id === activeSubmissionId);
  if (!sub) return;
  try {
    const response = await fetch(`/api/submissions/${encodeURIComponent(sub.id)}/grade`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${jwt}` },
      body: JSON.stringify({
        feedback: $('modal-feedback-text')?.value.trim() || '',
        privateNote: $('modal-private-note')?.value.trim() || '',
        grade: $('modal-grade')?.value.trim() || '',
      }),
    });
    const result = await response.json();
    if (!response.ok) return alert(result.error || 'Could not save feedback.');
    Object.assign(sub, result.submission);
    closeFeedbackModal();
    renderAll();
  } catch (error) {
    console.error('Feedback save failed', error);
    alert('Could not reach the server. Feedback was not saved.');
  }
}

async function generateFeedback() {
  const sub = SUBMISSIONS.find(s => s.id === activeSubmissionId);
  const assignment = ASSIGNMENTS.find(a => a.id === sub?.assignmentId);
  if (!sub || !assignment) return;
  try {
    const response = await fetch('/api/ai/generate-feedback', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${jwt}` },
      body: JSON.stringify({
        assignmentTitle: assignment.title,
        description: assignment.description,
        rubric: assignment.rubric || '',
        submissionContent: textFromHtml(sub.content),
      }),
    });
    if (!response.ok) throw new Error('AI unavailable');
    const result = await response.json();
    if ($('modal-feedback-text')) $('modal-feedback-text').value = result.feedback || '';
    if ($('modal-grade')) $('modal-grade').value = result.grade || '';
  } catch (error) {
    console.error('AI feedback generation failed', error);
    alert('Could not generate AI feedback. Please try again.');
  }
}

function renderAssignments() {
  const container = $('teacher-assignment-list');
  if (!container) return;
  const pages = Math.max(1, Math.ceil(ASSIGNMENTS.length / TEACHER_PAGE_SIZE));
  teacherAssignmentPage = Math.min(teacherAssignmentPage, pages);
  const visible = ASSIGNMENTS.slice((teacherAssignmentPage - 1) * TEACHER_PAGE_SIZE, teacherAssignmentPage * TEACHER_PAGE_SIZE);
  container.innerHTML = visible.length ? visible.map(assignment => {
    const count = SUBMISSIONS.filter(submission => submission.assignmentId === assignment.id).length;
    const canManage = !assignment.createdBy || String(assignment.createdBy) === String(currentUser.id);
    const actions = canManage
      ? `<button type="button" class="btn-secondary small edit-assignment" data-id="${html(assignment.id)}">Edit</button><button type="button" class="btn-secondary small delete-assignment" data-id="${html(assignment.id)}">Delete</button>`
      : '<span class="teacher-record-subtext">Owned by another instructor</span>';
    return `<tr><td><strong>${html(assignment.title)}</strong><small class="teacher-record-subtext">${html((assignment.description || 'No description provided.').slice(0, 110))}${assignment.description?.length > 110 ? '…' : ''}</small></td><td>${html(assignment.subject || assignment.class || '—')}</td><td>${formatDate(assignment.dueDate)}</td><td>${Number(assignment.minWords || 0).toLocaleString()}</td><td>${count}</td><td class="teacher-action-cell">${actions}</td></tr>`;
  }).join('') : '<tr><td colspan="6" class="teacher-empty-row">No assignments yet.</td></tr>';
  renderTeacherPagination('teacher-assignments-pagination', ASSIGNMENTS.length, teacherAssignmentPage, page => {
    teacherAssignmentPage = page;
    renderAssignments();
  });
  container.querySelectorAll('.edit-assignment').forEach(button => button.addEventListener('click', () => openEditAssignment(button.dataset.id)));
  container.querySelectorAll('.delete-assignment').forEach(button => button.addEventListener('click', async () => {
    if (!confirm('Delete this assignment?')) return;
    try {
      const response = await fetch(`/api/assignments/${encodeURIComponent(button.dataset.id)}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${jwt}` },
      });
      const result = await response.json();
      if (!response.ok) return alert(result.error || 'Could not delete assignment.');
      SUBMISSIONS = SUBMISSIONS.filter(submission => String(submission.assignmentId) !== String(button.dataset.id));
      Object.keys(DRAFTS).forEach(key => {
        if (key.endsWith(`:${button.dataset.id}`)) delete DRAFTS[key];
      });
      ASSIGNMENTS = ASSIGNMENTS.filter(item => String(item.id) !== String(button.dataset.id));
      renderAll();
    } catch (error) {
      console.error('Assignment delete failed', error);
      alert('Could not reach the server. Assignment was not deleted.');
    }
  }));
}
function setupAssignmentEditor() {
  $('edit-assignment-close')?.addEventListener('click', closeEditAssignment);
  $('edit-assignment-cancel')?.addEventListener('click', closeEditAssignment);
  $('edit-assignment-backdrop')?.addEventListener('click', closeEditAssignment);
  $('edit-assignment-save')?.addEventListener('click', saveEditedAssignment);
}

function openEditAssignment(id) {
  const assignment = ASSIGNMENTS.find(a => a.id === id);
  if (!assignment) return;
  activeAssignmentId = id;
  $('edit-assignment-title').value = assignment.title || '';
  $('edit-assignment-due').value = assignment.dueDate ? assignment.dueDate.slice(0, 10) : '';
  $('edit-assignment-words').value = assignment.minWords || '';
  $('edit-assignment-type').value = assignment.type || 'essay';
  $('edit-assignment-modal')?.classList.remove('hidden');
}

async function saveEditedAssignment() {
  const assignment = ASSIGNMENTS.find(a => a.id === activeAssignmentId);
  if (!assignment) return;
  try {
    const response = await fetch(`/api/assignments/${encodeURIComponent(assignment.id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${jwt}` },
      body: JSON.stringify({
        title: $('edit-assignment-title')?.value.trim() || assignment.title,
        dueDate: new Date(($('edit-assignment-due')?.value || assignment.dueDate.slice(0, 10)) + 'T23:59:00').toISOString(),
        minWords: Number($('edit-assignment-words')?.value || assignment.minWords || 250),
        type: $('edit-assignment-type')?.value || assignment.type || 'essay',
      }),
    });
    const result = await response.json();
    if (!response.ok) return alert(result.error || 'Could not update assignment.');
    Object.assign(assignment, result.assignment);
    closeEditAssignment();
    renderAll();
  } catch (error) {
    console.error('Assignment update failed', error);
    alert('Could not reach the server. Assignment was not updated.');
  }
}

function closeEditAssignment() {
  activeAssignmentId = null;
  $('edit-assignment-modal')?.classList.add('hidden');
}

function setupProfile() {
  $('save-profile-btn')?.addEventListener('click', async () => {
    const first = $('profile-first')?.value.trim();
    const middle = $('profile-middle')?.value.trim() || '';
    const last = $('profile-last')?.value.trim();
    const pass = $('profile-pass')?.value || '';
    if (!first || !last) return alert('Name cannot be blank.');
    if (pass && (pass.length < 8 || !/[a-z]/.test(pass) || !/[A-Z]/.test(pass) || !/\d/.test(pass))) {
      return alert('At least 8 characters, including uppercase, lowercase, and a number. A symbol is optional and may improve strength.');
    }
    try {
      const response = await fetch(`/api/users/${encodeURIComponent(currentUser.id)}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${sessionStorage.getItem('edugram_jwt') || ''}`,
        },
        body: JSON.stringify({
          firstName: first,
          middleName: middle,
          lastName: last,
          email: currentUser.email,
          phone: currentUser.phone || '',
          studentId: currentUser.studentId || '',
          ...(pass ? { password: pass } : {}),
        }),
      });
      const result = await response.json();
      if (!response.ok) return alert(result.error || 'Could not update profile.');
      Object.assign(currentUser, result.user);
    } catch (error) {
      console.error('Profile update request failed', error);
      return alert('Could not reach the server. Profile was not saved.');
    }
    updateChrome();
    populateProfile();
    $('profile-toast')?.classList.remove('hidden');
    setTimeout(() => $('profile-toast')?.classList.add('hidden'), 2500);
  });
}

function populateProfile() {
  if (!$('profile-first')) return;
  $('profile-first').value = currentUser.firstName || '';
  $('profile-middle').value = currentUser.middleName || '';
  $('profile-last').value = currentUser.lastName || '';
  $('profile-email-display').value = currentUser.email || '';
  $('profile-empid-display').value = currentUser.employeeId || '';
  $('profile-pass').value = '';
  $('tp-avatar-display').textContent = ((currentUser.firstName?.[0] || 'T') + (currentUser.lastName?.[0] || '')).toUpperCase();
  $('tp-fullname-display').textContent = [currentUser.firstName, currentUser.middleName, currentUser.lastName].filter(Boolean).join(' ');
  $('tp-email-display').textContent = currentUser.email || '';
}

function logout() {
  sessionStorage.clear();
  window.location.href = 'index.php';
}

document.addEventListener('DOMContentLoaded', initTeacherDashboard);
