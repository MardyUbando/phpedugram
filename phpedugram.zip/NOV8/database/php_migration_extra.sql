CREATE TABLE IF NOT EXISTS coursework_records (
    record_type ENUM('assignment', 'submission', 'draft') NOT NULL,
    record_id VARCHAR(191) NOT NULL,
    owner_id BIGINT UNSIGNED NULL,
    parent_id VARCHAR(191) NULL,
    payload LONGTEXT NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (record_type, record_id),
    KEY coursework_owner (record_type, owner_id),
    KEY coursework_parent (record_type, parent_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET @middle_name_exists = (
    SELECT COUNT(*)
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'users'
      AND COLUMN_NAME = 'middle_name'
);

SET @middle_name_sql = IF(
    @middle_name_exists = 0,
    'ALTER TABLE users ADD COLUMN middle_name VARCHAR(100) NULL AFTER first_name',
    'SELECT 1'
);

PREPARE middle_name_statement FROM @middle_name_sql;
EXECUTE middle_name_statement;
DEALLOCATE PREPARE middle_name_statement;
