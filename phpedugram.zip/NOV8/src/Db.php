<?php
declare(strict_types=1);

namespace Edugram;

use PDO;
use PDOException;

final class Db
{
    public static function connect(): PDO
    {
        $host = $_ENV['DB_HOST'] ?? $_ENV['MYSQL_HOST'] ?? '';
        $port = $_ENV['DB_PORT'] ?? $_ENV['MYSQL_PORT'] ?? '';
        $name = $_ENV['DB_NAME'] ?? $_ENV['LOGIN_DB_NAME'] ?? $_ENV['MYSQL_DATABASE'] ?? '';
        $user = $_ENV['DB_USER'] ?? $_ENV['MYSQL_USER'] ?? '';
        $password = $_ENV['DB_PASSWORD'] ?? $_ENV['MYSQL_PASSWORD'] ?? null;
        if ($host === '' || $port === '' || $name === '' || $user === '' || $password === null) {
            throw new PDOException('Database settings are incomplete in .env.');
        }

        try {
            $pdo = new PDO(
                "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4",
                $user,
                $password,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
            $courseworkCheck = $pdo->prepare('SELECT 1 FROM coursework_records LIMIT 0');
            $courseworkCheck->execute();
            return $pdo;
        } catch (PDOException $exception) {
            if (in_array((string)$exception->getCode(), ['42S02', '42S22'], true)) {
                error_log('Database schema is missing a required table or column: ' . $exception->getMessage());
                throw new PDOException('Database schema is incomplete.', 0, $exception);
            }
            error_log('Database connection failed: ' . $exception->getMessage());
            throw new PDOException('Database connection failed.', 0, $exception);
        }
    }

}
