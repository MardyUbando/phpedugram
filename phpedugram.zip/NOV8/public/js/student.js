'use strict';

const jwt = sessionStorage.getItem('edugram_jwt');
const userRole = sessionStorage.getItem('edugram_user_role');
const decoded = jwt ? decodeJwtPayload(jwt) : null;

if (!decoded || userRole !== 'student') {
  window.location.href = 'index.php';
}

let currentUser = USERS.find(user => user.id === decoded?.sub);
let quillEditor = null;
let lastEditorSelection = null;
let pendingGeminiSuggestion = null;
let myClasses = [];
let academicOptions = [];
let pdfCheckerText = '';
let pendingSubmission = null;
const STUDENT_PAGE_SIZE = 8;
let assignmentsPage = 1;
let historyPage = 1;
let feedbackPage = 1;
let assignmentFilter = 'all';

if (!currentUser) {
  sessionStorage.clear();
  window.location.href = 'index.php';
}

const $ = id => document.getElementById(id);
const html = value => String(value ?? '').replace(/[&<>"']/g, char => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[char]));
const textFromHtml = value => {
  const div = document.createElement('div');
  div.innerHTML = value || '';
  return div.textContent || div.innerText || '';
};
const formatDate = value => value ? new Date(value).toLocaleDateString('en-PH', {
  month: 'short', day: 'numeric', year: 'numeric',
}) : 'No date';

function myAssignments() {
  return ASSIGNMENTS.filter(assignment => assignment.forAll || myClasses.some(classInfo => {
    const label = `${classInfo.courseCode} - ${classInfo.majorName} - ${classInfo.yearSectionName} - ${classInfo.subject}`;
    return [classInfo.id, label, classInfo.yearSectionName].includes(assignment.class);
  }));
}

function mySubmission(assignmentId) {
  return SUBMISSIONS.find(sub => sub.assignmentId === assignmentId && sub.studentId === currentUser.id);
}

function assignmentStatus(assignment) {
  const sub = mySubmission(assignment.id);
  if (sub?.status === 'graded') return 'graded';
  if (sub) return 'submitted';
  return new Date(assignment.dueDate) < new Date() ? 'overdue' : 'pending';
}

function initStudentDashboard() {
  $('auth-screen')?.style && ($('auth-screen').style.display = 'none');
  $('student-screen')?.style && ($('student-screen').style.display = 'flex');

  updateUserChrome();
  setupNavigation();
  setupOverviewInteractions();
  setupEditor();
  setupPdfChecker();
  setupProfile();
  setupFilters();
  renderAll();
  loadStudentAcademicOptions();
  setupPasswordStrength('sp-pass', 'sp-password-strength');

  $('student-logout')?.addEventListener('click', logout);
  $('student-menu-toggle')?.addEventListener('click', () => $('student-sidebar')?.classList.toggle('active'));
}

function updateUserChrome() {
  const initials = ((currentUser.firstName?.[0] || 'S') + (currentUser.lastName?.[0] || '')).toUpperCase();
  if ($('student-avatar')) $('student-avatar').textContent = initials;
  if ($('student-name')) $('student-name').textContent = [currentUser.firstName, currentUser.middleName, currentUser.lastName].filter(Boolean).join(' ');
  if ($('student-welcome-name')) $('student-welcome-name').textContent = currentUser.firstName;
}

function setupNavigation() {
  const titles = {
    's-overview': 'Overview',
    's-assignments': 'Assignments',
    's-editor': 'Writing Editor',
    's-pdf-checker': 'PDF Checker',
    's-history': 'Submission History',
    's-feedback': 'Teacher Feedback',
    's-profile': 'My Profile',
  };

  document.querySelectorAll('.nav-item, .s-nav-link').forEach(item => {
    item.addEventListener('click', event => {
      event.preventDefault();
      showPanel(item.dataset.panel, titles[item.dataset.panel]);
    });
  });
}

function setupOverviewInteractions() {
  const openOverviewTarget = target => {
    const assignmentId = target.dataset.overviewAssignment;
    if (assignmentId) {
      showPanel('s-editor', 'Writing Editor');
      if ($('assignment-select')) {
        $('assignment-select').value = assignmentId;
        loadSelectedAssignment();
      }
      return;
    }
    const panelId = target.dataset.overviewPanel;
    if (!panelId) return;
    showPanel(panelId, target.dataset.overviewTitle || (panelId === 's-history' ? 'Submission History' : 'Overview'));
    const filter = target.dataset.overviewFilter;
    if (filter) document.querySelector(`#s-assignments .filter-btn[data-filter="${filter}"]`)?.click();
  };
  document.addEventListener('click', event => {
    const target = event.target.closest('[data-overview-panel], [data-overview-assignment]');
    if (!target) return;
    event.preventDefault();
    openOverviewTarget(target);
  });
  document.addEventListener('keydown', event => {
    if (!['Enter', ' '].includes(event.key)) return;
    const target = event.target.closest('[data-overview-panel], [data-overview-assignment]');
    if (!target || target.tagName === 'A' || target.tagName === 'BUTTON') return;
    event.preventDefault();
    openOverviewTarget(target);
  });
}

function showPanel(panelId, title = 'Overview') {
  document.querySelectorAll('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.panel === panelId));
  document.querySelectorAll('.panel').forEach(panel => panel.classList.toggle('active', panel.id === panelId));
  if ($('student-panel-title')) $('student-panel-title').textContent = title;
  $('student-sidebar')?.classList.remove('active');

  if (panelId === 's-profile') populateProfile();
  if (panelId === 's-editor') populateAssignmentSelect();
}

function setupFilters() {
  document.querySelectorAll('#s-assignments .filter-btn').forEach(button => {
    button.addEventListener('click', () => {
      document.querySelectorAll('#s-assignments .filter-btn').forEach(btn => btn.classList.remove('active'));
      button.classList.add('active');
      assignmentFilter = button.dataset.filter || 'all';
      assignmentsPage = 1;
      renderAssignments(assignmentFilter);
    });
  });
}

function renderAll() {
  updateStudentStats();
  renderDeadlines();
  renderActivity();
  renderAssignments();
  populateAssignmentSelect();
  renderHistory();
  renderFeedback();
  populateProfile();
  refreshMyClasses();
}

async function refreshMyClasses() {
  try {
    const response = await fetch('/api/classes', { headers: { Authorization: 'Bearer ' + (sessionStorage.getItem('edugram_jwt') || '') } });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not load your classes');
    $('student-classes-error')?.classList.add('hidden');
    myClasses = await Promise.all(result.classes.map(async classInfo => {
      const membersResponse = await fetch(`/api/classes/${encodeURIComponent(classInfo.id)}/members`, {
        headers: { Authorization: 'Bearer ' + (sessionStorage.getItem('edugram_jwt') || '') },
      });
      const membersResult = await membersResponse.json();
      if (!membersResponse.ok) throw new Error(membersResult.error || `Could not load classmates for ${classInfo.subject}`);
      return { ...classInfo, members: membersResult.members };
    }));
    $('student-classes-list').innerHTML = myClasses.length ? myClasses.map(classInfo =>
      '<div class="card" style="margin-bottom:.75rem;"><h4>' + html(classInfo.subject) +
      '</h4><p>' + html(classInfo.teacherName) + ' · ' + html(classInfo.courseCode) + ' - ' +
      html(classInfo.majorName) + ' - ' + html(classInfo.yearSectionName) + '</p><p>Classmates: ' +
      (classInfo.members.length
        ? classInfo.members.map(member => html([member.firstName, member.middleName, member.lastName].filter(Boolean).join(' '))).join(', ')
        : 'No classmates yet.') + '</p></div>'
    ).join('') : '<p class="empty-hint">You are not enrolled in any classes yet.</p>';
    updateStudentStats();
    renderDeadlines();
    renderAssignments();
    populateAssignmentSelect();
  } catch (error) {
    console.error('My classes refresh failed', error);
    $('student-classes-error').textContent = error.message || 'Could not refresh your classes.';
    $('student-classes-error').classList.remove('hidden');
  }
}

async function loadStudentAcademicOptions() {
  try {
    const response = await fetch('/api/academic/options');
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not load academic options');
    academicOptions = result.courses;
    fillStudentAcademicOptions();
  } catch (error) {
    console.error('Student academic options load failed', error);
    $('student-classes-error').textContent = error.message || 'Could not load academic options.';
    $('student-classes-error').classList.remove('hidden');
  }
}

function fillStudentSelect(select, entries, placeholder, label = entry => entry.name) {
  if (!select) return;
  select.innerHTML = '<option value="">' + placeholder + '</option>' + entries.map(entry =>
    '<option value="' + html(entry.id) + '">' + html(label(entry)) + '</option>'
  ).join('');
  select.disabled = entries.length === 0;
}

function updateStudentAcademicOutput() {
  const output = $('sp-academic-output');
  if (!output) return;
  const year = $('sp-year')?.value.trim() || '';
  const section = $('sp-section')?.value.trim().replace(/\s+/g, ' ') || '';
  if (!year && !section) {
    output.textContent = 'Your saved year and section will appear here.';
    return;
  }
  if (!year || !section) {
    output.textContent = 'Enter both year and section to preview your profile.';
    return;
  }
  const course = $('sp-course')?.value ? $('sp-course').selectedOptions[0]?.textContent : '';
  const major = $('sp-major')?.value ? $('sp-major').selectedOptions[0]?.textContent : '';
  output.textContent = major
    ? `Profile record: ${course} · ${major} · ${year}-${section}`
    : `Year and section: ${year}-${section}`;
}

function fillStudentAcademicOptions() {
  const courseSelect = $('sp-course');
  const majorSelect = $('sp-major');
  const yearInput = $('sp-year');
  const sectionInput = $('sp-section');
  const selectedYearSectionId = currentUser.yearSectionId || '';
  const selectedPath = academicOptions.flatMap(course => course.majors.flatMap(major =>
    major.yearSections.map(yearSection => ({ course, major, yearSection }))
  )).find(item => item.yearSection.id === selectedYearSectionId);
  fillStudentSelect(courseSelect, academicOptions, 'Select course', course => course.code + ' - ' + course.name);
  fillStudentSelect(majorSelect, [], 'Select major');
  if (yearInput) yearInput.value = '';
  if (sectionInput) sectionInput.value = '';
  if (selectedPath) {
    courseSelect.value = selectedPath.course.id;
    fillStudentSelect(majorSelect, selectedPath.course.majors, 'Select major');
    majorSelect.value = selectedPath.major.id;
    const yearSectionParts = selectedPath.yearSection.name.match(/^([1-6])-(.+)$/);
    if (yearInput) yearInput.value = yearSectionParts?.[1] || '';
    if (sectionInput) sectionInput.value = yearSectionParts?.[2] || '';
  }
  if (!courseSelect.dataset.bound) {
    courseSelect.addEventListener('change', () => {
      const course = academicOptions.find(item => item.id === courseSelect.value);
      fillStudentSelect(majorSelect, course?.majors || [], 'Select major');
      if (yearInput) yearInput.value = '';
      if (sectionInput) sectionInput.value = '';
      updateStudentAcademicOutput();
    });
    majorSelect.addEventListener('change', () => {
      if (yearInput) yearInput.value = '';
      if (sectionInput) sectionInput.value = '';
      updateStudentAcademicOutput();
    });
    yearInput?.addEventListener('input', updateStudentAcademicOutput);
    sectionInput?.addEventListener('input', updateStudentAcademicOutput);
    courseSelect.dataset.bound = 'true';
  }
  updateStudentAcademicOutput();
}

function updateStudentStats() {
  const assignments = myAssignments();
  const submitted = assignments.filter(a => mySubmission(a.id)).length;
  const pending = assignments.filter(a => assignmentStatus(a) === 'pending' || assignmentStatus(a) === 'overdue').length;
  const feedback = SUBMISSIONS.filter(s => s.studentId === currentUser.id && s.feedback).length;

  if ($('s-total-assignments')) $('s-total-assignments').textContent = assignments.length;
  if ($('s-submitted')) $('s-submitted').textContent = submitted;
  if ($('s-pending')) $('s-pending').textContent = pending;
  if ($('s-feedback-count')) $('s-feedback-count').textContent = feedback;
  if ($('pending-count')) $('pending-count').textContent = pending;
  if ($('feedback-count')) $('feedback-count').textContent = feedback;
}

function renderDeadlines() {
  const list = document.querySelector('.deadline-list');
  if (!list) return;
  const upcoming = myAssignments()
    .filter(a => !mySubmission(a.id))
    .sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate))
    .slice(0, 3);

  list.innerHTML = upcoming.length ? upcoming.map(a => `
    <button type="button" class="deadline-item overview-deadline ${new Date(a.dueDate) < new Date() ? 'urgent' : ''}" data-overview-assignment="${html(a.id)}" aria-label="Open ${html(a.title)}">
      <div class="deadline-dot"></div>
      <div class="deadline-info">
        <span class="deadline-title">${html(a.title)}</span>
        <span class="deadline-sub">${html(a.description || 'Writing assignment')}</span>
      </div>
      <span class="deadline-badge">${formatDate(a.dueDate)}</span>
    </button>
  `).join('') : '<p class="empty-hint">No pending deadlines.</p>';
}

function renderActivity() {
  const list = document.querySelector('.activity-list');
  if (!list) return;
  const recent = SUBMISSIONS
    .filter(s => s.studentId === currentUser.id)
    .sort((a, b) => new Date(b.submittedAt || b.updatedAt || 0) - new Date(a.submittedAt || a.updatedAt || 0))
    .slice(0, 3);

  list.innerHTML = recent.length ? recent.map(sub => {
    const assignment = ASSIGNMENTS.find(a => a.id === sub.assignmentId);
    return `
      <div class="activity-item overview-clickable" role="button" tabindex="0" data-overview-panel="s-history" data-overview-title="Submission History" aria-label="View submission for ${html(assignment?.title || 'Assignment')}">
        <div class="activity-icon submit"></div>
        <div class="activity-text">
          <span>${sub.status === 'graded' ? 'Feedback received for' : 'Submitted'} <em>${html(assignment?.title || 'Assignment')}</em></span>
          <time>${formatDate(sub.submittedAt || sub.updatedAt)}</time>
        </div>
      </div>
    `;
  }).join('') : '<p class="empty-hint">No activity yet.</p>';
}

function renderAssignments(filter = 'all') {
  const grid = $('student-assignment-grid');
  if (!grid) return;
  assignmentFilter = filter;
  let assignments = myAssignments();
  if (filter === 'pending') assignments = assignments.filter(a => assignmentStatus(a) === 'pending' || assignmentStatus(a) === 'overdue');
  if (filter === 'submitted') assignments = assignments.filter(a => mySubmission(a.id));
  const pages = Math.max(1, Math.ceil(assignments.length / STUDENT_PAGE_SIZE));
  assignmentsPage = Math.min(assignmentsPage, pages);
  const visible = assignments.slice((assignmentsPage - 1) * STUDENT_PAGE_SIZE, assignmentsPage * STUDENT_PAGE_SIZE);
  grid.innerHTML = visible.length ? visible.map(assignment => {
    const status = assignmentStatus(assignment);
    const classInfo = myClasses.find(item => [item.id, `${item.courseCode} - ${item.majorName} - ${item.yearSectionName} - ${item.subject}`, item.yearSectionName].includes(assignment.class));
    const classLabel = classInfo ? `${classInfo.courseCode} · ${classInfo.subject}` : assignment.forAll ? 'All classes' : '—';
    const description = assignment.description || 'No description provided.';
    const handout = assignment.attachment?.data
      ? `<a class="student-handout-link" href="data:application/pdf;base64,${assignment.attachment.data}" download="${html(assignment.attachment.name || 'assignment.pdf')}">Download handout</a>`
      : '';
    return `<tr><td><strong>${html(assignment.title)}</strong><small class="student-record-subtext">${html(description.slice(0, 110))}${description.length > 110 ? '…' : ''}</small>${handout}</td><td>${html(classLabel)}</td><td>${formatDate(assignment.dueDate)}</td><td>${Number(assignment.minWords || 0).toLocaleString()}</td><td><span class="status-badge ${html(status)}">${html(status)}</span></td><td><button type="button" class="btn-primary small open-editor" data-id="${html(assignment.id)}">${mySubmission(assignment.id) ? 'View / Revise' : 'Start Writing'}</button></td></tr>`;
  }).join('') : '<tr><td colspan="6" class="student-empty-row">No assignments found.</td></tr>';
  renderStudentPagination('assignments-pagination', assignments.length, assignmentsPage, page => {
    assignmentsPage = page;
    renderAssignments(assignmentFilter);
  });
  bindStudentEditorButtons(grid);
}

function renderStudentPagination(id, total, page, setPage) {
  const pagination = $(id);
  if (!pagination) return;
  const pages = Math.max(1, Math.ceil(total / STUDENT_PAGE_SIZE));
  const start = total ? (page - 1) * STUDENT_PAGE_SIZE + 1 : 0;
  const end = Math.min(page * STUDENT_PAGE_SIZE, total);
  pagination.innerHTML = `<span>Showing ${start}–${end} of ${total}</span><div class="student-pagination-controls"><button type="button" class="student-page-button" data-page="${page - 1}" ${page <= 1 ? 'disabled' : ''}>Previous</button><span>Page ${page} of ${pages}</span><button type="button" class="student-page-button" data-page="${page + 1}" ${page >= pages ? 'disabled' : ''}>Next</button></div>`;
  pagination.querySelectorAll('[data-page]').forEach(button => button.addEventListener('click', () => setPage(Number(button.dataset.page))));
}

function bindStudentEditorButtons(container) {
  container.querySelectorAll('.open-editor').forEach(button => button.addEventListener('click', () => {
    showPanel('s-editor', 'Writing Editor');
    if ($('assignment-select')) {
      $('assignment-select').value = button.dataset.id;
      loadSelectedAssignment();
    }
  }));
}
function setupEditor() {
  if (window.Quill && $('quill-editor')) {
    quillEditor = new Quill('#quill-editor', { theme: 'snow', placeholder: 'Write your submission here...' });
    quillEditor.on('text-change', updateWordCount);
    quillEditor.on('selection-change', range => {
      if (range) lastEditorSelection = range;
    });
  }
  $('assignment-select')?.addEventListener('change', loadSelectedAssignment);
  $('save-draft-btn')?.addEventListener('click', saveDraft);
  $('submit-assignment-btn')?.addEventListener('click', submitAssignment);
  $('pre-submit-edit-btn')?.addEventListener('click', closePreSubmitReview);
  $('pre-submit-close')?.addEventListener('click', closePreSubmitReview);
  $('pre-submit-backdrop')?.addEventListener('click', closePreSubmitReview);
  $('pre-submit-confirm-btn')?.addEventListener('click', async () => {
    if (!pendingSubmission) return;
    const submission = pendingSubmission;
    closePreSubmitReview();
    await saveReviewedSubmission(submission);
  });
  $('check-writing-btn')?.addEventListener('click', checkWriting);
  $('gemini-improve-btn')?.addEventListener('mousedown', event => event.preventDefault());
  $('gemini-improve-btn')?.addEventListener('click', improveSelectedWriting);
  $('gemini-apply-btn')?.addEventListener('click', applyGeminiSuggestion);
  $('gemini-dismiss-btn')?.addEventListener('click', clearGeminiSuggestion);
}

async function improveSelectedWriting() {
  if (!quillEditor) return;
  const range = quillEditor.getSelection() || lastEditorSelection;
  if (!range || range.length < 1) {
    pendingGeminiSuggestion = null;
    return showGeminiSuggestion('Select a passage in the editor first, then click Improve with Gemini.', '');
  }
  if (range.length > 12000) {
    pendingGeminiSuggestion = null;
    return showGeminiSuggestion('Select a shorter passage (12,000 characters or fewer) and try again.', '');
  }

  pendingGeminiSuggestion = null;
  const originalText = quillEditor.getText(range.index, range.length);
  const documentSnapshot = quillEditor.getText();
  const button = $('gemini-improve-btn');
  if (button) {
    button.disabled = true;
    button.dataset.originalLabel = button.textContent.trim();
    button.textContent = 'Improving...';
  }
  showGeminiSuggestion('Gemini is preparing a revision...', '');
  try {
    const response = await fetch('/api/ai/improve-writing', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${jwt}` },
      body: JSON.stringify({ text: originalText }),
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Gemini could not improve this passage.');
    if (typeof result.suggestion !== 'string' || !result.suggestion.trim()) {
      throw new Error('Gemini returned an empty suggestion. Please try again.');
    }
    pendingGeminiSuggestion = {
      index: range.index,
      length: range.length,
      originalText,
      documentSnapshot,
      suggestion: result.suggestion.trim(),
    };
    showGeminiSuggestion('Review the suggestion. Your original text will change only if you choose Replace selection.', pendingGeminiSuggestion.suggestion);
  } catch (error) {
    console.error('Gemini writing improvement failed', error);
    pendingGeminiSuggestion = null;
    showGeminiSuggestion(error.message || 'Could not get a Gemini suggestion. Please try again.', '');
  } finally {
    if (button) {
      button.disabled = false;
      button.textContent = button.dataset.originalLabel || 'Improve with Gemini';
    }
  }
}

function showGeminiSuggestion(status, suggestion) {
  const card = $('gemini-suggestion-card');
  const statusEl = $('gemini-suggestion-status');
  const textEl = $('gemini-suggestion-text');
  if (statusEl) statusEl.textContent = status;
  if (textEl) textEl.textContent = suggestion;
  $('gemini-apply-btn')?.classList.toggle('hidden', !suggestion || !pendingGeminiSuggestion);
  if (card) card.classList.remove('hidden');
}

function applyGeminiSuggestion() {
  if (!pendingGeminiSuggestion || !quillEditor) return;
  if (quillEditor.getText() !== pendingGeminiSuggestion.documentSnapshot
    || quillEditor.getText(pendingGeminiSuggestion.index, pendingGeminiSuggestion.length) !== pendingGeminiSuggestion.originalText) {
    showGeminiSuggestion('The editor changed while the suggestion was open. Select the passage again and regenerate the suggestion.', '');
    pendingGeminiSuggestion = null;
    return;
  }
  const { index, length, suggestion } = pendingGeminiSuggestion;
  quillEditor.deleteText(index, length, 'user');
  quillEditor.insertText(index, suggestion, 'user');
  quillEditor.setSelection(index + suggestion.length, 0, 'silent');
  updateWordCount();
  clearGeminiSuggestion();
}

function clearGeminiSuggestion() {
  pendingGeminiSuggestion = null;
  $('gemini-suggestion-card')?.classList.add('hidden');
  if ($('gemini-suggestion-text')) $('gemini-suggestion-text').textContent = '';
}

function setupPdfChecker() {
  const input = $('pdf-file-input');
  const dropzone = $('pdf-dropzone');
  const status = $('pdf-checker-status');
  const details = $('pdf-checker-details');
  const canvas = $('pdf-preview-canvas');
  const grammarButton = $('pdf-grammar-btn');
  const grammarResults = $('pdf-grammar-results');
  const openEditor = $('pdf-open-editor-btn');
  const clear = $('pdf-clear-btn');
  if (!input || !dropzone) return;

  if (window.pdfjsLib) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
  }
  const setStatus = (message, type = '') => {
    status.textContent = message;
    status.className = `pdf-checker-status${type ? ` ${type}` : ''}`;
  };
  const checkFile = async file => {
    pdfCheckerText = '';
    openEditor.disabled = true;
    grammarButton.disabled = true;
    grammarResults.hidden = true;
    grammarResults.innerHTML = '';
    clear.disabled = false;
    details.hidden = true;
    canvas.hidden = true;
    const context = canvas.getContext('2d');
    context?.clearRect(0, 0, canvas.width, canvas.height);
    if (!file) return;
    if (file.size > 20 * 1024 * 1024) return setStatus('This file is larger than the 20 MB limit.', 'error');
    if (!file.name.toLowerCase().endsWith('.pdf') || file.type && file.type !== 'application/pdf') {
      return setStatus('Choose a PDF file to continue.', 'error');
    }
    setStatus('Checking PDF…');
    try {
      const buffer = await file.arrayBuffer();
      const signature = new TextDecoder().decode(new Uint8Array(buffer, 0, Math.min(buffer.byteLength, 5)));
      if (!signature.startsWith('%PDF-')) throw new Error('This file does not have a valid PDF signature.');
      if (!window.pdfjsLib) throw new Error('The PDF reader could not load. Check your internet connection and reload this page.');
      const pdf = await pdfjsLib.getDocument({ data: new Uint8Array(buffer) }).promise;
      const pageTexts = [];
      for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
        const page = await pdf.getPage(pageNumber);
        const content = await page.getTextContent();
        pageTexts.push(content.items.map(item => item.str || '').join(' '));
        if (pageNumber === 1) {
          const viewport = page.getViewport({ scale: Math.min(1.2, 720 / page.getViewport({ scale: 1 }).width) });
          canvas.width = Math.ceil(viewport.width);
          canvas.height = Math.ceil(viewport.height);
          await page.render({ canvasContext: canvas.getContext('2d'), viewport }).promise;
          canvas.hidden = false;
        }
      }
      pdfCheckerText = pageTexts.join('\n\n').replace(/[ \t]+/g, ' ').trim();
      const words = pdfCheckerText ? pdfCheckerText.split(/\s+/).length : 0;
      details.innerHTML = `<div><strong>${html(file.name)}</strong><span>${(file.size / 1024 / 1024).toFixed(2)} MB</span></div><div><strong>${pdf.numPages}</strong><span>${pdf.numPages === 1 ? 'page' : 'pages'}</span></div><div><strong>${words.toLocaleString()}</strong><span>${words === 1 ? 'word extracted' : 'words extracted'}</span></div>`;
      details.hidden = false;
      if (words) {
        openEditor.disabled = false;
        grammarButton.disabled = false;
        setStatus('PDF opened successfully. Text is ready to review.', 'success');
      } else {
        setStatus('PDF opened, but no selectable text was found. It may be a scanned document; OCR is not available here.', 'warning');
      }
    } catch (error) {
      console.error('PDF check failed', error);
      setStatus(error.message || 'Could not read this PDF. It may be damaged or password-protected.', 'error');
    }
  };
  input.addEventListener('change', () => checkFile(input.files?.[0]));
  ['dragenter', 'dragover'].forEach(name => dropzone.addEventListener(name, event => {
    event.preventDefault();
    dropzone.classList.add('is-dragging');
  }));
  ['dragleave', 'drop'].forEach(name => dropzone.addEventListener(name, event => {
    event.preventDefault();
    dropzone.classList.remove('is-dragging');
  }));
  dropzone.addEventListener('drop', event => {
    const file = event.dataTransfer?.files?.[0];
    if (!file) return;
    try { input.files = event.dataTransfer.files; } catch (_) {  }
    checkFile(file);
  });
  openEditor.addEventListener('click', () => {
    if (!pdfCheckerText) return;
    if (quillEditor?.getText().trim() && !confirm('Replace the current Writing Editor text with the extracted PDF text?')) return;
    showPanel('s-editor', 'Writing Editor');
    if (quillEditor) quillEditor.setText(pdfCheckerText);
    updateWordCount();
  });
  grammarButton.addEventListener('click', async () => {
    if (!pdfCheckerText) return;
    grammarButton.disabled = true;
    grammarButton.textContent = 'Checking…';
    grammarResults.hidden = false;
    grammarResults.innerHTML = '<p class="empty-hint">Checking spelling, grammar, punctuation, and style…</p>';
    try {
      const analysisText = pdfCheckerText.slice(0, 20000);
      const response = await fetch('/api/ai/analyze-writing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${jwt}` },
        body: JSON.stringify({ text: analysisText }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Grammar checking failed.');
      const errors = Array.isArray(result.errors) ? result.errors : [];
      grammarResults.innerHTML = `<div class="pdf-grammar-heading"><strong>${errors.length ? `${errors.length} possible issue${errors.length === 1 ? '' : 's'} found` : 'No issues found'}</strong><span>Writing score: ${Number(result.score ?? 0)}/100</span></div>${errors.length ? `<div class="pdf-grammar-list">${errors.map(issue => `<article class="pdf-grammar-item"><span class="pdf-grammar-type">${html(issue.type || 'Review')}</span><p>${html(issue.note || 'Possible issue detected.')}</p>${issue.wrongText ? `<div class="pdf-grammar-quote">“${html(issue.wrongText)}”</div>` : ''}${issue.fix ? `<div class="pdf-grammar-fix"><strong>Suggestion:</strong> ${html(issue.fix)}${issue.alternatives?.length ? ` <span>(also: ${issue.alternatives.map(html).join(', ')})</span>` : ''}</div>` : ''}</article>`).join('')}</div>` : '<p class="empty-hint">The extracted text did not trigger any grammar suggestions. Review your PDF once more before submitting.</p>'}${pdfCheckerText.length > analysisText.length ? '<p class="pdf-checker-note">The grammar service checked the first 20,000 characters of this PDF.</p>' : ''}`;
    } catch (error) {
      console.error('PDF grammar check failed', error);
      grammarResults.innerHTML = `<p class="form-error">${html(error.message || 'Could not check this PDF text.')}</p>`;
    } finally {
      grammarButton.disabled = false;
      grammarButton.textContent = 'Check grammar again';
    }
  });
  clear.addEventListener('click', () => {
    input.value = '';
    pdfCheckerText = '';
    details.hidden = true;
    canvas.hidden = true;
    canvas.getContext('2d')?.clearRect(0, 0, canvas.width, canvas.height);
    openEditor.disabled = true;
    grammarButton.disabled = true;
    grammarResults.hidden = true;
    grammarResults.innerHTML = '';
    clear.disabled = true;
    setStatus('Your file stays in this browser. It is not uploaded.');
  });
}

function populateAssignmentSelect() {
  const select = $('assignment-select');
  if (!select) return;
  const selected = select.value;
  select.innerHTML = '<option value="">-- Select Assignment --</option>' + myAssignments().map(a => (
    `<option value="${html(a.id)}">${html(a.title)}</option>`
  )).join('');
  if (selected && myAssignments().some(a => a.id === selected)) select.value = selected;
}

function loadSelectedAssignment() {
  const assignment = ASSIGNMENTS.find(a => a.id === $('assignment-select')?.value);
  if (!assignment) return;
  const draftKey = `${currentUser.id}:${assignment.id}`;
  const sub = mySubmission(assignment.id);
  if ($('meta-title')) $('meta-title').textContent = assignment.title;
  if ($('meta-due')) $('meta-due').textContent = formatDate(assignment.dueDate);
  if ($('meta-words')) $('meta-words').textContent = Number(assignment.minWords || 0).toLocaleString();
  const content = DRAFTS[draftKey]?.content || sub?.content || '';
  if (quillEditor) quillEditor.root.innerHTML = content;
  updateWordCount();
}

function updateWordCount() {
  const text = quillEditor ? quillEditor.getText() : '';
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  if ($('word-count-display')) $('word-count-display').textContent = `${words} word${words === 1 ? '' : 's'}`;
}

async function saveDraft() {
  const assignmentId = $('assignment-select')?.value;
  if (!assignmentId) return alert('Please select an assignment first.');
  try {
    const response = await fetch(`/api/drafts/${encodeURIComponent(assignmentId)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${jwt}` },
      body: JSON.stringify({ content: quillEditor?.root.innerHTML || '' }),
    });
    const result = await response.json();
    if (!response.ok) return alert(result.error || 'Could not save draft.');
    DRAFTS[`${currentUser.id}:${assignmentId}`] = result.draft;
    alert('Draft saved.');
  } catch (error) {
    console.error('Draft save failed', error);
    alert('Could not reach the server. Draft was not saved.');
  }
}

async function submitAssignment() {
  const assignmentId = $('assignment-select')?.value;
  const assignment = ASSIGNMENTS.find(a => a.id === assignmentId);
  if (!assignment) return alert('Please select an assignment first.');
  const content = quillEditor?.root.innerHTML || '';
  const plainText = textFromHtml(content).trim();
  if (!plainText) return alert('Please write your submission before submitting.');

  const submitButton = $('submit-assignment-btn');
  if (submitButton) { submitButton.disabled = true; submitButton.dataset.originalText = submitButton.textContent.trim(); submitButton.textContent = 'Checking grammar…'; }
  try {
    const analysisText = plainText.slice(0, 20000);
    const response = await fetch('/api/ai/analyze-writing', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${jwt}` },
      body: JSON.stringify({ text: analysisText }),
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Grammar check failed.');
    renderAssistant(result);
    pendingSubmission = { assignmentId, content };
    showPreSubmitReview(result, plainText.length > analysisText.length);
  } catch (error) {
    console.error('Pre-submit grammar check failed', error);
    alert(`Grammar check could not finish, so your work was not submitted. ${error.message || 'Please try again.'}`);
  } finally {
    if (submitButton) { submitButton.disabled = false; submitButton.textContent = submitButton.dataset.originalText || 'Submit'; }
  }
}

function showPreSubmitReview(result, truncated) {
  const errors = Array.isArray(result.errors) ? result.errors : [];
  const summary = $('pre-submit-summary');
  const list = $('pre-submit-issues');
  if (summary) summary.innerHTML = errors.length
    ? `<strong>${errors.length} possible issue${errors.length === 1 ? '' : 's'} to review</strong><span>Writing score: ${Number(result.score ?? 0)}/100</span>`
    : '<strong>No grammar suggestions found</strong><span>Please still proofread before submitting.</span>';
  if (list) list.innerHTML = errors.length ? errors.map(issue => `
    <article class="pre-submit-issue">
      <span class="pdf-grammar-type">${html(issue.type || 'Review')}</span>
      <p>${html(issue.note || 'Possible issue detected.')}</p>
      ${issue.wrongText ? `<div class="pdf-grammar-quote">“${html(issue.wrongText)}”</div>` : ''}
      ${issue.fix ? `<div class="pdf-grammar-fix"><strong>Suggestion:</strong> ${html(issue.fix)}${issue.alternatives?.length ? ` <span>(also: ${issue.alternatives.map(html).join(', ')})</span>` : ''}</div>` : ''}
    </article>`).join('') : '<p class="empty-hint">No spelling, grammar, or punctuation issues were detected.</p>';
  if (truncated && list) list.insertAdjacentHTML('beforeend', '<p class="pdf-checker-note">Only the first 20,000 characters were checked. Review the remaining text manually.</p>');
  $('pre-submit-review-modal')?.classList.remove('hidden');
}

function closePreSubmitReview() {
  $('pre-submit-review-modal')?.classList.add('hidden');
  pendingSubmission = null;
}

async function saveReviewedSubmission({ assignmentId, content }) {
  try {
    const response = await fetch('/api/submissions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${jwt}` },
      body: JSON.stringify({ assignmentId, content }),
    });
    const result = await response.json();
    if (!response.ok) return alert(result.error || 'Could not submit assignment.');
    const index = SUBMISSIONS.findIndex(item => item.assignmentId === assignmentId && item.studentId === currentUser.id);
    if (index === -1) SUBMISSIONS.push(result.submission);
    else SUBMISSIONS[index] = result.submission;
    delete DRAFTS[`${currentUser.id}:${assignmentId}`];
    renderAll();
    $('submit-toast')?.classList.remove('hidden');
    setTimeout(() => $('submit-toast')?.classList.add('hidden'), 2500);
  } catch (error) {
    console.error('Submission save failed', error);
    alert('Could not reach the server. Submission was not saved.');
  }
}

async function checkWriting() {
  const text = quillEditor?.getText().trim() || '';
  if (!text) return alert('Write something first.');
  setAssistantLoading();
  try {
    const response = await fetch('/api/ai/analyze-writing', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + jwt },
      body: JSON.stringify({ text }),
    });
    if (!response.ok) throw new Error('AI unavailable');
    renderAssistant(await response.json());
  } catch (error) {
    console.error('Writing analysis failed', error);
    if ($('error-list')) $('error-list').innerHTML = '<p class="form-error">Writing analysis failed. Please try again.</p>';
    if ($('suggestion-list')) $('suggestion-list').innerHTML = '';
  }
}

function setAssistantLoading() {
  if ($('error-list')) $('error-list').innerHTML = '<p class="empty-hint">Analyzing...</p>';
  if ($('suggestion-list')) $('suggestion-list').innerHTML = '<p class="empty-hint">Please wait.</p>';
}

function renderAssistant(result) {
  const errors = Array.isArray(result.errors) ? result.errors : [];
  const suggestions = Array.isArray(result.suggestions) ? result.suggestions : [];
  const score = Number(result.score || 0);
  if ($('error-count')) $('error-count').textContent = errors.length;
  if ($('error-list')) $('error-list').innerHTML = errors.length ? errors.map(e => {
    const altText = Array.isArray(e.alternatives) && e.alternatives.length
      ? ` <span class="ai-alt-suggestions">(also: ${e.alternatives.map(html).join(', ')})</span>`
      : '';
    return `<div class="ai-error-item"><strong>${html(e.type)}</strong>: ${html(e.note)}<br><small>${html(e.fix || '')}${altText}</small></div>`;
  }).join('') : '<p class="empty-hint">No major issues found.</p>';
  if ($('suggestion-list')) $('suggestion-list').innerHTML = suggestions.length ? suggestions.map(s => `<div class="ai-error-item">${html(s.note)}</div>`).join('') : '<p class="empty-hint">No suggestions.</p>';
  if ($('score-num')) $('score-num').textContent = score || '--';
  if ($('score-arc')) $('score-arc').style.strokeDasharray = `${score}, 100`;
  const sentences = (quillEditor?.getText() || '').split(/[.!?]+/).filter(s => s.trim());
  const words = (quillEditor?.getText() || '').trim().split(/\s+/).filter(Boolean);
  if ($('r-sentences')) $('r-sentences').textContent = sentences.length;
  if ($('r-avg')) $('r-avg').textContent = sentences.length ? Math.round(words.length / sentences.length) : 0;
  if ($('r-level')) $('r-level').textContent = words.length > 250 ? 'Developed' : 'Draft';
}

function renderHistory() {
  const tbody = $('history-tbody');
  if (!tbody) return;
  const rows = SUBMISSIONS.filter(s => s.studentId === currentUser.id)
    .sort((a, b) => new Date(b.submittedAt || b.updatedAt || 0) - new Date(a.submittedAt || a.updatedAt || 0));
  const pages = Math.max(1, Math.ceil(rows.length / STUDENT_PAGE_SIZE));
  historyPage = Math.min(historyPage, pages);
  const visible = rows.slice((historyPage - 1) * STUDENT_PAGE_SIZE, historyPage * STUDENT_PAGE_SIZE);
  tbody.innerHTML = visible.length ? visible.map(s => {
    const assignment = ASSIGNMENTS.find(a => a.id === s.assignmentId);
    return `<tr><td><strong>${html(assignment?.title || 'Assignment')}</strong></td><td>${formatDate(s.submittedAt || s.updatedAt)}</td><td><span class="status-badge ${html(s.status)}">${html(s.status)}</span></td><td>${html(s.grade || '-')}</td><td><button type="button" class="btn-secondary small open-editor" data-id="${html(s.assignmentId)}">View</button></td></tr>`;
  }).join('') : '<tr><td colspan="5">No submissions yet.</td></tr>';
  renderStudentPagination('history-pagination', rows.length, historyPage, page => {
    historyPage = page;
    renderHistory();
  });
  bindStudentEditorButtons(tbody);
}

function renderFeedback() {
  const list = $('student-feedback-list');
  if (!list) return;
  const feedback = SUBMISSIONS.filter(s => s.studentId === currentUser.id && (s.feedback || s.grade))
    .sort((a, b) => new Date(b.submittedAt || b.updatedAt || 0) - new Date(a.submittedAt || a.updatedAt || 0));
  const pages = Math.max(1, Math.ceil(feedback.length / STUDENT_PAGE_SIZE));
  feedbackPage = Math.min(feedbackPage, pages);
  const visible = feedback.slice((feedbackPage - 1) * STUDENT_PAGE_SIZE, feedbackPage * STUDENT_PAGE_SIZE);
  list.innerHTML = visible.length ? visible.map(s => {
    const assignment = ASSIGNMENTS.find(a => a.id === s.assignmentId);
    return `<tr><td><strong>${html(assignment?.title || 'Assignment')}</strong></td><td>${html(s.feedback || 'No written feedback.')}</td><td>${html(s.grade || 'Ungraded')}</td><td><button type="button" class="btn-secondary small open-editor" data-id="${html(s.assignmentId)}">View work</button></td></tr>`;
  }).join('') : '<tr><td colspan="4" class="student-empty-row">No feedback yet.</td></tr>';
  renderStudentPagination('feedback-pagination', feedback.length, feedbackPage, page => {
    feedbackPage = page;
    renderFeedback();
  });
  bindStudentEditorButtons(list);
}

function setupProfile() {
  $('sp-save-btn')?.addEventListener('click', async () => {
    const first = $('sp-first')?.value.trim();
    const middle = $('sp-middle')?.value.trim() || '';
    const last = $('sp-last')?.value.trim();
    const pass = $('sp-pass')?.value || '';
    if (!first || !last) return alert('Name cannot be blank.');
    if (pass && (pass.length < 8 || !/[a-z]/.test(pass) || !/[A-Z]/.test(pass) || !/\d/.test(pass))) {
      return alert('At least 8 characters, including uppercase, lowercase, and a number. A symbol is optional and may improve strength.');
    }
    try {
      const response = await fetch(`/api/users/${encodeURIComponent(currentUser.id)}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${sessionStorage.getItem('edugram_jwt') || ''}`,
        },
        body: JSON.stringify({
          firstName: first,
          middleName: middle,
          lastName: last,
          phone: currentUser.phone || '',
          studentId: currentUser.studentId || '',
          courseId: $('sp-course').value || '',
          majorId: $('sp-major').value || '',
          year: $('sp-year').value.trim(),
          section: $('sp-section').value.trim(),
          ...(pass ? { password: pass } : {}),
        }),
      });
      const result = await response.json();
      if (!response.ok) return alert(result.error || 'Could not update profile.');
      Object.assign(currentUser, result.user);
    } catch (error) {
      console.error('Profile update request failed', error);
      return alert('Could not reach the server. Profile was not saved.');
    }
    updateUserChrome();
    populateProfile();
    $('sp-toast')?.classList.remove('hidden');
    setTimeout(() => $('sp-toast')?.classList.add('hidden'), 2500);
  });
}

function populateProfile() {
  if (!$('sp-first')) return;
  $('sp-first').value = currentUser.firstName || '';
  $('sp-middle').value = currentUser.middleName || '';
  $('sp-last').value = currentUser.lastName || '';
  $('sp-id-input').value = currentUser.studentId || '';
  $('sp-pass').value = '';
  $('sp-avatar-display').textContent = ((currentUser.firstName?.[0] || 'S') + (currentUser.lastName?.[0] || '')).toUpperCase();
  $('sp-fullname-display').textContent = [currentUser.firstName, currentUser.middleName, currentUser.lastName].filter(Boolean).join(' ');
  if (academicOptions.length) fillStudentAcademicOptions();
  $('spa-submitted').textContent = SUBMISSIONS.filter(s => s.studentId === currentUser.id).length;
  $('spa-graded').textContent = SUBMISSIONS.filter(s => s.studentId === currentUser.id && s.status === 'graded').length;
  $('spa-pending').textContent = SUBMISSIONS.filter(s => s.studentId === currentUser.id && s.status !== 'graded').length;
}

function logout() {
  sessionStorage.clear();
  window.location.href = 'index.php';
}

document.addEventListener('DOMContentLoaded', initStudentDashboard);
