<?php
declare(strict_types=1);

namespace Edugram;

use PDO;
use Throwable;

final class Coursework
{
    /** Make a random UUID for an assignment or submission record. */
    private static function uuid(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 15) | 64);
        $bytes[8] = chr((ord($bytes[8]) & 63) | 128);
        $hex = bin2hex($bytes);
        return substr($hex, 0, 8) . '-' . substr($hex, 8, 4) . '-'
            . substr($hex, 12, 4) . '-' . substr($hex, 16, 4) . '-' . substr($hex, 20);
    }

    /** Read assignments, submissions, and drafts from the coursework table. */
    private static function records(PDO $db): array
    {
        $data = ['assignments' => [], 'submissions' => [], 'drafts' => []];
        $statement = $db->prepare('SELECT record_type, record_id, payload FROM coursework_records');
        $statement->execute();

        foreach ($statement->fetchAll() as $row) {
            $value = json_decode($row['payload'], true);
            if (!is_array($value)) {
                continue;
            }
            if ($row['record_type'] === 'assignment') {
                $data['assignments'][] = $value;
            } elseif ($row['record_type'] === 'submission') {
                $data['submissions'][] = $value;
            } elseif ($row['record_type'] === 'draft') {
                $data['drafts'][$row['record_id']] = $value;
            }
        }
        return $data;
    }

    /** Save changed records and their audit entry in a database transaction. */
    private static function saveRecords(
        PDO $db,
        array $data,
        array $oldData,
        array $actor,
        string $ip,
        string $event,
        string $description
    ): void {
        $db->beginTransaction();

        try {
            $rows = [];
            foreach ($data['assignments'] as $assignment) {
                $rows[] = [
                    'assignment',
                    (string)$assignment['id'],
                    $assignment['createdBy'] ?? null,
                    null,
                    $assignment,
                ];
            }
            foreach ($data['submissions'] as $submission) {
                $rows[] = [
                    'submission',
                    (string)$submission['id'],
                    $submission['studentId'] ?? null,
                    $submission['assignmentId'] ?? null,
                    $submission,
                ];
            }
            foreach ($data['drafts'] as $key => $draft) {
                $keyParts = explode(':', (string)$key, 2);
                $rows[] = [
                    'draft',
                    (string)$key,
                    $keyParts[0] ?? null,
                    $keyParts[1] ?? null,
                    $draft,
                ];
            }

            $removed = [];
            foreach ($oldData['assignments'] as $assignment) {
                $removed['assignment:' . $assignment['id']] = true;
            }
            foreach ($oldData['submissions'] as $submission) {
                $removed['submission:' . $submission['id']] = true;
            }
            foreach ($oldData['drafts'] as $key => $draft) {
                $removed['draft:' . $key] = true;
            }
            foreach ($rows as [$type, $id]) {
                unset($removed[$type . ':' . $id]);
            }

            $delete = $db->prepare(
                'DELETE FROM coursework_records WHERE record_type = :type AND record_id = :id'
            );
            foreach (array_keys($removed) as $key) {
                [$type, $id] = explode(':', $key, 2);
                $delete->execute(['type' => $type, 'id' => $id]);
            }

            $upsert = $db->prepare(
                'INSERT INTO coursework_records (record_type, record_id, owner_id, parent_id, payload) '
                . 'VALUES (:type, :id, :owner, :parent, :payload) '
                . 'ON DUPLICATE KEY UPDATE owner_id = VALUES(owner_id), '
                . 'parent_id = VALUES(parent_id), payload = VALUES(payload)'
            );
            foreach ($rows as [$type, $id, $owner, $parent, $value]) {
                $ownerId = is_string($owner) && preg_match('/^[1-9]\d*$/', $owner)
                    ? $owner
                    : null;
                $upsert->execute([
                    'type' => $type,
                    'id' => $id,
                    'owner' => $ownerId,
                    'parent' => $parent,
                    'payload' => json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                ]);
            }

            Audit::record($db, $actor['userId'], $event, $description, $ip);
            $db->commit();
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }
    }

    /** Route coursework requests and keep bulk database writes disabled. */
    public static function handle(
        PDO $db,
        string $method,
        string $path,
        array $body,
        array $actor,
        string $ip
    ): ?array {
        if ($path === '/api/data' && $method === 'GET') {
            return self::data($db, $actor);
        }
        if ($path === '/api/data' && $method === 'PUT') {
            return [405, ['error' => 'Bulk database updates are disabled; use the resource-specific routes']];
        }
        if (preg_match('#^/api/(assignments|drafts|submissions)(?:/([^/]+)(?:/(grade))?)?$#', $path, $matches)) {
            return self::mutation($db, $method, $matches, $body, $actor, $ip);
        }
        return null;
    }

    /** Check whether a student can access an assignment's selected classes. */
    private static function accessible(PDO $db, array $assignment, string $studentId): bool
    {
        if (!empty($assignment['forAll'])) {
            return true;
        }

        $statement = $db->prepare(
            'SELECT CAST(c.class_id AS CHAR) id, co.course_code courseCode, '
            . 'co.course_name courseName, m.major_name majorName, '
            . 'y.year_section_name yearSectionName, c.subject '
            . 'FROM classes c JOIN enrollments e ON e.class_id = c.class_id '
            . 'JOIN year_sections y ON y.year_section_id = c.year_section_id '
            . 'JOIN majors m ON m.major_id = y.major_id '
            . 'JOIN courses co ON co.course_id = m.course_id '
            . 'WHERE e.student_id = :student_id'
        );
        $statement->execute(['student_id' => $studentId]);

        foreach ($statement->fetchAll() as $class) {
            $fullName = $class['courseCode'] . ' - ' . $class['majorName'] . ' - '
                . $class['yearSectionName'] . ' - ' . $class['subject'];
            if ((string)$assignment['class'] === (string)$class['id']
                || (string)$assignment['class'] === (string)$class['yearSectionName']
                || (string)$assignment['class'] === $fullName) {
                return true;
            }
        }
        return false;
    }

    /** Return coursework filtered to the signed-in user's role and access. */
    private static function data(PDO $db, array $actor): array
    {
        $data = self::records($db);
        $userQuery = $db->prepare(
            'SELECT CAST(u.user_id AS CHAR) id, u.email, u.phone, CAST(u.role_id AS CHAR) roleId, '
            . 'r.role_name role, u.first_name firstName, u.middle_name middleName, '
            . 'u.last_name lastName, u.school_id_number studentId, '
            . 'CAST(u.year_section_id AS CHAR) yearSectionId, u.account_status accountStatus, '
            . 'u.created_at createdAt FROM users u JOIN roles r ON r.role_id = u.role_id '
            . 'ORDER BY u.created_at, u.user_id'
        );
        $userQuery->execute();
        $users = $userQuery->fetchAll();

        $usersById = [];
        foreach ($users as $user) {
            $usersById[$user['id']] = $user;
        }
        foreach ($data['submissions'] as &$submission) {
            $student = $usersById[(string)($submission['studentId'] ?? '')] ?? null;
            if ($student) {
                $submission['studentName'] = trim(implode(' ', array_filter([
                    $student['firstName'],
                    $student['middleName'],
                    $student['lastName'],
                ])));
            }
        }
        unset($submission);

        if ($actor['role'] === 'student') {
            $data['assignments'] = array_values(array_filter(
                $data['assignments'],
                fn(array $assignment): bool => self::accessible($db, $assignment, (string)$actor['userId'])
            ));
            $data['users'] = array_values(array_map(
                static function (array $user) use ($actor): array {
                    unset($user['email']);
                    $user['id'] = (string)$actor['userId'];
                    return $user;
                },
                array_filter($users, fn(array $user): bool => $user['id'] === (string)$actor['userId'])
            ));
            $data['submissions'] = array_values(array_map(
                static function (array $submission): array {
                    unset($submission['privateNote'], $submission['gradedBy']);
                    return $submission;
                },
                array_filter(
                    $data['submissions'],
                    fn(array $submission): bool => (string)($submission['studentId'] ?? '') === (string)$actor['userId']
                )
            ));
            $data['drafts'] = array_filter(
                $data['drafts'],
                fn(array $draft, string $key): bool => str_starts_with($key, (string)$actor['userId'] . ':'),
                ARRAY_FILTER_USE_BOTH
            );
        } elseif ($actor['role'] === 'teacher') {
            $data['assignments'] = array_values(array_filter(
                $data['assignments'],
                fn(array $assignment): bool => (string)($assignment['createdBy'] ?? '') === (string)$actor['userId']
            ));
            $assignmentIds = array_column($data['assignments'], 'id');
            $data['submissions'] = array_values(array_filter(
                $data['submissions'],
                fn(array $submission): bool => in_array($submission['assignmentId'] ?? null, $assignmentIds, true)
            ));
        } else {
            $data['users'] = $users;
        }

        return [200, [
            'users' => $data['users'] ?? $users,
            'assignments' => $data['assignments'],
            'submissions' => $data['submissions'],
            'drafts' => (object)$data['drafts'],
        ]];
    }

    /** Handle assignment, draft, submission, and grade changes. */
    private static function mutation(
        PDO $db,
        string $method,
        array $matches,
        array $body,
        array $actor,
        string $ip
    ): ?array {
        $kind = $matches[1];
        $recordId = $matches[2] ?? null;
        $isGradeRequest = ($matches[3] ?? '') === 'grade';
        $data = self::records($db);
        $oldData = $data;
        $role = $actor['role'];

        if ($kind === 'assignments') {
            return self::assignmentMutation($db, $method, $recordId, $body, $actor, $ip, $data, $oldData);
        }
        if ($kind === 'drafts' && $method === 'PUT') {
            return self::saveDraft($db, $recordId, $body, $actor, $ip, $data, $oldData);
        }
        if ($kind === 'submissions' && $isGradeRequest && $method === 'PUT') {
            return self::gradeSubmission($db, $recordId, $body, $actor, $ip, $data, $oldData);
        }
        if ($kind === 'submissions' && $method === 'POST') {
            return self::submitWork($db, $body, $actor, $ip, $data, $oldData);
        }
        return null;
    }

    /** Create, edit, or delete an assignment. */
    private static function assignmentMutation(
        PDO $db,
        string $method,
        ?string $assignmentId,
        array $body,
        array $actor,
        string $ip,
        array $data,
        array $oldData
    ): ?array {
        Auth::requireRole($actor, ['teacher', 'admin', 'super_admin']);

        if ($method === 'POST' && $assignmentId === null) {
            $title = is_string($body['title'] ?? null) ? trim($body['title']) : '';
            $description = is_string($body['description'] ?? null) ? trim($body['description']) : '';
            $dueTimestamp = strtotime((string)($body['dueDate'] ?? ''));
            if ($title === '' || $description === '' || $dueTimestamp === false) {
                throw new HttpError(400, 'Title, prompt, and valid due date are required');
            }

            $attachment = null;
            if (($body['attachment'] ?? null) !== null) {
                $attachmentData = $body['attachment'];
                $name = basename((string)($attachmentData['name'] ?? ''));
                $encoded = $attachmentData['data'] ?? '';
                $bytes = is_string($encoded) ? base64_decode($encoded, true) : false;
                if (!str_ends_with(strtolower($name), '.pdf') || !is_string($encoded)
                    || !preg_match('/^[A-Za-z0-9+\/]+={0,2}$/', $encoded)
                    || strlen($encoded) > 7 * 1024 * 1024 || $bytes === false
                    || strlen($bytes) > 5 * 1024 * 1024) {
                    throw new HttpError(400, 'Attach a PDF file no larger than 5 MB.');
                }
                if (substr($bytes, 0, 5) !== '%PDF-') {
                    throw new HttpError(400, 'The attachment must be a valid PDF no larger than 5 MB.');
                }
                $attachment = ['name' => substr($name, 0, 180), 'data' => $encoded];
            }

            $assignment = [
                'id' => self::uuid(),
                'title' => $title,
                'subject' => is_string($body['subject'] ?? null) ? trim($body['subject']) : '',
                'description' => $description,
                'rubric' => is_string($body['rubric'] ?? null) ? trim($body['rubric']) : '',
                'type' => is_string($body['type'] ?? null) ? $body['type'] : 'essay',
                'class' => is_string($body['class'] ?? null) ? $body['class'] : '',
                'forAll' => ($body['forAll'] ?? true) !== false,
                'minWords' => is_numeric($body['minWords'] ?? null) ? (int)$body['minWords'] : 250,
                'dueDate' => date('c', $dueTimestamp),
                'attachment' => $attachment,
                'createdBy' => (string)$actor['userId'],
                'createdAt' => date('c'),
            ];
            array_unshift($data['assignments'], $assignment);
            self::saveRecords(
                $db,
                $data,
                $oldData,
                $actor,
                $ip,
                'assignment_created',
                'Created assignment ' . $assignment['id'] . ': ' . $title
            );
            return [201, ['assignment' => $assignment]];
        }

        $assignmentIndex = null;
        foreach ($data['assignments'] as $index => $assignment) {
            if ((string)$assignment['id'] === $assignmentId) {
                $assignmentIndex = $index;
                break;
            }
        }
        if ($assignmentIndex === null) {
            return [404, ['error' => 'Assignment not found']];
        }

        $assignment = $data['assignments'][$assignmentIndex];
        if ($actor['role'] === 'teacher' && isset($assignment['createdBy'])
            && (string)$assignment['createdBy'] !== (string)$actor['userId']) {
            throw new HttpError(403, 'You may edit only your own assignments');
        }

        if ($method === 'PUT') {
            $title = is_string($body['title'] ?? null) ? trim($body['title']) : $assignment['title'];
            $dueDate = $body['dueDate'] ?? $assignment['dueDate'];
            $dueTimestamp = strtotime((string)$dueDate);
            if ($title === '' || $dueTimestamp === false) {
                throw new HttpError(400, 'Title and valid due date are required');
            }
            $assignment['title'] = $title;
            $assignment['dueDate'] = date('c', $dueTimestamp);
            if (is_numeric($body['minWords'] ?? null)) {
                $assignment['minWords'] = (int)$body['minWords'];
            }
            if (is_string($body['type'] ?? null)) {
                $assignment['type'] = $body['type'];
            }
            $data['assignments'][$assignmentIndex] = $assignment;
            self::saveRecords(
                $db,
                $data,
                $oldData,
                $actor,
                $ip,
                'assignment_updated',
                'Updated assignment ' . $assignment['id'] . ': ' . $assignment['title']
            );
            return [200, ['assignment' => $assignment]];
        }

        if ($method === 'DELETE') {
            $data['assignments'] = array_values(array_filter(
                $data['assignments'],
                fn(array $item): bool => (string)$item['id'] !== $assignmentId
            ));
            $data['submissions'] = array_values(array_filter(
                $data['submissions'],
                fn(array $submission): bool => (string)($submission['assignmentId'] ?? '') !== $assignmentId
            ));
            foreach (array_keys($data['drafts']) as $draftKey) {
                if (str_ends_with($draftKey, ':' . $assignmentId)) {
                    unset($data['drafts'][$draftKey]);
                }
            }
            self::saveRecords(
                $db,
                $data,
                $oldData,
                $actor,
                $ip,
                'assignment_deleted',
                'Deleted assignment ' . $assignmentId
            );
            return [200, ['success' => true]];
        }

        return null;
    }

    /** Save a student's draft for an assignment they can access. */
    private static function saveDraft(
        PDO $db,
        ?string $assignmentId,
        array $body,
        array $actor,
        string $ip,
        array $data,
        array $oldData
    ): array {
        Auth::requireRole($actor, ['student']);
        if (!is_string($body['content'] ?? null)) {
            throw new HttpError(400, 'Draft content is required');
        }

        $assignment = self::findAssignment($data, (string)$assignmentId);
        if ($assignment === null) {
            return [404, ['error' => 'Assignment not found']];
        }
        if (!self::accessible($db, $assignment, (string)$actor['userId'])) {
            throw new HttpError(403, 'Assignment is not available to your classes');
        }

        $draft = ['content' => $body['content'], 'savedAt' => date('c')];
        $data['drafts'][$actor['userId'] . ':' . $assignmentId] = $draft;
        self::saveRecords(
            $db,
            $data,
            $oldData,
            $actor,
            $ip,
            'draft_saved',
            'Saved draft for assignment ' . $assignmentId
        );
        return [200, ['draft' => $draft]];
    }

    /** Find one assignment by its public ID. */
    private static function findAssignment(array $data, string $assignmentId): ?array
    {
        foreach ($data['assignments'] as $assignment) {
            if ((string)$assignment['id'] === $assignmentId) {
                return $assignment;
            }
        }
        return null;
    }

    /** Grade a submission, checking teacher ownership when needed. */
    private static function gradeSubmission(
        PDO $db,
        ?string $submissionId,
        array $body,
        array $actor,
        string $ip,
        array $data,
        array $oldData
    ): array {
        Auth::requireRole($actor, ['teacher', 'admin', 'super_admin']);

        $submissionIndex = null;
        foreach ($data['submissions'] as $index => $submission) {
            if ((string)$submission['id'] === $submissionId) {
                $submissionIndex = $index;
                break;
            }
        }
        if ($submissionIndex === null) {
            return [404, ['error' => 'Submission not found']];
        }

        $submission = $data['submissions'][$submissionIndex];
        if ($actor['role'] === 'teacher') {
            $assignment = self::findAssignment($data, (string)$submission['assignmentId']);
            if ($assignment === null || (string)($assignment['createdBy'] ?? '') !== (string)$actor['userId']) {
                throw new HttpError(403, 'You may grade submissions for your own assignments only');
            }
        }

        $feedback = is_string($body['feedback'] ?? null) ? trim($body['feedback']) : '';
        $grade = is_string($body['grade'] ?? null) ? trim($body['grade']) : '';
        if ($feedback === '' && $grade === '') {
            throw new HttpError(400, 'Feedback or a grade is required');
        }

        $submission = array_merge($submission, [
            'feedback' => $feedback,
            'grade' => $grade,
            'privateNote' => is_string($body['privateNote'] ?? null) ? trim($body['privateNote']) : '',
            'status' => 'graded',
            'gradedAt' => date('c'),
            'gradedBy' => (string)$actor['userId'],
        ]);
        $data['submissions'][$submissionIndex] = $submission;
        self::saveRecords(
            $db,
            $data,
            $oldData,
            $actor,
            $ip,
            'submission_graded',
            'Graded submission ' . $submission['id']
        );
        return [200, ['submission' => $submission]];
    }

    /** Submit or update a student's work and remove its draft. */
    private static function submitWork(
        PDO $db,
        array $body,
        array $actor,
        string $ip,
        array $data,
        array $oldData
    ): array {
        Auth::requireRole($actor, ['student']);
        $assignmentId = is_string($body['assignmentId'] ?? null) ? $body['assignmentId'] : '';
        $content = is_string($body['content'] ?? null) ? $body['content'] : null;
        if ($assignmentId === '' || $content === null) {
            throw new HttpError(400, 'Assignment and submission content are required');
        }

        $assignment = self::findAssignment($data, $assignmentId);
        if ($assignment === null) {
            return [404, ['error' => 'Assignment not found']];
        }
        if (!self::accessible($db, $assignment, (string)$actor['userId'])) {
            throw new HttpError(403, 'Assignment is not available to your classes');
        }

        $userQuery = $db->prepare('SELECT first_name, middle_name, last_name FROM users WHERE user_id = :id');
        $userQuery->execute(['id' => $actor['userId']]);
        $user = $userQuery->fetch() ?: [];
        $studentName = trim(implode(' ', array_filter([
            $user['first_name'] ?? '',
            $user['middle_name'] ?? '',
            $user['last_name'] ?? '',
        ])));

        $submissionIndex = null;
        foreach ($data['submissions'] as $index => $submission) {
            if ((string)$submission['assignmentId'] === $assignmentId
                && (string)$submission['studentId'] === (string)$actor['userId']) {
                $submissionIndex = $index;
                break;
            }
        }

        $now = date('c');
        $isNew = $submissionIndex === null;
        $submission = [
            'id' => $isNew ? self::uuid() : $data['submissions'][$submissionIndex]['id'],
            'assignmentId' => $assignmentId,
            'studentId' => (string)$actor['userId'],
            'studentName' => $studentName,
            'content' => $content,
            'status' => 'submitted',
            'submittedAt' => $isNew ? $now : $data['submissions'][$submissionIndex]['submittedAt'],
            'updatedAt' => $now,
            'feedback' => '',
            'grade' => '',
            'privateNote' => '',
        ];

        if ($isNew) {
            $data['submissions'][] = $submission;
        } else {
            $data['submissions'][$submissionIndex] = $submission;
        }
        unset($data['drafts'][$actor['userId'] . ':' . $assignmentId]);

        self::saveRecords(
            $db,
            $data,
            $oldData,
            $actor,
            $ip,
            $isNew ? 'submission_created' : 'submission_updated',
            ($isNew ? 'Submitted' : 'Updated') . ' assignment ' . $assignmentId
        );
        return [$isNew ? 201 : 200, ['submission' => $submission]];
    }
}

