<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>EDUGRAM — Academic Writing & Submission System</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="../edu.css" />
  
  <link href="https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.snow.min.css" rel="stylesheet"/>
</head>
<body class="teacher-page">

  
  <div id="auth-screen" class="screen active">
    <div class="auth-page-bg">

      
      <div class="auth-card-wrap">

        
        <div id="login-view" class="auth-card-view active">
          <div class="auth-card">

            
            <div class="auth-avatar-ring">
              <svg viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" width="40" height="40">
                <circle cx="20" cy="15" r="8" fill="var(--navy)" opacity=".18"/>
                <circle cx="20" cy="14" r="7" fill="var(--navy)"/>
                <path d="M4 36c0-8.837 7.163-14 16-14s16 5.163 16 14" fill="var(--navy)" opacity=".85"/>
              </svg>
            </div>

            
            <div class="auth-card-brand">
              <svg width="22" height="22" viewBox="0 0 40 40" fill="none">
                <rect width="40" height="40" rx="9" fill="var(--navy)"/>
                <path d="M8 26L18 10L28 26H8Z" fill="var(--gold)" opacity="0.95"/>
                <path d="M13 26L18 17L23 26H13Z" fill="white" opacity="0.95"/>
              </svg>
              <span class="auth-card-brand-name">EDUGRAM</span>
            </div>

            <div class="auth-card-header">
              <h2>Welcome back</h2>
              <p>Sign in to your account to continue</p>
            </div>

            <div class="field-group">
              <label for="login-email">Email Address</label>
              <input type="email" id="login-email" placeholder="you@institution.edu" autocomplete="email" />
            </div>

            <div class="field-group">
              <label for="login-password">Password</label>
              <div class="password-wrap">
                <input type="password" id="login-password" placeholder="••••••••" autocomplete="current-password" />
                <button type="button" class="pw-toggle" data-target="login-password" aria-label="Show or hide password">
                  <svg class="eye-show" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/><path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/></svg>
                  <svg class="eye-hide" viewBox="0 0 20 20" fill="currentColor" style="display:none"><path fill-rule="evenodd" d="M3.707 2.293a1 1 0 00-1.414 1.414l14 14a1 1 0 001.414-1.414l-1.473-1.473A10.014 10.014 0 0019.542 10C18.268 5.943 14.478 3 10 3a9.958 9.958 0 00-4.512 1.074l-1.78-1.781zm4.261 4.26l1.514 1.515a2.003 2.003 0 012.45 2.45l1.514 1.514a4 4 0 00-5.478-5.478z" clip-rule="evenodd"/><path d="M12.454 16.697L9.75 13.992a4 4 0 01-3.742-3.741L2.335 6.578A9.98 9.98 0 00.458 10c1.274 4.057 5.064 7 9.542 7 .847 0 1.669-.105 2.454-.303z"/></svg>
                </button>
              </div>
            </div>

            <div id="login-error" class="form-error hidden"></div>

            <button class="btn-primary auth-submit-btn" id="login-btn">
              <span class="btn-label">Login</span>
              <span class="btn-spinner hidden"></span>
            </button>

            <div class="auth-card-links">
              <a href="#" id="go-register-link">Create Account</a>
              <a href="#" id="forgot-password-link">Forgot Password?</a>
            </div>

          </div>
        </div>

        
        <div id="register-view" class="auth-card-view">
          <div class="auth-card">

            <div class="auth-card-brand">
              <svg width="22" height="22" viewBox="0 0 40 40" fill="none">
                <rect width="40" height="40" rx="9" fill="var(--navy)"/>
                <path d="M8 26L18 10L28 26H8Z" fill="var(--gold)" opacity="0.95"/>
                <path d="M13 26L18 17L23 26H13Z" fill="white" opacity="0.95"/>
              </svg>
              <span class="auth-card-brand-name">EDUGRAM</span>
            </div>

            <div class="auth-card-header">
              <h2>Create Account</h2>
              <p>Join EDUGRAM — fill in your details below</p>
            </div>

            <div class="field-row">
              <div class="field-group">
                <label>First Name</label>
                <input type="text" id="reg-first" placeholder="First" autocomplete="given-name" />
              </div>
              <div class="field-group">
                <label>Middle Name (optional)</label>
                <input type="text" id="reg-middle" placeholder="Middle" autocomplete="additional-name" />
              </div>
              <div class="field-group">
                <label>Last Name</label>
                <input type="text" id="reg-last" placeholder="Last" autocomplete="family-name" />
              </div>
            </div>

            <div class="field-group">
              <label>Institutional Email</label>
              <input type="email" id="reg-email" placeholder="you@institution.edu" autocomplete="email" />
            </div>

            <div class="field-group">
              <label>Phone (optional)</label>
              <input type="tel" id="reg-phone" placeholder="Phone number" autocomplete="tel" />
            </div>

            <div class="field-group">
              <label>Student / Employee ID</label>
              <input type="text" id="reg-id" placeholder="e.g. 2024-00123" />
            </div>

            <div class="field-group">
              <label>Course (optional)</label>
              <select id="reg-course"><option value="">Select course</option></select>
              <label for="reg-major">Major</label>
              <select id="reg-major" disabled><option value="">Select major</option></select>
              <div class="field-row reg-year-section-inputs">
                <div class="field-group"><label for="reg-year">Year</label><input id="reg-year" type="number" min="1" max="6" step="1" inputmode="numeric" placeholder="1–6" /></div>
                <div class="field-group"><label for="reg-section">Section</label><input id="reg-section" type="text" maxlength="16" placeholder="e.g. 1 WMT" /></div>
              </div>
              <small class="academic-input-hint">Example: Year 4 and Section 1 WMT appear as 4-1 WMT.</small>
              <output id="reg-academic-output" class="academic-record-output" aria-live="polite">Your year and section will appear here.</output>
              <div id="reg-class-error" class="form-error hidden" role="alert"></div>
            </div>

            <div class="field-group">
              <label>Password</label>
              <div class="password-wrap">
                <input type="password" id="reg-password" placeholder="At least 8 characters, including uppercase, lowercase, and a number." autocomplete="new-password" />
                <button type="button" class="pw-toggle" data-target="reg-password" aria-label="Show or hide password">
                  <svg class="eye-show" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/><path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/></svg>
                  <svg class="eye-hide" viewBox="0 0 20 20" fill="currentColor" style="display:none"><path fill-rule="evenodd" d="M3.707 2.293a1 1 0 00-1.414 1.414l14 14a1 1 0 001.414-1.414l-1.473-1.473A10.014 10.014 0 0019.542 10C18.268 5.943 14.478 3 10 3a9.958 9.958 0 00-4.512 1.074l-1.78-1.781zm4.261 4.26l1.514 1.515a2.003 2.003 0 012.45 2.45l1.514 1.514a4 4 0 00-5.478-5.478z" clip-rule="evenodd"/><path d="M12.454 16.697L9.75 13.992a4 4 0 01-3.742-3.741L2.335 6.578A9.98 9.98 0 00.458 10c1.274 4.057 5.064 7 9.542 7 .847 0 1.669-.105 2.454-.303z"/></svg>
                </button>
              </div>
              <small id="reg-password-strength" aria-live="polite">Strength: Weak</small>
              <small>At least 8 characters, including uppercase, lowercase, and a number. A symbol is optional and may improve strength.</small>
            </div>

            <div class="field-group">
              <label for="reg-role-select">I am a…</label>
              <div class="role-dropdown-wrap">
                <select id="reg-role-select" name="role" class="role-dropdown">
                  <option value="" disabled selected>Select your role</option>
                  <option value="student">Student</option>
                  <option value="teacher">Teacher</option>
                  <option value="admin">Admin</option>
                </select>
                <span class="role-dropdown-arrow">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/></svg>
                </span>
              </div>
            </div>

            <div id="register-error" class="form-error hidden"></div>
            <div id="register-success" class="form-success hidden"></div>

            <button class="btn-primary auth-submit-btn" id="register-btn">
              <span class="btn-label">Create Account</span>
              <span class="btn-spinner hidden"></span>
            </button>

            <div class="auth-card-links auth-card-links--center">
              <a href="#" id="go-login-link">Already have an account? Sign in</a>
            </div>

          </div>
        </div>

        
        <div id="forgot-view" class="auth-card-view">
          <div class="auth-card">

            <div class="auth-card-brand">
              <svg width="22" height="22" viewBox="0 0 40 40" fill="none">
                <rect width="40" height="40" rx="9" fill="var(--navy)"/>
                <path d="M8 26L18 10L28 26H8Z" fill="var(--gold)" opacity="0.95"/>
                <path d="M13 26L18 17L23 26H13Z" fill="white" opacity="0.95"/>
              </svg>
              <span class="auth-card-brand-name">EDUGRAM</span>
            </div>

            <div class="auth-card-header">
              <h2>Reset Password</h2>
              <p>Enter your email and we'll send reset instructions</p>
            </div>

            <div class="field-group">
              <label for="forgot-email">Email Address</label>
              <input type="email" id="forgot-email" placeholder="you@institution.edu" autocomplete="email" />
            </div>

            <div id="forgot-error" class="form-error hidden"></div>
            <div id="forgot-success" class="form-success hidden"></div>

            <button class="btn-primary auth-submit-btn" id="forgot-btn">
              <span class="btn-label">Send Reset Link</span>
              <span class="btn-spinner hidden"></span>
            </button>

            <div class="auth-card-links auth-card-links--center">
              <a href="#" id="go-login-from-forgot">Back to Sign In</a>
            </div>

          </div>
        </div>

        <p class="auth-page-footer">© 2026 EDUGRAM · Academic Writing &amp; Submission System</p>
      </div>

    </div>
  </div>

  
    <aside class="sidebar" id="teacher-sidebar">
      <div class="sidebar-brand">
        <svg width="28" height="28" viewBox="0 0 36 36" fill="none">
          <rect width="36" height="36" rx="10" fill="#1a3a5c"/>
          <path d="M8 26L18 10L28 26H8Z" fill="#c9a84c" opacity="0.9"/>
          <path d="M13 26L18 17L23 26H13Z" fill="white" opacity="0.9"/>
        </svg>
        <span>EDUGRAM</span>
      </div>
      <nav class="sidebar-nav">
        <a href="#" class="nav-item active" data-panel="t-overview">
          <svg viewBox="0 0 20 20" fill="currentColor"><path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z"/></svg>
          Dashboard
        </a>
        <a href="#" class="nav-item" data-panel="t-create">
          <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v2H7a1 1 0 100 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V7z" clip-rule="evenodd"/></svg>
          Create Assignment
        </a>
        <a href="#" class="nav-item" data-panel="t-submissions">
          <svg viewBox="0 0 20 20" fill="currentColor"><path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"/><path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5z" clip-rule="evenodd"/></svg>
          Submissions
        </a>
        <a href="#" class="nav-item" data-panel="t-assignments">
          <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h6a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"/></svg>
          My Assignments
        </a>
        <a href="#" class="nav-item" data-panel="t-sections" aria-label="Classes">
          <svg viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M7 9a3 3 0 100-6 3 3 0 000 6zm6-1a2.5 2.5 0 100-5 2.5 2.5 0 000 5zM1 16a5 5 0 0110 0v1H1v-1zm11.5-4a4.5 4.5 0 016.5 4v1h-6v-1a6.9 6.9 0 00-.5-4z"/></svg>
          Classes
        </a>
        <a href="#" class="nav-item" data-panel="t-profile">
          <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"/></svg>
          My Profile
        </a>
      </nav>
      <div class="sidebar-footer">
        <div class="user-info">
          <div class="user-avatar teacher-avatar" id="teacher-avatar">T</div>
          <div class="user-details">
            <span class="user-name" id="teacher-name">Teacher</span>
            <span class="user-role">Instructor</span>
          </div>
        </div>
        <button class="logout-btn" id="teacher-logout">
          <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3 3a1 1 0 00-1 1v12a1 1 0 102 0V4a1 1 0 00-1-1zm10.293 9.293a1 1 0 001.414 1.414l3-3a1 1 0 000-1.414l-3-3a1 1 0 10-1.414 1.414L14.586 9H7a1 1 0 100 2h7.586l-1.293 1.293z" clip-rule="evenodd"/></svg>
        </button>
      </div>
    </aside>

    <main class="main-content" id="teacher-main">
      <div class="topbar">
        <div class="topbar-left">
          <button class="menu-toggle" id="teacher-menu-toggle">
            <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"/></svg>
          </button>
          <h1 class="topbar-title" id="teacher-panel-title">Dashboard</h1>
        </div>
        <div class="topbar-right">
          <div class="lang-badge">🇬🇧 English</div>
          <div class="topbar-right" style="position: relative;">
            <div class="notification-btn" id="notif-toggle">
              <svg viewBox="0 0 20 20" fill="currentColor"><path d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z"/></svg>
              <span class="notif-dot" id="notif-indicator"></span>
            </div>
            <div id="notif-dropdown" class="card hidden" style="position: absolute; top: 45px; right: 0; width: 300px; z-index: 1000; padding: 1rem;">
              <h4 style="margin-bottom: 1rem; border-bottom: 1px solid var(--gray-100); padding-bottom: .5rem; font-family: var(--font-serif); color: var(--navy);">Notifications</h4>
              <div id="notif-list" style="display: flex; flex-direction: column; gap: .75rem;"></div>
            </div>
          </div>
        </div>
      </div>

      
      <div class="panel active" id="t-overview">
        <div class="panel-content">
          <div class="welcome-banner teacher-banner">
            <div class="welcome-text">
              <h2>Welcome, <span id="teacher-welcome-name">Prof.</span> 📚</h2>
              <p>You have <strong id="t-pending-count" class="teacher-dashboard-link" role="button" tabindex="0" data-dashboard-panel="t-submissions" data-dashboard-filter="pending" aria-label="View submissions awaiting review">3</strong> submissions awaiting review.</p>
            </div>
            <div class="welcome-art">
              <svg width="120" height="80" viewBox="0 0 120 80">
                <ellipse cx="60" cy="70" rx="55" ry="8" fill="#1a3a5c" opacity="0.1"/>
                <rect x="20" y="20" width="80" height="50" rx="4" fill="#1a3a5c"/>
                <rect x="25" y="25" width="70" height="40" rx="2" fill="#f0f4f8"/>
                <circle cx="75" cy="35" r="10" fill="#c9a84c"/>
                <path d="M70 35l3 3 5-5" stroke="white" stroke-width="2" fill="none" stroke-linecap="round"/>
                <rect x="30" y="30" width="30" height="2" rx="1" fill="#1a3a5c" opacity="0.3"/>
                <rect x="30" y="35" width="25" height="2" rx="1" fill="#1a3a5c" opacity="0.2"/>
                <rect x="30" y="40" width="28" height="2" rx="1" fill="#1a3a5c" opacity="0.2"/>
                <rect x="30" y="50" width="60" height="8" rx="2" fill="#1a3a5c" opacity="0.1"/>
              </svg>
            </div>
          </div>

          <div class="stats-row">
            <div class="stat-card teacher-dashboard-stat" role="button" tabindex="0" data-dashboard-panel="t-sections" aria-label="View your students in Classes">
              <div class="stat-icon blue"><svg viewBox="0 0 20 20" fill="currentColor"><path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"/></svg></div>
              <div class="stat-info">
                <span class="stat-num" id="t-total-students">12</span>
                <span class="stat-label">Total Students</span>
              </div>
            </div>
            <div class="stat-card teacher-dashboard-stat" role="button" tabindex="0" data-dashboard-panel="t-assignments" aria-label="View active assignments">
              <div class="stat-icon gold"><svg viewBox="0 0 20 20" fill="currentColor"><path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"/><path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5z" clip-rule="evenodd"/></svg></div>
              <div class="stat-info">
                <span class="stat-num" id="t-total-assignments">4</span>
                <span class="stat-label">Active Assignments</span>
              </div>
            </div>
            <div class="stat-card teacher-dashboard-stat" role="button" tabindex="0" data-dashboard-panel="t-submissions" data-dashboard-filter="pending" aria-label="View submissions pending review">
              <div class="stat-icon red"><svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"/></svg></div>
              <div class="stat-info">
                <span class="stat-num" id="t-pending-review">3</span>
                <span class="stat-label">Pending Review</span>
              </div>
            </div>
            <div class="stat-card teacher-dashboard-stat" role="button" tabindex="0" data-dashboard-panel="t-submissions" data-dashboard-filter="graded" aria-label="View graded submissions">
              <div class="stat-icon green"><svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg></div>
              <div class="stat-info">
                <span class="stat-num" id="t-graded">5</span>
                <span class="stat-label">Graded</span>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-header">
              <h3>Recent Submissions</h3>
              <a href="#" class="card-link t-nav-link" data-panel="t-submissions">View all</a>
            </div>
            <div id="t-recent-submissions"></div>
          </div>
        </div>
      </div>

      
      <div class="panel" id="t-create" role="dialog" aria-modal="true" aria-labelledby="create-assignment-heading">
        <div class="modal-backdrop" id="create-assignment-backdrop"></div>
        <div class="panel-content create-assignment-modal-content">
          <div class="section-header">
            <div><h2 id="create-assignment-heading">Create New Assignment</h2><p>Set the instructions, due date, and handout for your students.</p></div>
            <button type="button" class="modal-close" id="create-assignment-close" aria-label="Close create assignment">×</button>
          </div>
          <div class="create-form-wrap">
            <div class="card create-form-card">
              <div class="field-group">
                <label>Assignment Title *</label>
                <input type="text" id="new-assignment-title" placeholder="e.g. Research Paper on Climate Change" />
              </div>
              <div class="field-row">
                <div class="field-group">
                  <label>Subject / Course</label>
                  <input type="text" id="new-assignment-subject" placeholder="e.g. English Composition" />
                </div>
                <div class="field-group">
                  <label>Due Date *</label>
                  <input type="date" id="new-assignment-due" />
                </div>
              </div>
              <div class="field-row">
                <div class="field-group">
                  <label>Minimum Word Count</label>
                  <input type="number" id="new-assignment-words" placeholder="e.g. 800" min="50" />
                </div>
                <div class="field-group">
                  <label>Assignment Type</label>
                  <select id="new-assignment-type">
                    <option value="essay">Essay</option>
                    <option value="research">Research Paper</option>
                    <option value="report">Book Report</option>
                    <option value="reflection">Reflection</option>
                    <option value="analysis">Critical Analysis</option>
                  </select>
                </div>
              </div>
              <div class="field-group">
                <label>Assignment Description / Prompt *</label>
                <textarea id="new-assignment-desc" rows="5" placeholder="Write detailed instructions for students…"></textarea>
              </div>
              <div class="field-group">
                <label>Rubric / Grading Criteria</label>
                <textarea id="new-assignment-rubric" rows="4" placeholder="Describe grading criteria (optional)…"></textarea>
              </div>
              <div class="field-group">
                <label for="new-assignment-pdf">PDF handout <span class="empty-hint">(optional, max 5 MB)</span></label>
                <label class="assignment-pdf-picker" for="new-assignment-pdf"><span class="assignment-pdf-icon">PDF</span><span><strong>Attach a PDF for students</strong><small id="new-assignment-pdf-name">No file selected</small></span><span class="btn-secondary small">Browse</span></label>
                <input id="new-assignment-pdf" type="file" accept="application/pdf,.pdf" hidden />
              </div>
              <div id="create-error" class="form-error hidden"></div>
              <div id="create-success" class="form-success hidden"></div>
              <div class="form-actions">
                <button class="btn-secondary" id="create-assignment-cancel" type="button">Cancel</button>
                <button class="btn-secondary" id="reset-assignment-btn" type="button">Reset</button>
                <button class="btn-primary" id="create-assignment-btn">Publish Assignment</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      
      <div class="panel" id="t-submissions">
        <div class="panel-content">
          <div class="section-header">
            <h2>Student Submissions</h2>
            <div class="filter-row">
              <button class="filter-btn active" data-tfilter="all">All</button>
              <button class="filter-btn" data-tfilter="pending">Pending</button>
              <button class="filter-btn" data-tfilter="graded">Graded</button>
            </div>
          </div>
          <div class="teacher-table-wrap"><table class="teacher-record-table"><thead><tr><th>Student</th><th>Assignment</th><th>Submitted</th><th>Status</th><th>Grade</th><th>Action</th></tr></thead><tbody id="submissions-list"></tbody></table></div>
          <div class="teacher-pagination" id="submissions-pagination" aria-label="Submission pages"></div>

          
          <div id="feedback-modal" class="modal hidden">
            <div class="modal-backdrop"></div>
            <div class="modal-box">
              <div class="modal-header">
                <h3>Review Submission</h3>
                <button class="modal-close" id="modal-close">✕</button>
              </div>
              <div class="modal-body">
                <div class="submission-preview">
                  <div class="preview-meta">
                    <span><strong>Student:</strong> <span id="modal-student"></span></span>
                    <span><strong>Assignment:</strong> <span id="modal-assignment"></span></span>
                    <span><strong>Submitted:</strong> <span id="modal-submitted"></span></span>
                  </div>
                  <div class="preview-text" id="modal-text"></div>
                </div>
                <div class="feedback-input-area">
                  <div style="display: flex; justify-content: space-between; align-items: center;">
                    <label>Your Feedback (Visible to Student)</label>
                    <button id="ai-generate-feedback-btn" type="button" class="btn-secondary small" style="display: flex; gap: 0.3rem; align-items: center; color: var(--navy); border-color: var(--navy);">
                      <svg viewBox="0 0 20 20" fill="currentColor" style="width: 14px; height: 14px;">
                        <path fill-rule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clip-rule="evenodd"/>
                      </svg>
                      AI Generate Feedback
                    </button>
                  </div>
                  <textarea id="modal-feedback-text" rows="5" placeholder="Write detailed feedback for the student…"></textarea>
                  <div class="private-note-area">
                    <label style="color: var(--red); margin-top: 0.5rem;">Private Note (Visible only to you)</label>
                    <textarea id="modal-private-note" rows="3" placeholder="Internal notes, grading justifications, etc."></textarea>
                  </div>
                  <div class="grade-row">
                    <label>Grade / Score</label>
                    <input type="text" id="modal-grade" placeholder="e.g. 88/100 or A-" />
                  </div>
                  <div class="feedback-tags">
                    <span class="ftag-label">Quick tags:</span>
                    <button class="ftag" data-tag="Good introduction">Good introduction</button>
                    <button class="ftag" data-tag="Needs more evidence">Needs more evidence</button>
                    <button class="ftag" data-tag="Excellent argument">Excellent argument</button>
                    <button class="ftag" data-tag="Work on transitions">Work on transitions</button>
                    <button class="ftag" data-tag="Strong conclusion">Strong conclusion</button>
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <button class="btn-secondary" id="modal-cancel">Cancel</button>
                <button class="btn-primary" id="modal-submit-feedback">Submit Feedback</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      
      <div id="edit-assignment-modal" class="modal hidden">
        <div class="modal-backdrop" id="edit-assignment-backdrop"></div>
        <div class="modal-box" style="max-width: 700px;">
          <div class="modal-header">
            <h3>Edit Assignment</h3>
            <button class="modal-close" id="edit-assignment-close">✕</button>
          </div>
          <div class="modal-body" style="display:flex;flex-direction:column;gap:1.1rem;">
            <div class="field-group">
              <label>Assignment Title *</label>
              <input type="text" id="edit-assignment-title" placeholder="e.g. Research Paper on Climate Change" />
            </div>
            <div class="field-row">
              <div class="field-group">
                <label>Open Date (Min. Date)</label>
                <input type="date" id="edit-assignment-open" />
              </div>
              <div class="field-group">
                <label>Due Date *</label>
                <input type="date" id="edit-assignment-due" />
              </div>
            </div>
            <div class="field-row">
              <div class="field-group">
                <label>Minimum Word Count</label>
                <input type="number" id="edit-assignment-words" min="50" placeholder="e.g. 800" />
              </div>
              <div class="field-group">
                <label>Assignment Type</label>
                <select id="edit-assignment-type">
                  <option value="essay">Essay</option>
                  <option value="research">Research Paper</option>
                  <option value="report">Book Report</option>
                  <option value="reflection">Reflection</option>
                  <option value="analysis">Critical Analysis</option>
                </select>
              </div>
            </div>
            <div id="edit-assignment-error" class="form-error hidden"></div>
            <div id="edit-assignment-success" class="form-success hidden"></div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" id="edit-assignment-cancel">Cancel</button>
            <button class="btn-primary" id="edit-assignment-save">Save Changes</button>
          </div>
        </div>
      </div>

      <div class="panel" id="t-sections">
        <div class="panel-content">
          <div class="section-header"><div><h2>My Classes</h2><p>Classes and students assigned to you.</p></div><span class="classes-section-badge">Teaching sections</span></div>
          <div id="teacher-classes-error" class="form-error hidden" role="alert"></div>
          <div class="teacher-table-wrap"><table class="teacher-record-table"><thead><tr><th>Course</th><th>Major</th><th>Year / Section</th><th>Subject</th><th>Students</th></tr></thead><tbody id="teacher-classes-list"></tbody></table></div>
          <div class="teacher-pagination" id="classes-pagination" aria-label="Class pages"></div>
        </div>
      </div>

      
      <div class="panel" id="t-assignments">
        <div class="panel-content">
          <div class="section-header">
            <h2>My Published Assignments</h2>
            <button class="btn-primary small t-nav-link" data-panel="t-create">+ New Assignment</button>
          </div>
          <div class="teacher-table-wrap"><table class="teacher-record-table"><thead><tr><th>Assignment</th><th>Subject</th><th>Due date</th><th>Words</th><th>Submissions</th><th>Actions</th></tr></thead><tbody id="teacher-assignment-list"></tbody></table></div>
          <div class="teacher-pagination" id="teacher-assignments-pagination" aria-label="Assignment pages"></div>
        </div>
      </div>

      
      <div class="panel" id="t-profile">
        <div class="panel-content">
          <div class="section-header"><h2>My Profile</h2></div>
          <div class="card create-form-card" style="max-width:1800px;">
            
            <div class="teacher-profile-header">
              <div class="tp-avatar" id="tp-avatar-display">T</div>
              <div class="tp-info">
                <div class="tp-fullname" id="tp-fullname-display">—</div>
                <div class="tp-role-tag">Teacher · Faculty</div>
                <div class="tp-email" id="tp-email-display">—</div>
              </div>
            </div>
            <div style="padding:1.5rem;display:flex;flex-direction:column;gap:1rem;">
              <div class="field-row">
                <div class="field-group">
                  <label>First Name</label>
                  <input type="text" id="profile-first" />
                </div>
                <div class="field-group">
                  <label>Middle Name</label>
                  <input type="text" id="profile-middle" />
                </div>
                <div class="field-group">
                  <label>Last Name</label>
                  <input type="text" id="profile-last" />
                </div>
              </div>
              <div class="field-group">
                <label>Email Address</label>
                <input type="email" id="profile-email-display" disabled style="background:var(--gray-50);color:var(--gray-500);" />
              </div>
              <div class="field-group">
                <label>Employee ID</label>
                <input type="text" id="profile-empid-display" disabled style="background:var(--gray-50);color:var(--gray-500);" />
              </div>
              <div class="field-group">
                <label>New Password (leave blank to keep current)</label>
                <input type="password" id="profile-pass" placeholder="••••••••" />
                <small id="profile-password-strength" aria-live="polite">Strength: Weak</small>
                <small>At least 8 characters, including uppercase, lowercase, and a number. A symbol is optional and may improve strength.</small>
              </div>
              <button class="btn-primary" id="save-profile-btn">Save Changes</button>
              <div id="profile-toast" class="form-success hidden" style="margin-top: 0;">✓ Profile Updated!</div>
            </div>
          </div>
        </div>
      </div>

    </main>
  </div>
  
  
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.min.js"></script>
  <script src="../js/database.js"></script>
  <script src="../js/teacher.js"></script>
</body>
</html>
