<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>EDUGRAM — Academic Writing &amp; Submission System</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="../edu.css" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.snow.min.css" rel="stylesheet"/>
</head>
<body>

  <div id="auth-screen" class="screen active">
    <div class="auth-page-bg">
      <div class="auth-layout">
        <aside class="auth-showcase" aria-label="About EDUGRAM">
          <div class="showcase-brand">
            <span class="showcase-brand-mark" aria-hidden="true">
              <svg viewBox="0 0 40 40" fill="none"><rect width="40" height="40" rx="12" fill="white"/><path d="M8 27 20 9l12 18H8Z" fill="#c9a84c"/><path d="m14 27 6-9 6 9H14Z" fill="#1a3a5c"/></svg>
            </span>
            <span>EDUGRAM</span>
          </div>
          <div class="showcase-copy">
            <span class="showcase-eyebrow"><span></span> YOUR ACADEMIC WORKSPACE</span>
            <h1>Make room for<br /><em>great ideas.</em></h1>
            <p>Write, learn, and keep your academic work moving in one thoughtful space.</p>
          </div>
          <div class="showcase-note" aria-hidden="true">
            <div class="showcase-note-top"><span class="note-icon">✦</span><span>YOUR NEXT CHAPTER</span><span class="note-dots">•••</span></div>
            <div class="note-lines"><i></i><i></i><i></i></div>
            <div class="note-highlight"><span>✦</span> Start with one clear idea.</div>
            <div class="note-footer"><span>EDUGRAM WRITING SPACE</span><span>01 / 03</span></div>
          </div>
          <div class="showcase-bottom"><span class="showcase-orbit" aria-hidden="true">✳</span><span>Every strong piece of work begins somewhere.</span></div>
        </aside>

        <div class="auth-card-wrap">

          <!-- LOGIN VIEW -->
          <div id="login-view" class="auth-card-view active">
            <div class="auth-card">

              <div class="auth-avatar-ring">
                <svg viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" width="40" height="40">
                  <circle cx="20" cy="15" r="8" fill="var(--navy)" opacity=".18"/>
                  <circle cx="20" cy="14" r="7" fill="var(--navy)"/>
                  <path d="M4 36c0-8.837 7.163-14 16-14s16 5.163 16 14" fill="var(--navy)" opacity=".85"/>
                </svg>
              </div>

              <div class="auth-card-brand">
                <svg width="22" height="22" viewBox="0 0 40 40" fill="none">
                  <rect width="40" height="40" rx="9" fill="var(--navy)"/>
                  <path d="M8 26L18 10L28 26H8Z" fill="var(--gold)" opacity="0.95"/>
                  <path d="M13 26L18 17L23 26H13Z" fill="white" opacity="0.95"/>
                </svg>
                <span class="auth-card-brand-name">EDUGRAM</span>
              </div>

              <div class="auth-card-header">
                <h2>Welcome back</h2>
                <p>Sign in to your account to continue</p>
              </div>

              <div class="field-group">
                <label for="login-email">Email or phone</label>
                <input type="text" id="login-email" placeholder="you@institution.edu or phone number" autocomplete="username" />
              </div>

              <div class="field-group">
                <label for="login-password">Password</label>
                <div class="password-wrap">
                  <input type="password" id="login-password" placeholder="••••••••" autocomplete="current-password" />
                  <button type="button" class="pw-toggle" data-target="login-password" aria-label="Show or hide password">
                    <svg class="eye-show" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/><path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/></svg>
                    <svg class="eye-hide" viewBox="0 0 20 20" fill="currentColor" style="display:none"><path fill-rule="evenodd" d="M3.707 2.293a1 1 0 00-1.414 1.414l14 14a1 1 0 001.414-1.414l-1.473-1.473A10.014 10.014 0 0019.542 10C18.268 5.943 14.478 3 10 3a9.958 9.958 0 00-4.512 1.074l-1.78-1.781zm4.261 4.26l1.514 1.515a2.003 2.003 0 012.45 2.45l1.514 1.514a4 4 0 00-5.478-5.478z" clip-rule="evenodd"/><path d="M12.454 16.697L9.75 13.992a4 4 0 01-3.742-3.741L2.335 6.578A9.98 9.98 0 00.458 10c1.274 4.057 5.064 7 9.542 7 .847 0 1.669-.105 2.454-.303z"/></svg>
                  </button>
                </div>
              </div>

              <div id="login-error" class="form-error hidden"></div>

              <button class="btn-primary auth-submit-btn" id="login-btn">
                <span class="btn-label">Login</span>
                <span class="btn-spinner hidden"></span>
              </button>

              <div class="auth-card-links">
                <a href="#" id="go-register-link">Create Account</a>
                <a href="#" id="forgot-password-link">Forgot Password?</a>
              </div>

            </div>
          </div>

          <!-- REGISTER VIEW -->
          <div id="register-view" class="auth-card-view" role="dialog" aria-modal="true" aria-labelledby="register-modal-title" tabindex="-1">
            <div class="auth-card">

              <div class="auth-card-brand">
                <svg width="22" height="22" viewBox="0 0 40 40" fill="none">
                  <rect width="40" height="40" rx="9" fill="var(--navy)"/>
                  <path d="M8 26L18 10L28 26H8Z" fill="var(--gold)" opacity="0.95"/>
                  <path d="M13 26L18 17L23 26H13Z" fill="white" opacity="0.95"/>
                </svg>
                <span class="auth-card-brand-name">EDUGRAM</span>
              </div>

              <div class="auth-card-header">
                <h2 id="register-modal-title">Create your account</h2>
                <p>Join EDUGRAM — fill in your details below</p>
              </div>

              <ol class="register-stepper" aria-label="Registration steps">
                <li class="active" data-register-indicator="0"><span>01</span><b>Personal</b></li>
                <li data-register-indicator="1"><span>02</span><b>Academic</b></li>
                <li data-register-indicator="2"><span>03</span><b>Security</b></li>
              </ol>
              <div id="register-step-count" class="register-step-count" aria-live="polite">Step 1 of 3</div>

              <div class="register-sections">
                <section class="register-section active" data-register-step="0">
                  <div class="register-section-heading"><span>01</span><div><strong>Personal details</strong><small>Your information helps identify your account.</small></div></div>
                  <div class="field-row">
                    <div class="field-group">
                      <label for="reg-first">First name</label>
                      <input type="text" id="reg-first" placeholder="First" autocomplete="given-name" />
                    </div>
                    <div class="field-group">
                      <label for="reg-middle">Middle name</label>
                      <input type="text" id="reg-middle" placeholder="Middle" autocomplete="additional-name" />
                    </div>
                    <div class="field-group">
                      <label for="reg-last">Last name</label>
                      <input type="text" id="reg-last" placeholder="Last" autocomplete="family-name" />
                    </div>
                  </div>

                  <div class="field-group">
                    <label for="reg-email">Institutional Email</label>
                    <input type="email" id="reg-email" placeholder="you@institution.edu" autocomplete="email" />
                  </div>

                  <div class="field-row">
                    <div class="field-group">
                      <label for="reg-phone">Phone <span class="register-optional">Optional</span></label>
                      <input type="tel" id="reg-phone" placeholder="Phone number" autocomplete="tel" />
                    </div>
                    <div class="field-group">
                      <label for="reg-id">Student ID</label>
                      <input type="text" id="reg-id" placeholder="e.g. 2024-00123" autocomplete="off" />
                    </div>
                  </div>
                </section>

                <section class="register-section" data-register-step="1">
                  <div class="register-section-heading"><span>02</span><div><strong>Academic placement</strong><small>Optional now; you can add it later.</small></div></div>
                  <div class="field-row registration-academic-path">
                    <div class="field-group"><label for="reg-course">Course</label><select id="reg-course"><option value="">Select course</option></select></div>
                    <div class="field-group"><label for="reg-major">Major</label><select id="reg-major" disabled><option value="">Select major</option></select></div>
                  </div>
                  <div class="field-row reg-year-section-inputs">
                    <div class="field-group"><label for="reg-year">Year</label><input id="reg-year" type="number" min="1" max="6" step="1" inputmode="numeric" placeholder="1–6" /></div>
                    <div class="field-group"><label for="reg-section">Section</label><input id="reg-section" type="text" maxlength="16" placeholder="e.g. 1 WMT" /></div>
                  </div>
                  <small class="academic-input-hint">Example: Year 4 and Section 1 WMT appear as 4-1 WMT.</small>
                  <output id="reg-academic-output" class="academic-record-output" aria-live="polite">Your year and section will appear here.</output>
                  <div id="reg-class-error" class="form-error hidden" role="alert"></div>
                </section>

                <section class="register-section register-credentials" data-register-step="2">
                  <div class="register-section-heading"><span>03</span><div><strong>Secure your account</strong><small>Choose a strong password and verify your email.</small></div></div>
                  
                  <div class="field-group">
                    <label for="reg-password">Password</label>
                    <div class="password-wrap">
                      <input type="password" id="reg-password" placeholder="Create a strong password" autocomplete="new-password" />
                      <button type="button" class="pw-toggle" data-target="reg-password" aria-label="Show or hide password">
                        <svg class="eye-show" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/><path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/></svg>
                        <svg class="eye-hide" viewBox="0 0 20 20" fill="currentColor" style="display:none"><path fill-rule="evenodd" d="M3.707 2.293a1 1 0 00-1.414 1.414l14 14a1 1 0 001.414-1.414l-1.473-1.473A10.014 10.014 0 0019.542 10C18.268 5.943 14.478 3 10 3a9.958 9.958 0 00-4.512 1.074l-1.78-1.781zm4.261 4.26l1.514 1.515a2.003 2.003 0 012.45 2.45l1.514 1.514a4 4 0 00-5.478-5.478z" clip-rule="evenodd"/><path d="M12.454 16.697L9.75 13.992a4 4 0 01-3.742-3.741L2.335 6.578A9.98 9.98 0 00.458 10c1.274 4.057 5.064 7 9.542 7 .847 0 1.669-.105 2.454-.303z"/></svg>
                      </button>
                    </div>
                    <small id="reg-password-strength" class="register-password-strength" aria-live="polite">Strength: Weak</small>
                    <small class="register-password-hint">At least 8 characters, including uppercase, lowercase, and a number.</small>
                  </div>

                  <div class="field-group" style="margin-top: 14px;">
                    <label for="reg-otp">Verification Code</label>
                    <div style="display: flex; gap: 8px;">
                      <input type="text" id="reg-otp" maxlength="6" placeholder="Enter 6-digit code" autocomplete="one-time-code" style="flex: 1;" />
                      <button type="button" id="send-otp-btn" class="btn-secondary" style="padding: 0 14px; white-space: nowrap;">Send Code</button>
                    </div>
                  </div>
                </section>
              </div>

              <div id="register-error" class="form-error hidden"></div>
              <div id="register-success" class="form-success hidden"></div>

              <div class="register-modal-actions">
                <button type="button" class="btn-secondary hidden" id="register-back-btn">Back</button>
                <button type="button" class="btn-primary auth-submit-btn" id="register-next-btn">Continue <span aria-hidden="true">→</span></button>
                <button class="btn-primary auth-submit-btn hidden" id="register-btn">
                  <span class="btn-label">Create Account</span>
                  <span class="btn-spinner hidden"></span>
                </button>
              </div>

              <div class="auth-card-links auth-card-links--center">
                <a href="#" id="go-login-link">Already have an account? Sign in</a>
              </div>

            </div>
          </div>

          <!-- FORGOT PASSWORD VIEW -->
          <div id="forgot-view" class="auth-card-view">
            <div class="auth-card">

              <div class="auth-card-brand">
                <svg width="22" height="22" viewBox="0 0 40 40" fill="none">
                  <rect width="40" height="40" rx="9" fill="var(--navy)"/>
                  <path d="M8 26L18 10L28 26H8Z" fill="var(--gold)" opacity="0.95"/>
                  <path d="M13 26L18 17L23 26H13Z" fill="white" opacity="0.95"/>
                </svg>
                <span class="auth-card-brand-name">EDUGRAM</span>
              </div>

              <div class="auth-card-header">
                <h2>Reset Password</h2>
                <p>Enter your institutional email, request a code, and set your new password.</p>
              </div>

              <div class="field-group">
                <label for="forgot-email">Email Address</label>
                <div style="display: flex; gap: 8px;">
                  <input type="email" id="forgot-email" placeholder="you@institution.edu" autocomplete="email" style="flex: 1;" />
                  <button type="button" id="send-forgot-otp-btn" class="btn-secondary" style="padding: 0 14px; white-space: nowrap;">Send Code</button>
                </div>
              </div>

              <div class="field-group" style="margin-top: 14px;">
                <label for="forgot-otp">Verification Code</label>
                <input type="text" id="forgot-otp" maxlength="6" placeholder="Enter 6-digit code" autocomplete="one-time-code" />
              </div>

              <div class="field-group" style="margin-top: 14px;">
                <label for="forgot-password">New Password</label>
                <div class="password-wrap">
                  <input type="password" id="forgot-password" placeholder="Enter new password" autocomplete="new-password" />
                </div>
              </div>

              <div id="forgot-error" class="form-error hidden"></div>
              <div id="forgot-success" class="form-success hidden"></div>

              <button class="btn-primary auth-submit-btn" id="forgot-btn" style="margin-top: 18px;">
                <span class="btn-label">Reset Password</span>
                <span class="btn-spinner hidden"></span>
              </button>

              <div class="auth-card-links auth-card-links--center">
                <a href="#" id="go-login-from-forgot">Back to Sign In</a>
              </div>

            </div>
          </div>

          <p class="auth-page-footer">© 2026 EDUGRAM · Academic Writing &amp; Submission System</p>
        </div>
      </div>

    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.min.js"></script>
  <script src="../js/database.js"></script>
  <script src="../js/auth.js"></script>
</body>
</html>