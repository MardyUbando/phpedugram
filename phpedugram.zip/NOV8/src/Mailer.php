<?php
declare(strict_types=1);

namespace Edugram;

use PHPMailer\PHPMailer\PHPMailer;

final class Mailer
{
    public static function sendOtp(string $recipient, string $code): void
    {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = $_ENV['MAIL_HOST'] ?? '';
        $mail->SMTPAuth = true;
        $mail->Username = $_ENV['MAIL_USERNAME'] ?? '';
        $mail->Password = $_ENV['MAIL_PASSWORD'] ?? '';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = (int)($_ENV['MAIL_PORT'] ?? 0);
        $mail->Timeout = 10;
        $mail->CharSet = 'UTF-8';

        $fromAddress = $_ENV['MAIL_FROM_ADDRESS'] ?? '';
        $fromName = $_ENV['MAIL_FROM_NAME'] ?? '';
        if ($mail->Host === '' || $mail->Port < 1 || $mail->Username === '' || $mail->Password === '' || $fromAddress === '' || $fromName === '') {
            throw new \RuntimeException('SMTP configuration is incomplete.');
        }

        $mail->setFrom($fromAddress, $fromName);
        $mail->addAddress($recipient);
        $mail->isHTML(true);
        $mail->Subject = 'Edugram Security: Your Verification Code';
        $safeCode = htmlspecialchars($code, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $mail->Body = '<h3>Your Edugram verification code is: <b>' . $safeCode
            . '</b></h3><p>This code expires in 5 minutes.</p>';
        $mail->AltBody = 'Your Edugram verification code is: ' . $code . '. This code expires in 5 minutes.';
        $mail->send();
    }
}
