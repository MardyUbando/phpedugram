<?php
declare(strict_types=1);

namespace Edugram;

use PDO;
use Throwable;

final class Otp
{
    private const EMAIL_LIMIT = 3;
    private const IP_LIMIT = 10;

    public static function send(PDO $db, string $email, string $ipAddress): void
    {
        $email = strtolower(trim($email));
        if ($email === '') {
            throw new HttpError(400, 'Email is required');
        }
        if (strlen($email) > 255 || !preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $email)) {
            throw new HttpError(400, 'A valid email address is required');
        }

        $purge = $db->prepare('DELETE FROM php_otp_verifications WHERE created_at < NOW() - INTERVAL 1 DAY');
        $purge->execute();
        $emailCount = $db->prepare(
            'SELECT COUNT(*) FROM php_otp_verifications '
            . 'WHERE email = :email AND created_at >= NOW() - INTERVAL 15 MINUTE'
        );
        $emailCount->execute(['email' => $email]);
        $ipCount = $db->prepare(
            'SELECT COUNT(*) FROM php_otp_verifications '
            . 'WHERE ip_address = :ip AND created_at >= NOW() - INTERVAL 15 MINUTE'
        );
        $ipCount->execute(['ip' => self::ip($ipAddress)]);
        if ((int)$emailCount->fetchColumn() >= self::EMAIL_LIMIT
            || (int)$ipCount->fetchColumn() >= self::IP_LIMIT) {
            throw new HttpError(429, 'Too many verification code requests. Please wait and try again.');
        }

        $code = (string)random_int(100000, 999999);
        $statement = $db->prepare(
            'INSERT INTO php_otp_verifications (email, otp_hash, expires_at, attempts, ip_address) '
            . 'VALUES (:email, :otp_hash, DATE_ADD(NOW(), INTERVAL 5 MINUTE), 0, :ip)'
        );
        $statement->execute([
            'email' => $email,
            'otp_hash' => self::hash($code),
            'ip' => self::ip($ipAddress),
        ]);
        $id = (string)$db->lastInsertId();

        try {
            Mailer::sendOtp($email, $code);
        } catch (Throwable $error) {
            $delete = $db->prepare('DELETE FROM php_otp_verifications WHERE id = :id');
            $delete->execute(['id' => $id]);
            throw $error;
        }
    }

    public static function verify(PDO $db, string $email, string $code, string $expiredMessage, string $invalidMessage): string
    {
        $email = strtolower(trim($email));
        $statement = $db->prepare(
            'SELECT id, otp_hash, attempts, used_at, (expires_at >= NOW()) AS is_valid '
            . 'FROM php_otp_verifications WHERE email = :email ORDER BY id DESC LIMIT 1'
        );
        $statement->execute(['email' => $email]);
        $record = $statement->fetch();
        if (!$record || $record['used_at'] !== null || (int)$record['attempts'] >= 5) {
            throw new HttpError(400, $invalidMessage);
        }
        if (!(bool)$record['is_valid']) {
            throw new HttpError(400, $expiredMessage);
        }

        if (!preg_match('/^\d{6}$/', $code) || !hash_equals((string)$record['otp_hash'], self::hash($code))) {
            $attempt = $db->prepare(
                'UPDATE php_otp_verifications SET attempts = LEAST(attempts + 1, 5) WHERE id = :id'
            );
            $attempt->execute(['id' => $record['id']]);
            throw new HttpError(400, $invalidMessage);
        }
        return (string)$record['id'];
    }

    public static function consume(PDO $db, string $id): void
    {
        $statement = $db->prepare('UPDATE php_otp_verifications SET used_at = NOW() WHERE id = :id AND used_at IS NULL');
        $statement->execute(['id' => $id]);
        if ($statement->rowCount() !== 1) {
            throw new HttpError(400, 'Invalid verification code');
        }
    }

    private static function hash(string $code): string
    {
        $secret = (string)($_ENV['OTP_HASH_SECRET'] ?? $_ENV['JWT_SECRET'] ?? '');
        if ($secret === '') {
            throw new \RuntimeException('OTP_HASH_SECRET or JWT_SECRET is missing from the environment.');
        }
        return hash_hmac('sha256', $code, $secret);
    }

    private static function ip(string $ipAddress): string
    {
        return substr($ipAddress !== '' ? $ipAddress : '0.0.0.0', 0, 45);
    }
}
