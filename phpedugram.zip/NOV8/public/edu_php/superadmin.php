<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>EDUGRAM — Academic Writing & Submission System</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="../edu.css" />
  
  <link href="https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.snow.min.css" rel="stylesheet"/>
</head>
<body class="superadmin-page">

  
  <div id="auth-screen" class="screen active">
    <div class="auth-page-bg">

      
      <div class="auth-card-wrap">

        
        <div id="login-view" class="auth-card-view active">
          <div class="auth-card">

            
            <div class="auth-avatar-ring">
              <svg viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" width="40" height="40">
                <circle cx="20" cy="15" r="8" fill="var(--navy)" opacity=".18"/>
                <circle cx="20" cy="14" r="7" fill="var(--navy)"/>
                <path d="M4 36c0-8.837 7.163-14 16-14s16 5.163 16 14" fill="var(--navy)" opacity=".85"/>
              </svg>
            </div>

            <div class="auth-card-brand">
              <svg width="22" height="22" viewBox="0 0 40 40" fill="none">
                <rect width="40" height="40" rx="9" fill="var(--navy)"/>
                <path d="M8 26L18 10L28 26H8Z" fill="var(--gold)" opacity="0.95"/>
                <path d="M13 26L18 17L23 26H13Z" fill="white" opacity="0.95"/>
              </svg>
              <span class="auth-card-brand-name">EDUGRAM</span>
            </div>

            <div class="auth-card-header">
              <h2>Welcome back</h2>
              <p>Sign in to your account to continue</p>
            </div>

            <div class="field-group">
              <label for="login-email">Email Address</label>
              <input type="email" id="login-email" placeholder="you@institution.edu" autocomplete="email" />
            </div>

            <div class="field-group">
              <label for="login-password">Password</label>
              <div class="password-wrap">
                <input type="password" id="login-password" placeholder="••••••••" autocomplete="current-password" />
                <button type="button" class="pw-toggle" data-target="login-password" aria-label="Show or hide password">
                  <svg class="eye-show" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/><path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/></svg>
                  <svg class="eye-hide" viewBox="0 0 20 20" fill="currentColor" style="display:none"><path fill-rule="evenodd" d="M3.707 2.293a1 1 0 00-1.414 1.414l14 14a1 1 0 001.414-1.414l-1.473-1.473A10.014 10.014 0 0019.542 10C18.268 5.943 14.478 3 10 3a9.958 9.958 0 00-4.512 1.074l-1.78-1.781zm4.261 4.26l1.514 1.515a2.003 2.003 0 012.45 2.45l1.514 1.514a4 4 0 00-5.478-5.478z" clip-rule="evenodd"/><path d="M12.454 16.697L9.75 13.992a4 4 0 01-3.742-3.741L2.335 6.578A9.98 9.98 0 00.458 10c1.274 4.057 5.064 7 9.542 7 .847 0 1.669-.105 2.454-.303z"/></svg>
                </button>
              </div>
            </div>

            <div id="login-error" class="form-error hidden"></div>

            <button class="btn-primary auth-submit-btn" id="login-btn">
              <span class="btn-label">Login</span>
              <span class="btn-spinner hidden"></span>
            </button>

            <div class="auth-card-links">
              <a href="#" id="go-register-link">Create Account</a>
              <a href="#" id="forgot-password-link">Forgot Password?</a>
            </div>

          </div>
        </div>

        
        <div id="register-view" class="auth-card-view">
          <div class="auth-card">

            <div class="auth-card-brand">
              <svg width="22" height="22" viewBox="0 0 40 40" fill="none">
                <rect width="40" height="40" rx="9" fill="var(--navy)"/>
                <path d="M8 26L18 10L28 26H8Z" fill="var(--gold)" opacity="0.95"/>
                <path d="M13 26L18 17L23 26H13Z" fill="white" opacity="0.95"/>
              </svg>
              <span class="auth-card-brand-name">EDUGRAM</span>
            </div>

            <div class="auth-card-header">
              <h2>Create Account</h2>
              <p>Join EDUGRAM — fill in your details below</p>
            </div>

            <div class="field-row">
              <div class="field-group">
                <label>First Name</label>
                <input type="text" id="reg-first" placeholder="First" autocomplete="given-name" />
              </div>
              <div class="field-group">
                <label>Middle Name (optional)</label>
                <input type="text" id="reg-middle" placeholder="Middle" autocomplete="additional-name" />
              </div>
              <div class="field-group">
                <label>Last Name</label>
                <input type="text" id="reg-last" placeholder="Last" autocomplete="family-name" />
              </div>
            </div>

            <div class="field-group">
              <label>Institutional Email</label>
              <input type="email" id="reg-email" placeholder="you@institution.edu" autocomplete="email" />
            </div>

            <div class="field-group">
              <label>Phone (optional)</label>
              <input type="tel" id="reg-phone" placeholder="Phone number" autocomplete="tel" />
            </div>

            <div class="field-group">
              <label>Student / Employee ID</label>
              <input type="text" id="reg-id" placeholder="e.g. 2024-00123" />
            </div>

            <div class="field-group">
              <label>Course (optional)</label>
              <select id="reg-course"><option value="">Select course</option></select>
              <label for="reg-major">Major</label>
              <select id="reg-major" disabled><option value="">Select major</option></select>
              <div class="field-row reg-year-section-inputs">
                <div class="field-group"><label for="reg-year">Year</label><input id="reg-year" type="number" min="1" max="6" step="1" inputmode="numeric" placeholder="1–6" /></div>
                <div class="field-group"><label for="reg-section">Section</label><input id="reg-section" type="text" maxlength="16" placeholder="e.g. 1 WMT" /></div>
              </div>
              <small class="academic-input-hint">Example: Year 4 and Section 1 WMT appear as 4-1 WMT.</small>
              <output id="reg-academic-output" class="academic-record-output" aria-live="polite">Your year and section will appear here.</output>
              <div id="reg-class-error" class="form-error hidden" role="alert"></div>
            </div>

            <div class="field-group">
              <label>Password</label>
              <div class="password-wrap">
                <input type="password" id="reg-password" placeholder="At least 8 characters, including uppercase, lowercase, and a number." autocomplete="new-password" />
                <button type="button" class="pw-toggle" data-target="reg-password" aria-label="Show or hide password">
                  <svg class="eye-show" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/><path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/></svg>
                  <svg class="eye-hide" viewBox="0 0 20 20" fill="currentColor" style="display:none"><path fill-rule="evenodd" d="M3.707 2.293a1 1 0 00-1.414 1.414l14 14a1 1 0 001.414-1.414l-1.473-1.473A10.014 10.014 0 0019.542 10C18.268 5.943 14.478 3 10 3a9.958 9.958 0 00-4.512 1.074l-1.78-1.781zm4.261 4.26l1.514 1.515a2.003 2.003 0 012.45 2.45l1.514 1.514a4 4 0 00-5.478-5.478z" clip-rule="evenodd"/><path d="M12.454 16.697L9.75 13.992a4 4 0 01-3.742-3.741L2.335 6.578A9.98 9.98 0 00.458 10c1.274 4.057 5.064 7 9.542 7 .847 0 1.669-.105 2.454-.303z"/></svg>
                </button>
              </div>
              <small id="reg-password-strength" aria-live="polite">Strength: Weak</small>
              <small>At least 8 characters, including uppercase, lowercase, and a number. A symbol is optional and may improve strength.</small>
            </div>

            <div class="field-group">
              <label for="reg-role-select">I am a…</label>
              <div class="role-dropdown-wrap">
                <select id="reg-role-select" name="role" class="role-dropdown">
                  <option value="" disabled selected>Select your role</option>
                  <option value="student">Student</option>
                  <option value="teacher">Teacher</option>
                  <option value="admin">Admin</option>
                </select>
                <span class="role-dropdown-arrow">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/></svg>
                </span>
              </div>
            </div>

            <div id="register-error" class="form-error hidden"></div>
            <div id="register-success" class="form-success hidden"></div>

            <button class="btn-primary auth-submit-btn" id="register-btn">
              <span class="btn-label">Create Account</span>
              <span class="btn-spinner hidden"></span>
            </button>

            <div class="auth-card-links auth-card-links--center">
              <a href="#" id="go-login-link">Already have an account? Sign in</a>
            </div>

          </div>
        </div>

        
        <div id="forgot-view" class="auth-card-view">
          <div class="auth-card">

            <div class="auth-card-brand">
              <svg width="22" height="22" viewBox="0 0 40 40" fill="none">
                <rect width="40" height="40" rx="9" fill="var(--navy)"/>
                <path d="M8 26L18 10L28 26H8Z" fill="var(--gold)" opacity="0.95"/>
                <path d="M13 26L18 17L23 26H13Z" fill="white" opacity="0.95"/>
              </svg>
              <span class="auth-card-brand-name">EDUGRAM</span>
            </div>

            <div class="auth-card-header">
              <h2>Reset Password</h2>
              <p>Enter your email and we'll send reset instructions</p>
            </div>

            <div class="field-group">
              <label for="forgot-email">Email Address</label>
              <input type="email" id="forgot-email" placeholder="you@institution.edu" autocomplete="email" />
            </div>

            <div id="forgot-error" class="form-error hidden"></div>
            <div id="forgot-success" class="form-success hidden"></div>

            <button class="btn-primary auth-submit-btn" id="forgot-btn">
              <span class="btn-label">Send Reset Link</span>
              <span class="btn-spinner hidden"></span>
            </button>

            <div class="auth-card-links auth-card-links--center">
              <a href="#" id="go-login-from-forgot">Back to Sign In</a>
            </div>

          </div>
        </div>

        <p class="auth-page-footer">© 2026 EDUGRAM · Academic Writing &amp; Submission System</p>
      </div>

    </div>
  </div>

  
    <aside class="sidebar" id="admin-sidebar">
      <div class="sidebar-brand">
        <svg width="28" height="28" viewBox="0 0 36 36" fill="none">
          <rect width="36" height="36" rx="10" fill="#1a3a5c"/>
          <path d="M8 26L18 10L28 26H8Z" fill="#c9a84c" opacity="0.9"/>
          <path d="M13 26L18 17L23 26H13Z" fill="white" opacity="0.9"/>
        </svg>
        <span>EDUGRAM</span>
      </div>
      <nav class="sidebar-nav">
        <a href="#" class="nav-item active" data-panel="a-overview">
          <svg viewBox="0 0 20 20" fill="currentColor"><path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z"/></svg>
          Dashboard
        </a>
        <a href="#" class="nav-item" data-panel="a-people">
          <svg viewBox="0 0 20 20" fill="currentColor"><path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z"/></svg>
          People Management
        </a>
        <a href="#" class="nav-item" data-panel="a-academic"><svg viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M10 2 2 6l8 4 6-3v5h2V6l-8-4Zm-5 8.5V14c0 1.7 2.2 3 5 3s5-1.3 5-3v-3.5l-5 2.5-5-2.5Z"/></svg>Academic Setup</a>
        <a href="#" class="nav-item" data-panel="a-sections"><svg viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M3 3h14a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Zm1.5 3v2h3V6h-3Zm4.5 0v2h6V6H9Zm-4.5 5v2h3v-2h-3Zm4.5 0v2h6v-2H9Z"/></svg>Classes</a>
      </nav>
      <div class="sidebar-footer">
        <div class="user-info">
          <div class="user-avatar teacher-avatar" id="admin-avatar">A</div>
          <div class="user-details">
            <span class="user-name" id="admin-name">Admin</span>
            <span class="user-role">Administrator</span>
          </div>
        </div>
        <button class="logout-btn" onclick="logout('admin')">
          <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3 3a1 1 0 00-1 1v12a1 1 0 102 0V4a1 1 0 00-1-1zm10.293 9.293a1 1 0 001.414 1.414l3-3a1 1 0 000-1.414l-3-3a1 1 0 10-1.414 1.414L14.586 9H7a1 1 0 100 2h7.586l-1.293 1.293z" clip-rule="evenodd"/></svg>
        </button>
      </div>
    </aside>

    <main class="main-content" id="admin-main">
      <div class="topbar">
        <div class="topbar-left">
          <button class="menu-toggle" id="admin-menu-toggle">
            <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"/></svg>
          </button>
          <h1 class="topbar-title">System Administration</h1>
        </div>
      </div>

      <div class="panel active" id="a-overview">
        <div class="panel-content">
          <div class="welcome-banner superadmin-hero">
            <div class="welcome-text">
              <span class="superadmin-eyebrow">EDUGRAM • SYSTEM CONTROL</span>
              <h2>Hello, <span id="admin-welcome-name">Admin</span> ⚙️</h2>
              <p>Manage people, classes, and academic setup from one place.</p>
            </div>
            <div class="superadmin-hero-mark" aria-hidden="true"><svg viewBox="0 0 120 120" fill="none"><circle cx="60" cy="60" r="49" stroke="currentColor" stroke-width="1.5"/><circle cx="60" cy="60" r="36" stroke="currentColor" stroke-width="1.5"/><path d="M31 76 60 29l29 47H31Z" fill="currentColor" opacity=".9"/><path d="m46 76 14-23 14 23H46Z" fill="#1a3a5c"/></svg></div>
          </div>
          <div class="superadmin-shortcuts">
            <button class="superadmin-shortcut" data-superadmin-panel="a-people"><span class="shortcut-icon"><svg viewBox="0 0 20 20" fill="currentColor"><path d="M9 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm8 0a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM1 16a5 5 0 0 1 10 0v1H1v-1Zm10.5-4.3a5 5 0 0 1 7.5 4.3v1h-6v-1a6.9 6.9 0 0 0-1.5-4.3Z"/></svg></span><span><strong>People</strong><small>Review and manage accounts</small></span><b aria-hidden="true">›</b></button>
            <button class="superadmin-shortcut" data-superadmin-panel="a-sections"><span class="shortcut-icon"><svg viewBox="0 0 20 20" fill="currentColor"><path d="M3 3h14a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Zm1.5 3v2h3V6h-3ZM9 6v2h6V6H9Zm-4.5 5v2h3v-2h-3ZM9 11v2h6v-2H9Z"/></svg></span><span><strong>Classes</strong><small>Organize courses and sections</small></span><b aria-hidden="true">›</b></button>
            <button class="superadmin-shortcut" data-superadmin-panel="a-academic"><span class="shortcut-icon"><svg viewBox="0 0 20 20" fill="currentColor"><path d="m10 2 8 4-8 4-8-4 8-4Zm-6 7.5 6 3 6-3V14c0 1.7-2.7 3-6 3s-6-1.3-6-3V9.5Z"/></svg></span><span><strong>Academic setup</strong><small>Configure courses and majors</small></span><b aria-hidden="true">›</b></button>
          </div>
        </div>
      </div>

      
      <div class="panel" id="a-people">
        <div class="panel-content">
          <div class="section-header">
            <h2>People Management</h2>
            <div style="display:flex;gap:.5rem;">
              <button class="btn-secondary small" id="add-teacher-btn">+ Add Teacher</button>
              <button class="btn-primary small" id="add-person-btn">+ Add Student</button>
            </div>
          </div>

          
          <div class="people-controls">
            <div class="people-search-wrap">
              <svg class="people-search-icon" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd"/></svg>
              <input type="text" id="people-search" placeholder="Search by name, email, or ID…" class="people-search-input" />
            </div>
            <div class="people-filter-tabs">
              <button class="filter-btn active" data-prole="all">All</button>
              <button class="filter-btn" data-prole="student">Students</button>
              <button class="filter-btn" data-prole="teacher">Teachers</button>
            </div>
          </div>

          
          <div class="people-stats-row" id="people-stats-row">
            <div class="pstat pstat-clickable" data-statfilter="all" title="Show all users"><span class="pstat-num" id="pstat-total">0</span><span class="pstat-label">Total Users</span></div>
            <div class="pstat pstat-clickable" data-statfilter="student" title="Show students"><span class="pstat-num" id="pstat-students">0</span><span class="pstat-label">Students</span></div>
            <div class="pstat pstat-clickable" data-statfilter="teacher" title="Show teachers"><span class="pstat-num" id="pstat-teachers">0</span><span class="pstat-label">Teachers</span></div>
            <div class="pstat pstat-clickable" data-statfilter="submissions" title="Show users with submissions"><span class="pstat-num" id="pstat-active">0</span><span class="pstat-label">With Submissions</span></div>
          </div>

          <div class="table-wrap people-table-wrap"><table class="people-table"><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>ID</th><th>Submissions</th><th>Actions</th></tr></thead><tbody id="people-grid"></tbody></table></div>
          <div class="people-pagination" id="people-pagination" aria-label="People pages"></div>
        </div>
      </div>

      <div class="panel" id="a-sections">
        <div class="panel-content">
          <div class="section-header superadmin-section-heading"><div><span class="superadmin-eyebrow">ORGANIZATION</span><h2><svg viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M3 3h14a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Zm1.5 3v2h3V6h-3ZM9 6v2h6V6H9Zm-4.5 5v2h3v-2h-3ZM9 11v2h6v-2H9Z"/></svg>Classes</h2><p>Create and maintain class groups, teachers, and student membership.</p></div></div>
          <div id="classes-error" class="form-error hidden" role="alert"></div>
          <div id="class-academic-error" class="form-error hidden" role="alert"></div>
          <div class="two-col">
            <div class="card">
              <h3>Manage class</h3>
              <div class="field-group"><label for="class-course">Course</label><select id="class-course"></select></div>
              <div class="field-group"><label for="class-major">Major</label><select id="class-major"></select></div>
              <div class="field-group"><label for="class-year-section">Year and Section</label><select id="class-year-section"></select></div>
              <div class="field-group"><label for="class-subject">Subject</label><input id="class-subject" maxlength="150" /></div>
              <div class="field-group"><label for="class-teacher">Teacher</label><select id="class-teacher"><option value="">Select teacher</option></select></div>
              <div class="field-group"><label for="class-student-ids">Class Members (student ID numbers; comma, spaces, or new lines)</label><textarea id="class-student-ids" rows="4"></textarea></div>
              <label><input type="checkbox" id="class-add-section-students" /> Also add all students of this section</label>
              <button type="button" class="btn-primary small" id="class-save">Create class</button>
              <button type="button" class="btn-secondary small hidden" id="class-cancel">Cancel edit</button>
            </div>
            <div class="card">
              <h3>Classes list</h3>
              <div class="table-wrap"><table><thead><tr><th>Course</th><th>Year and Section</th><th>Major</th><th>Subject</th><th>Teacher</th><th>Members</th><th>Actions</th></tr></thead><tbody id="classes-table-body"></tbody></table></div>
              <div class="people-pagination" id="classes-pagination" aria-label="Class pages"></div>
            </div>
          </div>
          <div class="card" style="margin-top:1rem;">
            <div class="section-header"><h3>Class members</h3><select id="class-member-select"><option value="">Select a class</option></select></div>
            <div class="field-row">
              <div class="field-group"><label for="class-bulk-ids">Student ID numbers (comma, spaces, or new lines)</label><textarea id="class-bulk-ids" rows="3"></textarea></div>
              <div class="field-group" style="align-self:end"><button type="button" class="btn-primary small" id="class-add-members-btn">Process IDs</button></div>
            </div>
            <div id="class-members-report" class="form-success hidden" role="status"></div>
            <div id="class-members-list"></div>
          </div>
        </div>
      </div>

      <div class="panel" id="a-academic">
        <div class="panel-content">
          <div class="section-header"><h2>Academic Setup</h2></div>
          <div id="academic-error" class="form-error hidden" role="alert"></div>
          <div id="academic-success" class="form-success hidden" role="status"></div>
          <div class="academic-grid">
            <section class="card academic-card">
              <h3>Courses</h3>
              <div class="academic-form">
                <div class="field-group"><label for="academic-course-code">Course Code</label><input id="academic-course-code" maxlength="20" required /></div>
                <div class="field-group"><label for="academic-course-name">Course Name</label><input id="academic-course-name" maxlength="150" required /></div>
                <div class="academic-actions">
                  <button type="button" class="btn-primary small academic-submit" id="academic-course-save" disabled>Add course</button>
                  <button type="button" class="btn-secondary small hidden" id="academic-course-cancel">Cancel edit</button>
                </div>
              </div>
              <div class="table-wrap academic-table-wrap"><table><thead><tr><th>Code</th><th>Name</th><th>Actions</th></tr></thead><tbody id="academic-courses-table"></tbody></table></div>
              <div class="people-pagination" id="academic-courses-pagination" aria-label="Course pages"></div>
            </section>
            <section class="card academic-card">
              <h3>Majors</h3>
              <div class="academic-form">
                <div class="field-group"><label for="academic-major-course">Course</label><select id="academic-major-course" required></select></div>
                <div class="field-group"><label for="academic-major-name">Major Name</label><input id="academic-major-name" maxlength="150" required /></div>
                <div class="academic-actions">
                  <button type="button" class="btn-primary small" id="academic-major-save" disabled>Add major</button>
                  <button type="button" class="btn-secondary small hidden" id="academic-major-cancel">Cancel edit</button>
                </div>
              </div>
              <div class="table-wrap academic-table-wrap"><table><thead><tr><th>Course</th><th>Major</th><th>Actions</th></tr></thead><tbody id="academic-majors-table"></tbody></table></div>
              <div class="people-pagination" id="academic-majors-pagination" aria-label="Major pages"></div>
            </section>
          </div>
          <section class="card academic-card academic-year-card">
            <h3>Year and Section</h3>
            <div class="academic-year-grid">
              <div class="field-group"><label for="academic-year-course">Course</label><select id="academic-year-course" required></select></div>
              <div class="field-group"><label for="academic-year-major">Major</label><select id="academic-year-major" required disabled></select></div>
              <div class="field-group"><label for="academic-year-name">Year and Section</label><input id="academic-year-name" maxlength="20" placeholder="2-1" required /></div>
              <div class="academic-actions">
                <button type="button" class="btn-primary small" id="academic-year-save" disabled>Add year and section</button>
                <button type="button" class="btn-secondary small hidden" id="academic-year-cancel">Cancel edit</button>
              </div>
            </div>
            <div class="table-wrap academic-table-wrap"><table><thead><tr><th>Course</th><th>Major</th><th>Year and Section</th><th>Actions</th></tr></thead><tbody id="academic-years-table"></tbody></table></div>
            <div class="people-pagination" id="academic-years-pagination" aria-label="Year and section pages"></div>
          </section>
        </div>
      </div>

      
      <div id="add-person-modal" class="modal hidden">
        <div class="modal-backdrop" id="add-person-backdrop"></div>
        <div class="modal-box" style="max-width: 700px;">
          <div class="modal-header">
            <h3 id="add-person-modal-title">Add New User</h3>
            <button class="modal-close" id="add-person-close" aria-label="Close modal">✕</button>
          </div>
          <div class="modal-body" style="display:flex;flex-direction:column;gap:1rem;">
            <div class="field-row">
              <div class="field-group">
                <label>First Name *</label>
                <input type="text" id="np-first" placeholder="First name" />
              </div>
              <div class="field-group">
                <label>Middle Name</label>
                <input type="text" id="np-middle" placeholder="Middle name" />
              </div>
              <div class="field-group">
                <label>Last Name *</label>
                <input type="text" id="np-last" placeholder="Last name" />
              </div>
            </div>
            <div class="field-group">
              <label>Institutional Email *</label>
              <input type="email" id="np-email" placeholder="student@institution.edu" />
            </div>
            <div class="role-selector">
              <label for="np-role-select">Role *</label>
              <div class="role-dropdown-wrap">
                <select id="np-role-select" class="role-dropdown">
                  <option value="student">🎓 Student</option>
                  <option value="teacher">🖥️ Teacher</option>
                  <option value="admin">⚙️ Admin</option>
                </select>
              </div>
            </div>
            <div class="field-row">
              <div class="field-group">
                <label id="np-id-label">ID *</label>
                <input type="text" id="np-id" placeholder="e.g. 2024-00123" />
              </div>
              <div class="field-group">
              </div>
            </div>
            <div class="field-group">
              <label>Temporary Password *</label>
              <input type="password" id="np-pass" placeholder="At least 8 characters, including uppercase, lowercase, and a number." />
              <small id="np-password-strength" aria-live="polite">Strength: Weak</small>
              <small>At least 8 characters, including uppercase, lowercase, and a number. A symbol is optional and may improve strength.</small>
            </div>
            <div id="np-error" class="form-error hidden"></div>
            <div id="np-success" class="form-success hidden"></div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" id="np-cancel">Cancel</button>
            <button class="btn-primary" id="np-save">Add Person</button>
          </div>
        </div>
      </div>

      <div id="view-person-modal" class="modal hidden">
        <div class="modal-backdrop" id="view-person-backdrop"></div>
        <div class="modal-box" style="max-width: 700px;">
          <div class="modal-header">
            <h3>User Profile</h3>
            <button class="modal-close" id="view-person-close" aria-label="Close modal">✕</button>
          </div>
          <div class="modal-body" style="display:flex;flex-direction:column;gap:1.2rem;">
            
            <div class="vp-header">
              <div class="vp-avatar" id="vp-avatar">U</div>
              <div>
                <div class="vp-name" id="vp-name">—</div>
                <div class="vp-role-badge" id="vp-role-badge">Student</div>
              </div>
            </div>
            
            <div class="field-row"><div class="field-group"><label>First Name</label><input type="text" id="vp-first" /></div><div class="field-group"><label>Middle Name</label><input type="text" id="vp-middle" /></div><div class="field-group"><label>Last Name</label><input type="text" id="vp-last" /></div></div>
            <div class="field-group"><label>Email</label><input type="email" id="vp-email" /></div>
            <div id="vp-role-manager" class="field-group">
              <label for="vp-role">Role</label>
              <select id="vp-role">
                <option value="student">Student</option>
                <option value="teacher">Teacher</option>
                <option value="admin">Admin</option>
              </select>
            </div>
            <div class="field-row">
              <div class="field-group"><label>ID</label><input type="text" id="vp-sid" /></div>
            </div>
            <div class="field-group"><label for="vp-year-section">Year and Section</label><select id="vp-year-section"></select></div>
            <div id="vp-status-manager" class="field-group">
              <label for="vp-account-status">Account status</label>
              <div style="display:flex;gap:.5rem;align-items:center">
                <select id="vp-account-status"><option value="active">Active</option><option value="locked">Locked</option><option value="suspended">Suspended</option></select>
                <button type="button" class="btn-secondary small" id="vp-status-save">Save status</button>
              </div>
              <div id="vp-status-error" class="form-error hidden" role="alert"></div>
            </div>
            <div id="vp-password-manager" class="field-group hidden">
              <label for="vp-pass">Reset Password</label>
              <input type="password" id="vp-pass" autocomplete="new-password" placeholder="At least 8 characters, including uppercase, lowercase, and a number." />
              <small id="vp-password-strength" aria-live="polite">Strength: Weak</small>
              <small>At least 8 characters, including uppercase, lowercase, and a number. A symbol is optional and may improve strength.</small>
              <button type="button" class="btn-secondary" id="vp-password-save" style="margin-top:.5rem">Update Password</button>
              <div id="vp-password-error" class="form-error hidden"></div>
              <div id="vp-password-success" class="form-success hidden"></div>
            </div>
            <div class="vp-activity" id="vp-activity"></div>
            <div id="vp-error" class="form-error hidden"></div>
            <div id="vp-success" class="form-success hidden"></div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary btn-danger-outline" id="vp-delete">Remove User</button>
            <div style="display:flex;gap:.5rem;">
              <button class="btn-secondary" id="vp-cancel">Cancel</button>
              <button class="btn-primary" id="vp-save">Save Changes</button>
            </div>
          </div>
        </div>
      </div>

      <div id="submissions-detail-modal" class="modal hidden">
        <div class="modal-backdrop" id="subs-detail-backdrop"></div>
        <div class="modal-box" style="max-width: 700px;">
          <div class="modal-header">
            <h3 id="subs-detail-title">Users with Submissions</h3>
            <button class="modal-close" id="subs-detail-close" aria-label="Close modal">✕</button>
          </div>
          <div class="modal-body" style="display:flex;flex-direction:column;gap:.75rem;max-height:60vh;overflow-y:auto;">
            <div id="subs-detail-list"></div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" id="subs-detail-cancel">Close</button>
          </div>
        </div>
      </div>

    </main>
  </div>

  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.min.js"></script>
  <script src="../js/auth.js"></script>
  <script src="../js/database.js"></script>
  <script src="../js/admin.js"></script>
</body>
</html>
