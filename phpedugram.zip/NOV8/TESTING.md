﻿# EDUGRAM manual test checklist

Before testing, complete the README setup, run both migrations, point Laragon to public/, and confirm /api/health succeeds. Use test accounts and sample records.

## Student

1. Register: on the login page choose Register, fill the required fields, click Send Verification Code, enter the emailed code, and submit. Expect a success message, then return to login.
2. Login: enter the registered email and password. Expect the student page and enrolled classes to load.
3. Wrong password: sign out and enter the right email with a wrong password. Expect “Invalid credentials” and remain on login.
4. Forgot password: choose Forgot Password, request a code, enter it and a valid new password, then submit. Expect confirmation and be able to log in with the new password.
5. Writing check: open an assignment, enter a passage, and click the writing-check action. Expect issue suggestions and a score.
6. Improve writing: select writing and click Improve. Expect a revised passage or a clear Gemini configuration/provider error.
7. Draft and submit: open an available assignment, enter work, save draft, then submit. Expect a saved confirmation; submission is marked submitted and the draft clears.
8. Logout: click logout. Expect login page and protected pages require sign-in.

## Teacher

1. Login: sign in with a teacher account. Expect only assigned classes.
2. Create assignment: enter title, prompt, due date, optional class details, and save. Expect the assignment in the list.
3. Grade: open a student submission, enter feedback or grade, and save. Expect graded status and visible feedback.
4. AI feedback: click the AI feedback action. Expect feedback and a grade suggestion or a provider/configuration error.
5. Profile and logout: update profile and save, then log out. Expect saved details and return to login.

## Admin

1. Login and people: sign in and open People. Expect the list to load without password hashes or secrets.
2. Create class: choose a year-section and teacher, enter subject, and save. Expect the class in the list.
3. Bulk enroll: open class members, paste multiple student IDs separated by commas or spaces, and submit. Expect each result as added, already in this class, not found, or not a student.
4. Remove student: remove an enrolled student. Expect the member list to refresh without that student.
5. User actions: change allowed student/teacher profile, password, role, and status; delete a disposable account. Expect a confirmation and inactive/deleted accounts can no longer use their token.
6. Logout: click logout and expect the login page.

## Super admin

1. Academic setup: create a course, a major under it, and a year-section under that major. Expect each entry in the options.
2. Edit and delete: edit a test entry; try deleting a used entry, then delete unused test entries. Expect the used entry deletion to be rejected and unused deletion to succeed.
3. Class and user management: create a class, bulk-enroll students, remove a student, change a test user's role/status, and delete a disposable user. Expect lists and responses to update.
4. Logout: click logout and expect the login page.

## Requests that should be rejected

- Enter a wrong OTP six times: the first five wrong tries are rejected and the code becomes unusable; request a new code.
- Request a code four times for the same email within 15 minutes: the fourth request should be rate-limited.
- As a student, try creating a class or changing a user role: expect HTTP 403 and “Forbidden”.
- Use an expired JWT on a protected request: expect HTTP 401 and sign in again.

